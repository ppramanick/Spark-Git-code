package mainApp

import io.confluent.kafka.serializers.KafkaAvroDeserializer
import org.apache.kafka.common.serialization.StringDeserializer
import java.time.format.DateTimeFormatter
import com.typesafe.config.ConfigFactory
import java.time.LocalDateTime
import java.time.LocalDate._
import java.util.Properties
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming._
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.spark.streaming.kafka010._
//import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010.{KafkaUtils, HasOffsetRanges, OffsetRange}
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Assign
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
//import io.confluent.kafka.serializers.KafkaAvroDecoder
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.{col, lit, when}
import scalikejdbc._
import org.apache.spark.{SparkContext, SparkConf}
import scala.collection.JavaConverters._
import za.co.absa.spline.core.SparkLineageInitializer._
object kafka_spark_demo extends Serializable{
  def main(args: Array[String]): Unit = {
	if (args.length < 2) {
      		System.exit(1)
    	}
	val conf = ConfigFactory.load
	val sparkConf = new SparkConf().setAppName("SparkKafka_2.3_new")
	//val sc = new SparkContext(sparkConf)
	val ssc = new StreamingContext(sparkConf, Seconds(10))
	val sparkSession = SparkSession.builder().config(sparkConf).getOrCreate()
	import za.co.absa.spline.core.SparkLineageInitializer._
	sparkSession.enableLineageTracking()
	
	val jdbcDriver = conf.getString("jdbc.driver")
    	val jdbcUrl = conf.getString("jdbc.url")
    	val jdbcUser = conf.getString("jdbc.user")
    	val jdbcPassword = conf.getString("jdbc.password")
	//val topics = conf.getString("kafka_param.topics")
	val bootstrap_server = conf.getString("kafka_param.bootstrap_server")
	val schemaRegistryURL = conf.getString("kafka_param.schemaRegistryURL")
	//val targetHDFSlocation = conf.getString("data_loading_param.targetHDFSLocation")
	val target_tableName = conf.getString("data_loading_param.target_tableName")
	val databaseName = conf.getString("data_loading_param.databaseName")

	val topics = args(0)
	val targetHDFSlocation = args(1)
	
	val kafkaParams = Map(
      		"bootstrap.servers" -> bootstrap_server,
      		//"key.deserializer" -> "org.apache.kafka.common.serialization.StringDeserializer",
      		//"value.deserializer" -> "io.confluent.kafka.serializers.KafkaAvroDeserializer",
		"key.deserializer" -> classOf[KafkaAvroDeserializer],
		"value.deserializer" -> classOf[KafkaAvroDeserializer],
      		"schema.registry.url" -> schemaRegistryURL,
      		"enable.auto.commit" -> "false",
      		"group.id" -> "order",
      		"auto.offset.reset" -> "earliest"
    		)
	 /* Collect JDBC  params*/
        val connURL = jdbcUrl + "/kafkaMETA"
        Class.forName(jdbcDriver)
        ConnectionPool.singleton(connURL, jdbcUser, jdbcPassword)
	
	/*val connectionProperties = new Properties()
	connectionProperties.put("user", jdbcUser)
	connectionProperties.put("driver", jdbcDriver)
	connectionProperties.put("password", jdbcPassword)*/
		
	val topic = topics.split(",").toSet
	
	val fromOffsets = DB.readOnly { implicit session =>
        			sql"""
                                select partitionInfo, offsetInfo from kafka_offset where topic = ${topics}""".map { rs =>
                                new TopicPartition(topics, rs.int("partitionInfo")) -> rs.long("offsetInfo")
                                }.toList.apply().toMap
        		}

	

	//val kafkaStream = KafkaUtils.createDirectStream(ssc, PreferConsistent, Subscribe[Object, Object](topic, kafkaParams))
	val messages = KafkaUtils.createDirectStream(ssc,
                        LocationStrategies.PreferConsistent,
                        Assign[Object, Object](fromOffsets.keys.toList, kafkaParams, fromOffsets))
	println("Received the messages now starting DStream---------------")
	messages.foreachRDD(rdd => {
	    println("collecting offset info---------")
	    val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
            offsetRanges.foreach(println) 
	    processLog(rdd, targetHDFSlocation, jdbcUrl, databaseName, jdbcUser, jdbcDriver, jdbcPassword, target_tableName)
            /*val sqlContext = SQLContext.getOrCreate(rdd.sparkContext)
            import sqlContext.implicits._
            
            val orderRDD = rdd.map(rec => rec.value().toString)
	    orderRDD.foreach(println)
            val orderDF = sqlContext.read.json(orderRDD)
            //val jsonDF = orderDF.toJSON.rdd
            orderDF.printSchema()
            orderDF.show()
            /**************Ingest data into Mysql table********************************/
            //orderDF.withColumn("time_stamp", current_timestamp()).write.mode("append").jdbc(jdbcUrl + "/" + databaseName, target_tableName, connectionProperties)
            /**************Ingest data into HDFS with Audit column*********************/
            orderDF.withColumn("time_stamp", current_timestamp()).write.mode("append").json(targetHDFSlocation)*/

	    DB.localTx{ implicit session =>
                        offsetRanges.foreach{ offsetRange =>
                        //sql"""insert into kafka_offset(topic, partition, offset) value(${topic}, ${offsetRange.partition}, ${offsetRange.fromOffset})""".update.apply()
                        val affectedRows = sql"""update kafka_offset set offsetInfo = ${offsetRange.untilOffset} where topic = ${topic} and partitionInfo = ${offsetRange.partition} and offsetInfo = ${offsetRange.fromOffset}""".update.apply()
                        if (affectedRows != 1) { throw new Exception("Fail to update offset")}
                        	}/*end of foreach loop*/
                      }/*End of DB loop*/
	

            
        })/* End of kafkaStream foreach loop */

	ssc.start()
	ssc.awaitTermination()
	}
	

	def processLog(rdd: RDD[ConsumerRecord[Object, Object]], targetHDFSlocation:String, jdbcUrl:String, databaseName:String, jdbcUser:String, jdbcDriver:String, jdbcPassword:String, target_tableName:String) = {
	    val sqlContext = SQLContext.getOrCreate(rdd.sparkContext)
            import sqlContext.implicits._
	    val connectionProperties = new Properties()
            connectionProperties.put("user", jdbcUser)
            connectionProperties.put("driver", jdbcDriver)
            connectionProperties.put("password", jdbcPassword)

            val orderRDD = rdd.map(rec => rec.value().toString)
            //orderRDD.foreach(println)
            val orderDF = sqlContext.read.json(orderRDD)
            //val jsonDF = orderDF.toJSON.rdd
            orderDF.printSchema()
            orderDF.show()
            /**************Ingest data into Mysql table********************************/
            //orderDF.withColumn("time_stamp", current_timestamp()).write.mode("append").jdbc(jdbcUrl + "/" + databaseName, target_tableName, connectionProperties)
            /**************Ingest data into HDFS with Audit column*********************/
            orderDF.withColumn("time_stamp", current_timestamp()).write.mode("append").json(targetHDFSlocation)

}
}	
