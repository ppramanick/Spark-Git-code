SELECT t1.`(start_date|end_date|scd_flag)?+.+` FROM dev_core_group_plus.MemberInsuranceAgreementCoveredParty t1
INNER JOIN dev_publish_db_group_plus.InsuranceAgreement t2
ON t1.MemberInsuranceAgreementNumber = t2.InsuranceAgreementNumber
AND t1.InternalCompanyCode = t2.InternalCompanyCode
AND t2.InsuranceAgreementTypeCode IN ('Individual Certificate')
AND t1.scd_flag = true
INNER JOIN dev_publish_db_group_plus.Party t4
ON t1.SourceGNLGroupNumber = t4.SourceGNLGroupNumber
AND t1.SourceGNLDependentSequenceNumber = t4.SourceGNLDependentSequenceNumber
AND t1.SourceGNLParticipantID = t4.SourceGNLParticipantID
AND t4.SourceGNLAccountNumber = 0
AND t1.SourceSystemCode = t4.SourceSystemCode
INNER JOIN dev_publish_db_group_plus.ProductCoverage t3
ON t1.ProductCode = t3.ProductCoveragecode
limit 10000;


