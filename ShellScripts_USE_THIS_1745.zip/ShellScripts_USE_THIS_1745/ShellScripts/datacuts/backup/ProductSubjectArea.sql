set hive.support.quoted.identifiers=none;
-- Mitigate VORTEX failure
--set hive.execution.engine=mr;

--Load Parent Table
INSERT OVERWRITE TABLE dev_publish_db_group_plus.ProductCoverage
SELECT `(start_date|end_date|scd_flag)?+.+`
FROM dev_core_group_plus.ProductCoverage WHERE scd_flag = true
LIMIT 10000;

--Load Child Table PartyAddress
INSERT OVERWRITE TABLE dev_publish_db_group_plus.CoveragePlan
SELECT `(start_date|end_date|scd_flag)?+.+` FROM dev_core_group_plus.CoveragePlan t1
INNER JOIN dev_publish_db_group_plus.ProductCoverage t2
ON t1.InternalCompanyCode = t2.InternalCompanyCode
AND t1.ProductCoverageCode = t2.ProductCoverageCode
AND t1.scd_flag = true;