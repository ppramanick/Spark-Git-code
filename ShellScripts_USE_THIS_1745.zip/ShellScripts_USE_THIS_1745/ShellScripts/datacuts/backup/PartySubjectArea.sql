set hive.support.quoted.identifiers=none;

--Load Parent Table
INSERT OVERWRITE TABLE dev_publish_db_group_plus.Party
SELECT  partyname, partycreatedate, partytype, partyrole, preferredlanguagecode, preferredcontacttypecode, geographicareacode, firstname, lastname, middlename, namesuffix, gendercode, birthdate, ethnicitycode, naicscode, siccode, totalemployeecount, situsstatecode, maritalstatuscode, sourcegnlgroupnumber, sourcecifnumber, sourcegnlparticipantid, sourceacfwritingnumber, sourcemdmpartyobjectid, sourcewynid, sourcewynnamespaceid, sourcewynclientid, internalcompanycode, sourcegmgroupnumber, sourcegnlaccountnumber, smokerindicator, currentrecordindicator, sourcesystemcode, logicaldeleteindicator, masterpartyid, sourcegnlwritingnumber, partytitle, deathdate, childsupportlienonfileindicator, childsupportlienonfiletimestamp, onchildsupportliennetworkindicator, onchildsupportliennetworktimestamp, irsdefaultindicator, sourcegnldependentsequencenumber, lastupdateuserid, lastupdatedatetime, hivelastupdatetimestamp, hashcode FROM dev_core_group_plus.Party WHERE scd_flag = true
LIMIT 2500000;

--Load Child Table PartyAddress
INSERT OVERWRITE TABLE dev_publish_db_group_plus.PartyAddress
SELECT distinct t1.sourcegnlgroupnumber, t1.sourcegnlparticipantid, t1.sourcegnlaccountnumber, t1.partyaddresscategorycode, t1.addressline1, t1.addressline2, t1.addressline3, t1.addresscityname, t1.addresspostalcode, t1.statecode, t1.preferredaddresscategoryindicator, t1.countrycode, t1.addressvalidationindicator, t1.currentrecordindicator, t1.sourcesystemcode, t1.logicaldeleteindicator, t1.county, t1.lastupdateuserid, t1.lastupdatedatetime, t1.hivelastupdatetimestamp, t1.hashcode FROM dev_core_group_plus.PartyAddress t1
INNER JOIN dev_publish_db_group_plus.Party t2 
ON t1.SourceGNLGroupNumber = t2.SourceGNLGroupNumber
AND t1.SourceGNLParticipantID = t2.SourceGNLParticipantID
AND t1.SourceGNLAccountNumber = t2.SourceGNLAccountNumber
AND t2.sourcegnldependentsequencenumber = 0
AND t1.scd_flag = true limit 10000;

--Load Child Table PartyAlternateID
INSERT OVERWRITE TABLE dev_publish_db_group_plus.PartyAlternateID
SELECT distinct t1.sourcegnlaccountnumber, t1.sourcegnlparticipantid, t1.sourcegnldependentsequencenumber, t1.sourcegnlgroupnumber, t1.partyalternateidtypecode, t1.partyalternateidvalue, t1.currentrecordindicator, t1.sourcesystemcode, t1.logicaldeleteindicator, t1.lastupdateuserid, t1.lastupdatedatetime, t1.hivelastupdatetimestamp, t1.hashcode FROM dev_core_group_plus.PartyAlternateID t1
INNER JOIN dev_publish_db_group_plus.Party t2 
ON t1.scd_flag = true
AND t1.SourceGNLGroupNumber = t2.SourceGNLGroupNumber
AND t1.SourceGNLParticipantID = t2.SourceGNLParticipantID
AND t1.SourceGNLAccountNumber = t2.SourceGNLAccountNumber
AND t1.SourceGNLDependentSequenceNumber = t2.SourceGNLDependentSequenceNumber limit 10000;


--Load Child Table PartyElectronicAddress
INSERT OVERWRITE TABLE dev_publish_db_group_plus.PartyElectronicAddress
SELECT distinct t1.sourcegnlgroupnumber, t1.sourcegnlparticipantid, t1.sourcegnlaccountnumber, t1.roletype, t1.electronicaddresstypecode, t1.electronicaddresstext, t1.electronicaddresscategorytypecode, t1.currentrecordindicator, t1.sourcesystemcode, t1.logicaldeleteindicator, t1.lastupdateuserid, t1.lastupdatedatetime, t1.hivelastupdatetimestamp, t1.hashcode FROM dev_core_group_plus.PartyElectronicAddress t1
INNER JOIN dev_publish_db_group_plus.Party t2 
ON t1.SourceGNLGroupNumber = t2.SourceGNLGroupNumber
AND t1.SourceGNLParticipantID = t2.SourceGNLParticipantID
AND t1.SourceGNLAccountNumber = t2.SourceGNLAccountNumber
AND t2.sourcegnldependentsequencenumber = 0
AND t1.scd_flag = true;


--Load Child Table PartyPhone
INSERT OVERWRITE TABLE dev_publish_db_group_plus.PartyPhone
SELECT distinct t1.sourcegnlgroupnumber, t1.sourcegnlaccountnumber, t1.phonetype, t1.preferredphonetypeflag, t1.phonenumber, t1.phoneextension, t1.currentrecordindicator, t1.sourcesystemcode, t1.logicaldeleteindicator, t1.lastupdateuserid, t1.lastupdatedatetime, t1.hivelastupdatetimestamp, t1.hashcode FROM dev_core_group_plus.PartyPhone t1
INNER JOIN dev_publish_db_group_plus.Party t2 
ON t1.scd_flag = true
AND t1.SourceGNLGroupNumber = t2.SourceGNLGroupNumber
AND t1.SourceGNLAccountNumber = t2.SourceGNLAccountNumber 
AND t2.SourceGNLParticipantID = '0000000000'
AND t2.sourcegnldependentsequencenumber = 0
limit 10000;