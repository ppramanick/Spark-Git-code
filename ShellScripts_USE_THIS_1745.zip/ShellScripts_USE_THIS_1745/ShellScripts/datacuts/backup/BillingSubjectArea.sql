set hive.support.quoted.identifiers=none;


--Load Parent Table
INSERT OVERWRITE TABLE dev_publish_db_group_plus.AccountTransaction
SELECT `(start_date|end_date|scd_flag)?+.+`
FROM dev_core_group_plus.AccountTransaction WHERE scd_flag = true
LIMIT 10000;

INSERT OVERWRITE TABLE dev_publish_db_group_plus.Invoice
SELECT `(start_date|end_date|scd_flag)?+.+`
FROM dev_core_group_plus.Invoice WHERE scd_flag = true
LIMIT 10000;

INSERT OVERWRITE TABLE dev_publish_db_group_plus.Payment
SELECT `(start_date|end_date|scd_flag)?+.+` 
FROM dev_core_group_plus.Payment WHERE scd_flag = true
LIMIT 10000;


--Load Child Table AccountLine
INSERT OVERWRITE TABLE dev_publish_db_group_plus.AccountLine
SELECT `(start_date|end_date|scd_flag)?+.+` FROM dev_core_group_plus.AccountLine t1
INNER JOIN dev_publish_db_group_plus.AccountTransaction t2
ON t1.TransactionNumber = t2.TransactionNumber
INNER JOIN dev_publish_db_group_plus.BusinessAccount t3
ON t1.BusinessAccountNumber = t3.BusinessAccountNumber
AND t1.scd_flag = true;

--Load Child Table Bill
INSERT OVERWRITE TABLE dev_publish_db_group_plus.Bill
SELECT `(start_date|end_date|scd_flag)?+.+` FROM dev_core_group_plus.Bill t1
INNER JOIN dev_publish_db_group_plus.Invoice t2
ON t1.InvoiceNumber = t2.InvoiceNumber
INNER JOIN dev_publish_db_group_plus.InsuranceAgreement t3
ON t1.GroupInsuranceAgreementNumber = t3.InsuranceAgreementNumber
AND t1.scd_flag = true;


--Load Child Table BillLine
INSERT OVERWRITE TABLE dev_publish_db_group_plus.BillLine
SELECT `(start_date|end_date|scd_flag)?+.+` FROM dev_core_group_plus.BillLine t1
INNER JOIN dev_publish_db_group_plus.Bill t2
ON t1.BillNumber  = t2.BillNumber
INNER JOIN dev_publish_db_group_plus.AccountLine t3
ON t1.AccountLineNumber = t3.AccountLineNumber
AND t1.scd_flag = true;

--Load Child Table PaymentLine
INSERT OVERWRITE TABLE dev_publish_db_group_plus.PaymentLine
SELECT `(start_date|end_date|scd_flag)?+.+` FROM dev_core_group_plus.PaymentLine t1
INNER JOIN dev_publish_db_group_plus.Payment t2
ON t1.PaymentNumber  = t2.PaymentNumber
INNER JOIN dev_publish_db_group_plus.AccountLine t3
ON t1.AccountLineNumber = t3.AccountLineNumber
AND t1.scd_flag = true;