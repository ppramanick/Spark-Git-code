INSERT OVERWRITE TABLE dev_publish_db_group_plus.MemberInsuranceAgreementCoverage
SELECT DISTINCT t1.memberinsuranceagreementnumber, t1.internalcompanycode, t1.insuranceagreementtypecode, t1.productcode, t1.groupinsuranceagreementnumber, t1.groupinsuranceagreementtypecode, t1.memberinsuranceagreementcoverageeffectivedate, t1.memberinsuranceagreementcoverageenddate, t1.annualpremiumamount, t1.memberinsuranceagreementcoveragestatuscode, t1.requestedcoveragebenefitamount, t1.coveragetypecode, t1.memberinsuranceagreementcoverageterminationreasoncode, t1.billfrequencypremiumamount, t1.annualizedpremiumamount, t1.premiumpaidtodate, t1.taxstatuscode, t1.subaccountnumber, t1.membercoverageportedindicator, t1.premiumpaidinadvancemonthcount, t1.waiverofpremiumcoverageindicator, t1.payrolldeductionamount, t1.premiumpaidtodateamount, t1.memberinsuranceagreementcoveragestatuschangedatetime, t1.outofforceindicator, t1.initialannualpremiumamount, t1.approvedcoveragebenefitamount, t1.lastupdatedatetime, t1.currentrecordindicator, t1.sourcesystemcode, t1.logicaldeleteindicator, t1.lastupdateuserid, t1.hivelastupdatetimestamp, t1.hashcode
FROM dev_core_group_plus.MemberInsuranceAgreementCoverage t1
INNER JOIN dev_publish_db_group_plus.InsuranceAgreement t2
ON  t1.scd_flag = true AND t1.memberinsuranceagreementnumber = t2.InsuranceAgreementNumber
AND t1.InsuranceAgreementTypeCode = t2.InsuranceAgreementTypeCode
AND t2.InsuranceAgreementTypeCode IN ('Individual Certificate', 'Group Certificate')
AND t1.internalcompanycode = t2.internalcompanycode
INNER JOIN dev_publish_db_group_plus.GroupAccount t4
ON t1.InternalCompanyCode = t4.InternalCompanyCode
AND t1.groupinsuranceagreementnumber = t4.SourceGNLGroupAccountNumber
INNER JOIN dev_publish_db_group_plus.ProductCoverage t3
ON t1.productcode = t3.productcoveragecode
limit 10000;