INSERT OVERWRITE TABLE dev_publish_db_group_plus.MemberInsuranceAgreement 
SELECT DISTINCT t1.insuranceagreementnumber, t1.internalcompanycode, t1.insuranceagreementtypecode, t1.groupinsuranceagreementnumber, t1.accountnumber, t1.sourcegnlparticipantid, t1.sourcegnlaccountnumber, t1.memberinsuranceagreementterminationreasoncode, t1.memberinsuranceagreementmodificationreasoncode, t1.memberclassificationname, t1.lastupdatedatetime, t1.currentrecordindicator, t1.sourcesystemcode, t1.logicaldeleteindicator, t1.lastupdateuserid, t1.hivelastupdatetimestamp, t1.hashcode 
FROM dev_core_group_plus.MemberInsuranceAgreement t1
INNER JOIN dev_publish_db_group_plus.InsuranceAgreement t2
ON t1.InsuranceAgreementNumber = t2.InsuranceAgreementNumber
AND t1.InsuranceAgreementTypeCode = t2.InsuranceAgreementTypeCode
AND t1.scd_flag = true
AND t2.InsuranceAgreementTypeCode='Individual Certificate'
INNER JOIN dev_publish_db_group_plus.GroupAccount t3
ON t1.InternalCompanyCode = t3.InternalCompanyCode
AND t1.AccountNumber = t3.SourceGNLGroupAccountNumber
INNER JOIN dev_publish_db_group_plus.Party t4
ON t1.sourcegnlparticipantid = t4.sourcegnlparticipantid
AND t1.AccountNumber = t4.sourcegnlgroupnumber
AND t4.SourceGNLAccountNumber = 0
and t4.SourceGNLDependentSequenceNumber = 0
limit 10000;