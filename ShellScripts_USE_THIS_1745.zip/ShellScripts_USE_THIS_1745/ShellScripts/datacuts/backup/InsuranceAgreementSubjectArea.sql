set hive.support.quoted.identifiers=none;


-- RUN AFTER PARTY -> GROUPACCOUNT
--Load Child Table GroupInsuranceAgreement
INSERT OVERWRITE TABLE dev_publish_db_group_plus.GroupInsuranceAgreement SELECT distinct t1.accountnumber, t1.insuranceagreementnumber, t1.internalcompanycode, t1.insuranceagreementtypecode, t1.eligibleemployeecount, t1.totalemployeecount, t1.issuedparticipantcount, t1.requiredemployeeparticipationpercentage, t1.groupinsuranceagreementterminationreasoncode, t1.groupinsuranceagreementmodificationreasoncode, t1.maximummonthsinvestigateanddenyclaimcount, t1.lastupdatedatetime, t1.currentrecordindicator, t1.sourcesystemcode, t1.logicaldeleteindicator, t1.lastupdateuserid, t1.hivelastupdatetimestamp, t1.hashcode FROM dev_core_group_plus.GroupInsuranceAgreement t1 INNER JOIN dev_core_group_plus.InsuranceAgreement t2 ON t1.InsuranceAgreementNumber = t2.InsuranceAgreementNumber AND t1.InternalCompanyCode = t2.InternalCompanyCode INNER JOIN dev_core_group_plus.GroupAccount t3 ON t1.AccountNumber = t3.SourceGNLGroupAccountNumber AND t1.InternalCompanyCode = t3.InternalCompanyCode WHERE t1.scd_flag = true limit 10000;

--Load Child Table InsuranceAgreement
INSERT OVERWRITE TABLE dev_publish_db_group_plus.InsuranceAgreement
SELECT distinct t1.accountnumber, t1.internalcompanycode, t1.insuranceagreementnumber, t1.insuranceagreementtypecode, t1.insuranceagreementeffectivedate, t1.insuranceagreementenddate, t1.signaturedate, t1.terminationdate, t1.renewaldate, t1.billingactivatedindicator, t1.insuranceagreementstatuscode, t1.issuestatecode, t1.originalissuedate, t1.issuedate, t1.insuranceagreementmodificationapprovaluserid, t1.currentrecordindicator, t1.sourcesystemcode, t1.logicaldeleteindicator, t1.insuranceagreementstatusdate, t1.lastupdateuserid, t1.lastupdatedatetime, t1.hivelastupdatetimestamp, t1.hashcode FROM dev_core_group_plus.InsuranceAgreement t1
INNER JOIN dev_publish_db_group_plus.GroupAccount t2
ON t1.InternalCompanyCode = t2.InternalCompanyCode
AND t1.AccountNumber = t2.SourceGNLGroupAccountNumber
WHERE t1.scd_flag = true;

--Load Child Table GroupInsuranceAgreementCoverage
INSERT OVERWRITE TABLE dev_publish_db_group_plus.GroupInsuranceAgreementCoverage SELECT distinct t1.insuranceagreementtypecode, t1.internalcompanycode, t1.accountnumber, t1.insuranceagreementnumber, t1.productcode, t1.groupinsuranceagreementcoverageeffectivedate, t1.groupinsuranceagreementcoverageenddate, t1.groupinsuranceagreementcoveragestatuscode, t1.groupinsuranceagreementcoverageterminationreasoncode, t1.minimumparticipationrequiredpercentage, t1.actualparticipationcount, t1.currentparticipationcount, t1.participationstatuscode, t1.coveredpartysettypecode, t1.lastupdatedatetime, t1.currentrecordindicator, t1.sourcesystemcode, t1.logicaldeleteindicator, t1.lastupdateuserid, t1.hivelastupdatetimestamp, t1.hashcode FROM dev_core_group_plus.GroupInsuranceAgreementCoverage t1 INNER JOIN dev_publish_db_group_plus.InsuranceAgreement t2 ON t1.InsuranceAgreementNumber = t2.InsuranceAgreementNumber AND t1.InternalCompanyCode = t2.InternalCompanyCode AND t1.InsuranceAgreementTypeCode = t2.InsuranceAgreementTypeCode AND t2.InsuranceAgreementTypeCode = 'Group Certificate' INNER JOIN dev_publish_db_group_plus.GroupAccount t3 ON t1.InternalCompanyCode = t3.InternalCompanyCode AND t1.AccountNumber = t3.SourceGNLGroupAccountNumber INNER JOIN dev_publish_db_group_plus.ProductCoverage t4 ON t1.productcode = t4.ProductCoveragecode AND t1.InternalCompanyCode = t4.InternalCompanyCode AND t1.scd_flag = true limit 10000;

--Load Child Table MemberInsuranceAgreement
INSERT OVERWRITE TABLE dev_publish_db_group_plus.MemberInsuranceAgreement 
SELECT DISTINCT t1.insuranceagreementnumber, t1.internalcompanycode, t1.insuranceagreementtypecode, t1.groupinsuranceagreementnumber, t1.accountnumber, t1.sourcegnlparticipantid, t1.sourcegnlaccountnumber, t1.memberinsuranceagreementterminationreasoncode, t1.memberinsuranceagreementmodificationreasoncode, t1.memberclassificationname, t1.lastupdatedatetime, t1.currentrecordindicator, t1.sourcesystemcode, t1.logicaldeleteindicator, t1.lastupdateuserid, t1.hivelastupdatetimestamp, t1.hashcode 
FROM dev_core_group_plus.MemberInsuranceAgreement t1
INNER JOIN dev_publish_db_group_plus.InsuranceAgreement t2
ON t1.InsuranceAgreementNumber = t2.InsuranceAgreementNumber
AND t1.InsuranceAgreementTypeCode = t2.InsuranceAgreementTypeCode
AND t1.scd_flag = true
AND t2.InsuranceAgreementTypeCode='Individual Certificate'
INNER JOIN dev_publish_db_group_plus.GroupAccount t3
ON t1.InternalCompanyCode = t3.InternalCompanyCode
AND t1.AccountNumber = t3.SourceGNLGroupAccountNumber
INNER JOIN dev_publish_db_group_plus.Party t4
ON t1.sourcegnlparticipantid = t4.sourcegnlparticipantid
AND t1.AccountNumber = t4.sourcegnlgroupnumber
AND t4.SourceGNLAccountNumber = 0
and t4.SourceGNLDependentSequenceNumber = 0
limit 10000;

--Load Child Table MemberInsuranceAgreementCoverage
INSERT OVERWRITE TABLE dev_publish_db_group_plus.MemberInsuranceAgreementCoverage
SELECT DISTINCT t1.memberinsuranceagreementnumber, t1.internalcompanycode, t1.insuranceagreementtypecode, t1.productcode, t1.groupinsuranceagreementnumber, t1.groupinsuranceagreementtypecode, t1.memberinsuranceagreementcoverageeffectivedate, t1.memberinsuranceagreementcoverageenddate, t1.annualpremiumamount, t1.memberinsuranceagreementcoveragestatuscode, t1.requestedcoveragebenefitamount, t1.coveragetypecode, t1.memberinsuranceagreementcoverageterminationreasoncode, t1.billfrequencypremiumamount, t1.annualizedpremiumamount, t1.premiumpaidtodate, t1.taxstatuscode, t1.subaccountnumber, t1.membercoverageportedindicator, t1.premiumpaidinadvancemonthcount, t1.waiverofpremiumcoverageindicator, t1.payrolldeductionamount, t1.premiumpaidtodateamount, t1.memberinsuranceagreementcoveragestatuschangedatetime, t1.outofforceindicator, t1.initialannualpremiumamount, t1.approvedcoveragebenefitamount, t1.lastupdatedatetime, t1.currentrecordindicator, t1.sourcesystemcode, t1.logicaldeleteindicator, t1.lastupdateuserid, t1.hivelastupdatetimestamp, t1.hashcode
FROM dev_core_group_plus.MemberInsuranceAgreementCoverage t1
INNER JOIN dev_publish_db_group_plus.InsuranceAgreement t2
ON t1.scd_flag = true AND t1.memberinsuranceagreementnumber = t2.InsuranceAgreementNumber
AND t1.InsuranceAgreementTypeCode = t2.InsuranceAgreementTypeCode
AND t2.InsuranceAgreementTypeCode IN ('Individual Certificate', 'Group Certificate')
AND t1.internalcompanycode = t2.internalcompanycode
INNER JOIN dev_publish_db_group_plus.GroupAccount t4
ON t1.InternalCompanyCode = t4.InternalCompanyCode
AND t1.groupinsuranceagreementnumber = t4.SourceGNLGroupAccountNumber
INNER JOIN dev_publish_db_group_plus.ProductCoverage t3
ON t1.productcode = t3.productcoveragecode
limit 10000;

--Load Child Table MemberInsuranceAgreementCoveredParty
INSERT OVERWRITE TABLE dev_publish_db_group_plus.MemberInsuranceAgreementCoveredParty
SELECT t1.`(start_date|end_date|scd_flag)?+.+` FROM dev_core_group_plus.MemberInsuranceAgreementCoveredParty t1
INNER JOIN dev_publish_db_group_plus.InsuranceAgreement t2
ON t1.MemberInsuranceAgreementNumber = t2.InsuranceAgreementNumber
AND t1.InternalCompanyCode = t2.InternalCompanyCode
AND t2.InsuranceAgreementTypeCode IN ('Individual Certificate')
AND t1.scd_flag = true
INNER JOIN dev_publish_db_group_plus.Party t4
ON t1.SourceGNLGroupNumber = t4.SourceGNLGroupNumber
AND t1.SourceGNLDependentSequenceNumber = t4.SourceGNLDependentSequenceNumber
AND t1.SourceGNLParticipantID = t4.SourceGNLParticipantID
AND t4.SourceGNLAccountNumber = 0
AND t1.SourceSystemCode = t4.SourceSystemCode
INNER JOIN dev_publish_db_group_plus.ProductCoverage t3
ON t1.ProductCode = t3.ProductCoveragecode
limit 10000;