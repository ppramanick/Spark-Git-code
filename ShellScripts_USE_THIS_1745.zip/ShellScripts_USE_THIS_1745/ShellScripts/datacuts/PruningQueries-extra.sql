--drop table dev_work_group_plus.accounttransaction purge;
--drop table dev_core_group_plus.accounttransaction purge;
--drop table dev_publish_db_group_plus.accounttransaction purge;

select count(*) from dev_publish_db_group_plus.accounttransaction;
select count(*) from dev_publish_db_group_plus.accountline;

select a.accountlinetype, count(*) FROM dev_publish_db_group_plus.AccountLine a 
WHERE a.accountlinetype in ('Bill Line','Payment Line','Claim Indemnification Line','Disbursement Line')
group by a.accountlinetype;

Payment Line	16395
Claim Indemnification Line	1331215
Bill Line	139430871
Disbursement Line	982699

select a.accountlinetype, count(*) FROM dev_publish_db_group_plus.AccountLine a 
inner join dev_publish_db_group_plus.AccountTransaction b 
on a.transactionnumber=b.transactionnumber 
inner join dev_publish_db_group_plus.BusinessAccount c 
on a.businessaccountnumber=c.businessaccountnumber 
WHERE a.accountlinetype in ('Bill Line','Payment Line','Claim Indemnification Line','Disbursement Line')
group by a.accountlinetype;

Payment Line	16181
Claim Indemnification Line	1331160
Disbursement Line	982672

select a.accountlinetype, count(*) FROM dev_core_group_plus.AccountLine a 
inner join dev_core_group_plus.AccountTransaction b 
on a.transactionnumber=b.transactionnumber 
--inner join dev_core_group_plus.BusinessAccount c 
--on a.businessaccountnumber=c.businessaccountnumber 
WHERE a.accountlinetype in ('Bill Line','Payment Line','Claim Indemnification Line','Disbursement Line')
and a.scd_flag = true group by a.accountlinetype;

Payment Line	16395
Claim Indemnification Line	1331215
Disbursement Line	982699

select a.accountlinetype, count(*) FROM dev_core_group_plus.AccountLine a 
--inner join dev_core_group_plus.AccountTransaction b 
--on a.transactionnumber=b.transactionnumber 
inner join dev_core_group_plus.BusinessAccount c 
on a.businessaccountnumber=c.businessaccountnumber 
WHERE a.accountlinetype in ('Bill Line','Payment Line','Claim Indemnification Line','Disbursement Line')
and a.scd_flag = true group by a.accountlinetype;

INSERT OVERWRITE TABLE dev_publish_db_group_plus.AccountLine SELECT distinct a.accountlinenumber, a.businessaccountnumber, a.transactionnumber, a.accountlinetype, a.internalcompanycode, a.accountlinedescription, a.accountlinetransactionprocessingdate, a.accountlinetransactioncreationdate, a.accountlinetransactionisreversedindicator, a.accountlinetransactionreversaldate, a.accountlineamount, a.accountlineunallocatedamount, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.AccountLine a inner join dev_publish_db_group_plus.AccountTransaction b on a.transactionnumber=b.transactionnumber inner join dev_publish_db_group_plus.BusinessAccount c on a.businessaccountnumber=c.businessaccountnumber WHERE a.accountlinetype = 'Payment Line' and scd_flag = true limit 25000;

INSERT INTO TABLE dev_publish_db_group_plus.AccountLine SELECT distinct a.accountlinenumber, a.businessaccountnumber, a.transactionnumber, a.accountlinetype, a.internalcompanycode, a.accountlinedescription, a.accountlinetransactionprocessingdate, a.accountlinetransactioncreationdate, a.accountlinetransactionisreversedindicator, a.accountlinetransactionreversaldate, a.accountlineamount, a.accountlineunallocatedamount, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.AccountLine a inner join dev_publish_db_group_plus.AccountTransaction b on a.transactionnumber=b.transactionnumber inner join dev_publish_db_group_plus.BusinessAccount c on a.businessaccountnumber=c.businessaccountnumber WHERE a.accountlinetype = 'Claim Indemnification Line' and scd_flag = true limit 25000;

INSERT INTO TABLE dev_publish_db_group_plus.AccountLine SELECT distinct a.accountlinenumber, a.businessaccountnumber, a.transactionnumber, a.accountlinetype, a.internalcompanycode, a.accountlinedescription, a.accountlinetransactionprocessingdate, a.accountlinetransactioncreationdate, a.accountlinetransactionisreversedindicator, a.accountlinetransactionreversaldate, a.accountlineamount, a.accountlineunallocatedamount, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.AccountLine a inner join dev_publish_db_group_plus.AccountTransaction b on a.transactionnumber=b.transactionnumber inner join dev_publish_db_group_plus.BusinessAccount c on a.businessaccountnumber=c.businessaccountnumber WHERE a.accountlinetype = 'Bill Line' and scd_flag = true limit 25000;

INSERT INTO TABLE dev_publish_db_group_plus.AccountLine SELECT distinct a.accountlinenumber, a.businessaccountnumber, a.transactionnumber, a.accountlinetype, a.internalcompanycode, a.accountlinedescription, a.accountlinetransactionprocessingdate, a.accountlinetransactioncreationdate, a.accountlinetransactionisreversedindicator, a.accountlinetransactionreversaldate, a.accountlineamount, a.accountlineunallocatedamount, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.AccountLine a inner join dev_publish_db_group_plus.AccountTransaction b on a.transactionnumber=b.transactionnumber inner join dev_publish_db_group_plus.BusinessAccount c on a.businessaccountnumber=c.businessaccountnumber WHERE a.accountlinetype = 'Disbursement Line' and scd_flag = true limit 25000;

INSERT OVERWRITE TABLE dev_publish_db_group_plus.Payment SELECT a.`(start_date|end_date|scd_flag)?+.+` FROM dev_core_group_plus.Payment a WHERE scd_flag = true limit 10000;


--Payment--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.Payment SELECT distinct a.paymentmethodtypecode, a.bankreceiveddate, a.paymentreceiveddate, a.paymentcanceledindicator, a.paymentcanceldate, a.paymentcancelreasoncode, a.paymentamount, a.paymentmethodnumber, a.paymentcleanindicator, a.paymentnumber, a.paymentreceiptnumber, a.initialpaymentindicator, a.accountownerpartyid, a.paymentbatchid, a.paymentbatchgroupingid, a.paymentchannelcode, a.processedaspaidandbilledindicator, a.submittedaspaidandbilledindicator, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode 
FROM dev_core_group_plus.Payment a inner join dev_core_group_plus.PaymentLine c on a.paymentnumber=c.paymentnumber 
--inner join dev_publish_db_group_plus.AccountLine b on c.accountlinenumber=b.accountlinenumber 
WHERE a.scd_flag = true;

select count(*) FROM dev_core_group_plus.PaymentLine a inner join dev_core_group_plus.Payment c on a.paymentnumber=c.paymentnumber;

select count(*) FROM dev_core_group_plus.PaymentLine a inner join (select * from dev_core_group_plus.Payment limit 1000000) b on a.paymentnumber=b.paymentnumber 
inner join dev_publish_db_group_plus.AccountLine c on a.accountlinenumber=c.accountlinenumber;

--Payment--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.Payment SELECT a.`(start_date|end_date|scd_flag)?+.+` FROM dev_core_group_plus.Payment a WHERE scd_flag = true;

--PaymentLine--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.PaymentLine SELECT distinct a.accountlinenumber, a.paymentnumber, a.accountlinetype, a.accountlineamount, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.PaymentLine a inner join dev_publish_db_group_plus.AccountLine b on a.accountlinenumber=b.accountlinenumber inner join dev_publish_db_group_plus.Payment c on a.paymentnumber=c.paymentnumber WHERE a.scd_flag = true;

--BillLine--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.BillLine SELECT distinct a.accountlinenumber, a.billnumber, a.billlineeffectivedate, a.billlineenddate, a.billlineisadjustmentindicator, a.billlineamountwithouttax, a.billlinepaidamount, a.billlinetransactionmonthstartdate, a.billlinereversalmonthstartdate, a.billlineunallocatedamount, a.billlinedaypriceamount, a.billlinegroupcontributionamount, a.billlinedaypricewithouttaxamount, a.billlinegroupcontributionwithouttaxamount, a.billlinemembercontributionamount, a.billlinemembercontributionwithouttaxamount, a.billlinestatuscode, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.productcoverageid, a.memberinsuranceagreementid, a.billlineamount, a.groupinsuranceagreementid, a.lastupdateuserid, a.lastupdatedatetime, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.BillLine a inner join dev_publish_db_group_plus.AccountLine b on a.accountlinenumber=b.accountlinenumber inner join dev_publish_db_group_plus.Bill c on a.billnumber=c.billnumber WHERE scd_flag = true limit 10000;

--ClaimLine--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.ClaimLine SELECT distinct a.accountlinenumber, a.claimnumber, a.deliveredservicename, a.federaltaxwithheldonlateclaiminterestamount, a.statetaxwithheldonlateclaiminterestamount, a.federaltaxwithheldonemployerpaidbenefitsamount, a.statetaxwithheldonemployerpaidbenefitsamount, a.federaltaxwithheldonsection125paidbenefitsamount, a.statetaxwithheldonsection125paidbenefitsamount, a.federaltaxwithheldonbenefitspaidtoprovideramount, a.statetaxwithheldonbenefitspaidtoprovideramount, a.lateclaiminterestpaymentamount, a.lateclaimpenaltypaymentamount, a.statetaxwithheldamount, a.federaltaxwithheldamount, a.childsupportliendisbursementamount, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.ClaimLine a inner join dev_publish_db_group_plus.AccountLine b on a.accountlinenumber=b.accountlinenumber inner join dev_publish_db_group_plus.Claim c ON a.claimnumber = c.claimnumber inner join dev_publish_db_group_plus.deliveredservice d on a.deliveredservicename=d.deliveredservicename WHERE scd_flag = true limit 10000;

--DisbursementLine--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.DisbursementLine SELECT distinct a.accountlinenumber, a.disbursementnumber, a.disbursementlinedistributiontargetcode, a.disbursementreasoncode, a.disbursementpartnumber, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.lastupdateprocessid, a.rowinsertdatetime, a.rowupdatedatetime, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.DisbursementLine a inner join dev_publish_db_group_plus.AccountLine b on a.accountlinenumber=b.accountlinenumber inner join dev_publish_db_group_plus.Disbursement c ON a.disbursementnumber = c.disbursementnumber WHERE scd_flag = true limit 10000;


select count(*) from dev_core_group_plus.Payment;
select count(*) from dev_publish_db_group_plus.Payment;
select count(*) from dev_core_group_plus.PaymentLine;
select count(*) from dev_publish_db_group_plus.PaymentLine;
select count(*) from dev_publish_db_group_plus.BillLine;
select count(*) from dev_publish_db_group_plus.ClaimLine;
select count(*) from dev_publish_db_group_plus.DisbursementLine;

select accounttransactiontypecode, count(*) from dev_publish_db_group_plus.AccountTransaction group by accounttransactiontypecode;

select accounttransactiontypecode, count(*) from dev_core_group_plus.AccountTransaction group by accounttransactiontypecode;

set hive.support.quoted.identifiers=none;

INSERT OVERWRITE TABLE dev_publish_db_group_plus.AccountTransaction 
SELECT a.`(start_date|end_date|scd_flag)?+.+` 
FROM dev_core_group_plus.AccountTransaction a 
WHERE scd_flag = true and accounttransactiontypecode = 'Bill' limit 10000;
INSERT INTO TABLE dev_publish_db_group_plus.AccountTransaction 
SELECT a.`(start_date|end_date|scd_flag)?+.+` 
FROM dev_core_group_plus.AccountTransaction a 
WHERE scd_flag = true and accounttransactiontypecode = 'Disbursement' limit 10000;
INSERT INTO TABLE dev_publish_db_group_plus.AccountTransaction 
SELECT a.`(start_date|end_date|scd_flag)?+.+` 
FROM dev_core_group_plus.AccountTransaction a 
WHERE scd_flag = true and accounttransactiontypecode = 'Payment' limit 60000;
INSERT INTO TABLE dev_publish_db_group_plus.AccountTransaction 
SELECT a.`(start_date|end_date|scd_flag)?+.+` 
FROM dev_core_group_plus.AccountTransaction a 
WHERE scd_flag = true and accounttransactiontypecode = 'Claim Regularization' limit 10000;




INSERT OVERWRITE TABLE dev_publish_db_group_plus.BusinessAccount 
SELECT distinct a.businessaccountowningpartyidgrp, a.businessaccountowningpartyidacct, a.businessaccountowningpartyidssn, 
a.internalcompanycode, a.businessaccountnumber, a.businessaccountcreatedate, a.businessaccounttypecode, 
a.businessaccountbalanceamount, a.businessaccountsuspendedbalanceamount, a.currentrecordindicator, a.sourcesystemcode, 
a.logicaldeleteindicator, a.lastupdateuserid, a.lastupdatedatetime, a.hivelastupdatetimestamp, a.hashcode 
from dev_core_group_plus.BusinessAccount a 
inner join dev_publish_db_group_plus.Party c 
on c.sourcegnlgroupnumber=a.businessaccountowningpartyidgrp 
and c.SourceGNLAccountNumber=a.businessaccountowningpartyidacct 
and c.SourceGNLParticipantID = '0000000000' 
AND c.sourcegnldependentsequencenumber = 0
inner join dev_publish_db_group_plus.AccountLine b
on a.businessaccountnumber=b.businessaccountnumber
inner join dev_publish_db_group_plus.AccountTransaction d 
on b.transactionnumber=d.transactionnumber  
WHERE b.accountlinetype in ('Bill Line','Payment Line','Claim Indemnification Line','Disbursement Line')
and a.scd_flag = true;

SELECT count(*) 
from dev_core_group_plus.BusinessAccount a 
inner join dev_publish_db_group_plus.Party c 
on c.sourcegnlgroupnumber=a.businessaccountowningpartyidgrp 
and c.SourceGNLAccountNumber=a.businessaccountowningpartyidacct 
and c.SourceGNLParticipantID = '0000000000' 
AND c.sourcegnldependentsequencenumber = 0
inner join dev_core_group_plus.AccountLine b
on a.businessaccountnumber=b.businessaccountnumber
inner join dev_publish_db_group_plus.AccountTransaction d 
on b.transactionnumber=d.transactionnumber  
WHERE b.accountlinetype in ('Bill Line','Payment Line','Claim Indemnification Line','Disbursement Line')
and a.scd_flag = true;

SELECT count(*) 
from dev_core_group_plus.BusinessAccount a 
inner join dev_publish_db_group_plus.Party c 
on c.sourcegnlgroupnumber=a.businessaccountowningpartyidgrp 
and c.SourceGNLAccountNumber=a.businessaccountowningpartyidacct 
and c.SourceGNLParticipantID = '0000000000' 
AND c.sourcegnldependentsequencenumber = 0 
WHERE scd_flag = true;

INSERT OVERWRITE TABLE dev_publish_db_group_plus.BusinessAccount 

select count(*) from (SELECT distinct a.businessaccountowningpartyidgrp, a.businessaccountowningpartyidacct, a.businessaccountowningpartyidssn, a.internalcompanycode, a.businessaccountnumber, a.businessaccountcreatedate, a.businessaccounttypecode, a.businessaccountbalanceamount, a.businessaccountsuspendedbalanceamount, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.lastupdatedatetime, a.hivelastupdatetimestamp, a.hashcode from dev_core_group_plus.BusinessAccount a inner join dev_publish_db_group_plus.Party c on c.sourcegnlgroupnumber=a.businessaccountowningpartyidgrp and c.SourceGNLAccountNumber=a.businessaccountowningpartyidacct and c.SourceGNLParticipantID = '0000000000' AND c.sourcegnldependentsequencenumber = 0 WHERE scd_flag = true) a; 

limit 200000;

SELECT * from dev_publish_db_group_plus.BusinessAccount limit 2;

INSERT INTO TABLE dev_publish_db_group_plus.BusinessAccount 
SELECT a.`(start_date|end_date|scd_flag)?+.+` 
FROM dev_core_group_plus.BusinessAccount a 
WHERE scd_flag = true;


INSERT OVERWRITE TABLE dev_publish_db_group_plus.SubAccountBusinessAccount SELECT distinct a.groupinsuranceagreementnumber, a.bussinessaccountnumber, a.subaccountnumber, a.internalcompanycode, a.businessaccounttype, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode from dev_core_group_plus.SubAccountBusinessAccount a inner join dev_publish_db_group_plus.BusinessAccount b on a.bussinessaccountnumber=b.businessaccountnumber and a.internalcompanycode=b.internalcompanycode inner join dev_publish_db_group_plus.SubAccount c on c.subaccountnumber=a.subaccountnumber WHERE scd_flag = true limit 10000;

select count(*) from dev_publish_db_group_plus.SubAccountBusinessAccount;

select 'claim' as table_name, count(*) from claim union all
select 'claimline' as table_name, count(*) from claimline union all
select 'deliveredservice' as table_name, count(*) from deliveredservice union all
select 'disbursement' as table_name, count(*) from disbursement union all
select 'disbursementline' as table_name, count(*) from disbursementline union all
select 'loss' as table_name, count(*) from loss;

select 'accountline' as table_name, count(*) from accountline union all
select 'accounttransaction' as table_name, count(*) from accounttransaction union all
select 'bill' as table_name, count(*) from bill union all
select 'billline' as table_name, count(*) from billline union all
select 'invoice' as table_name, count(*) from invoice union all
select 'payment' as table_name, count(*) from payment union all
select 'paymentline' as table_name, count(*) from paymentline;

--Claim--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.Claim SELECT distinct a.claimnumber, a.sourcegnlgroupnumber, a.sourcegnlparticipantid, a.sourcegnldependentsequencenumber, a.memberinsuranceagreementnumber, a.claimcreationdatetime, a.claimincurreddate, a.claimtotalbenefitamount, a.claimclosedate, a.claimexamineremployeenumber, a.claimapproveremployeenumber, a.claimnotetext, a.claimreceiveddate, a.claimdecisioncode, a.claimstatusreasoncode, a.claimstatustypecode, a.claimstatusdate, a.benefitchargednotcoveredamount, a.claimtreatmentdecisionreasoncode, a.claimoverpaymentamount, a.claimfeeamount, a.claimfeebudgetcenter, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.Claim a inner join dev_publish_db_group_plus.InsuranceAgreement b on a.memberinsuranceagreementnumber=b.insuranceagreementnumber inner join dev_publish_db_group_plus.Party c ON a.SourceGNLParticipantID = c.SourceGNLParticipantID AND a.SourceGNLGroupNumber = c.SourceGNLGroupNumber AND c.SourceGNLAccountNumber = 0 and a.SourceGNLDependentSequenceNumber = c.SourceGNLDependentSequenceNumber WHERE scd_flag = true limit 50000;

--Loss--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.Loss SELECT distinct a.claimnumber, a.sourcegnlgroupnumber, a.sourcegnlparticipantid, a.sourcegnldependentsequencenumber, a.lossname, a.lossdescriptorname, a.losseventname, a.lossclosedate, a.losschargeamount, a.lossfirstpathologycode, a.lossfirstpathologyfamilycode, a.losstypecode, a.losseventdate, a.lossnotificationdate, a.proofoflossdate, a.proofoflossindicator, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdatedatetime, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.Loss a inner join dev_publish_db_group_plus.Claim b on a.claimnumber=b.claimnumber inner join dev_publish_db_group_plus.Party c ON a.SourceGNLParticipantID = c.SourceGNLParticipantID AND a.SourceGNLGroupNumber = c.SourceGNLGroupNumber AND c.SourceGNLAccountNumber = 0 and a.SourceGNLDependentSequenceNumber = c.SourceGNLDependentSequenceNumber WHERE scd_flag = true limit 50000;

--Disbursement--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.Disbursement SELECT distinct a.disbursementoperationcode, a.sourcegnlgroupnumber, a.sourcegnlparticipantid, a.sourcegnldependentsequencenumber, a.disbursementamount, a.disbursementcreationdate, a.disbursementsentdate, a.disbursementcasheddate, a.disbursementcanceldate, a.disbursementmoneychannelcode, a.disbursementnumber, a.disbursementtypecode, a.disbursementcancelreasoncode, a.disbursementpaymentmethodcode, a.interestpaymentamount, a.disbursementstatuscode, a.backupwithholdingindicator, a.taxwithholdingamount, a.disbursementstatusdate, a.disbursementpaymentmethodnumber, a.disbursementrequestsourcesystemcode, a.backupwithholdingdate, a.backupwithholdingstopdate, a.backupwithholdingamount, a.disbursementcreationtime, a.disbursementpaymenttypecode, a.internalcompanycode, a.achreturncode, a.backupwithholdingremarkcode, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.Disbursement a inner join dev_publish_db_group_plus.Party c ON a.SourceGNLParticipantID = c.SourceGNLParticipantID AND a.SourceGNLGroupNumber = c.SourceGNLGroupNumber AND c.SourceGNLAccountNumber = 0 and c.SourceGNLDependentSequenceNumber = 0 WHERE scd_flag = true limit 50000;

--DeliveredService--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.DeliveredService SELECT distinct a.beneficiarypartyid, a.productcoverageid, a.deliveredservicename, a.claimnumber, a.lossname, a.sourcegnlgroupnumber, a.sourcegnlparticipantid, a.sourcegnldependentsequencenumber, a.internalcompanycode, a.insuranceagreementtypecode, a.insuranceagreementnumber, a.lossprocedurecode, a.deliveredservicecanceledflag, a.deliveredservicereasoncode, a.deliveredservicetypecode, a.memberinsuranceagreementcoverageeffectivedate, a.deliveredservicedate, a.deliveredservicedecisionreasoncode, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.DeliveredService a inner join dev_publish_db_group_plus.InsuranceAgreement b on a.InsuranceAgreementNumber = b.InsuranceAgreementNumber and a.InternalCompanyCode = b.InternalCompanyCode and a.InsuranceAgreementTypeCode = b.InsuranceAgreementTypeCode and b.InsuranceAgreementTypeCode = 'Individual Certificate' inner join dev_publish_db_group_plus.Party c ON a.SourceGNLParticipantID = c.SourceGNLParticipantID AND a.SourceGNLGroupNumber = c.SourceGNLGroupNumber AND c.SourceGNLAccountNumber = 0 and a.SourceGNLDependentSequenceNumber = c.SourceGNLDependentSequenceNumber inner join dev_publish_db_group_plus.Loss d on a.claimnumber=d.claimnumber and a.lossname=d.lossname WHERE scd_flag = true limit 50000;

--ClaimLine--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.ClaimLine SELECT distinct a.accountlinenumber, a.claimnumber, a.deliveredservicename, a.federaltaxwithheldonlateclaiminterestamount, a.statetaxwithheldonlateclaiminterestamount, a.federaltaxwithheldonemployerpaidbenefitsamount, a.statetaxwithheldonemployerpaidbenefitsamount, a.federaltaxwithheldonsection125paidbenefitsamount, a.statetaxwithheldonsection125paidbenefitsamount, a.federaltaxwithheldonbenefitspaidtoprovideramount, a.statetaxwithheldonbenefitspaidtoprovideramount, a.lateclaiminterestpaymentamount, a.lateclaimpenaltypaymentamount, a.statetaxwithheldamount, a.federaltaxwithheldamount, a.childsupportliendisbursementamount, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.ClaimLine a inner join dev_publish_db_group_plus.AccountLine b on a.accountlinenumber=b.accountlinenumber inner join dev_publish_db_group_plus.Claim c ON a.claimnumber = c.claimnumber inner join dev_publish_db_group_plus.deliveredservice d on a.deliveredservicename=d.deliveredservicename WHERE scd_flag = true limit 10000;

--DisbursementLine--
INSERT OVERWRITE TABLE dev_publish_db_group_plus.DisbursementLine SELECT distinct a.accountlinenumber, a.disbursementnumber, a.disbursementlinedistributiontargetcode, a.disbursementreasoncode, a.disbursementpartnumber, a.lastupdatedatetime, a.currentrecordindicator, a.sourcesystemcode, a.logicaldeleteindicator, a.lastupdateuserid, a.lastupdateprocessid, a.rowinsertdatetime, a.rowupdatedatetime, a.hivelastupdatetimestamp, a.hashcode FROM dev_core_group_plus.DisbursementLine a inner join dev_publish_db_group_plus.AccountLine b on a.accountlinenumber=b.accountlinenumber inner join dev_publish_db_group_plus.Disbursement c ON a.disbursementnumber = c.disbursementnumber WHERE scd_flag = true limit 10000;


