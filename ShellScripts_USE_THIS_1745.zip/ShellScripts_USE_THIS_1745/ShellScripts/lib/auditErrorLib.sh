#!/bin/bash
#************************************************#
#              auditErrorLib.sh
#
#                Oct 2017
#
#           All audit/error log, shared functions
#           for all Data Lake scripts
#           Requires SharedFunctions.sh
#************************************************#

#************************************************************************
#
#                      Variables
#
#************************************************************************
# Staging
StagingTotalNumberOfRows="cf:stgTot"
SourceLocationName="cf:srcLoc"
StagingValidatedRows="cf:stgVal"
StagingFailureRows="cf:stgFail"
WorkValidatedRows="cf:wrkVal"
WorkFailureRows="cf:wrkFail"
StagingProcessStartDateTime="cf:stgSDt"
StagingProcessEndDateTime="cf:stgEDt"
StagingProcessRunTimeMs="cf:stgRt"
StagingValidationStartDateTime="cf:stgValSDt"
StagingValidationEndDateTime="cf:stgValEDt"
StagingToArchiveStartDateTime="cf:stgArcSDt"
StagingToArchiveEndDateTime="cf:stgArcEDt"
StagingToArchiveRunTimeMs="cf:stgArcRt"
StagingToWorkStartDateTime="cf:stgWrkSDt"
StagingToWorkEndDateTime="cf:stgWrkEDt"
StagingtoWorkRunTimeMs="cf:stgWrkRt"
StagingTableName="cf:stgTbl"
SourceTableName="cf:srcTbl"
SourceSystemName="cf:srcSys"
StagingProcessName="cf:stgProc"
StagingValidationProcessName="cf:stgValProc"
StagingToArchiveProcessName="cf:stgArcProc"
StagingToWorkProcessName="cf:stgWrkProc"
WorkTableName="cf:wrkTbl"
StagingToWorkLastImport="cf:stgWrkThrs"
StagingProcessUserId="cf:stgId"
WorkTotalNumberOfRows="cf:wrkTot"
StagingtoWorkValidationRunTimeInMs="cf:stgWrkValRt"

# CSV
SourceFileSize="cf:srcSize"
LandingFileSize="cf:lanSize"
LandingFileHashTotal="cf:lanHash"
SourceFileDateTime="cf:srcFDt"
LandingProcessStartDateTime="cf:lanSDt"
LandingProcessEndDateTime="cf:lanEDt"
LandingToArchiveStartDateTime="cf:lanArcSDt"
LandingToArchiveEndDateTime="cf:lanArcSEt"
LandingToWorkStartDateTime="cf:lanWrkSDt"
LandingToWorkEndDateTime="cf:lanWrkEDt"
LandingFileName="cf:lanFile"
LandingFileLocation="cf:lanFLoc"
LandingProcessName="cf:lanProc"
LandingToArchiveProcessName="cf:lanArcProc"
LandingToWorkProcessName="cf:lanWrkProc"
LandingProcessUserId="cf:lanId"
LandingProcessRunTimeMs="cf:lanRt"
LandingToWorkRunTimeMs="cf:lanWrkRt"
LandingToWorkValidationRunTimeInMs="cf:lanWrkValRt"
LandingMismatchRatio="cf:lanMmRat"
# Work->Core
WorkTotalNumberOfRows="cf:wrkTot"
WorkProcessStartDateTime="cf:wrkSDt"
WorkProcessEndDateTime="cf:wrkEDt"
WorkValidationStartDateTime="cf:wrkValSDt"
WorkValidationEndDateTime="cf:wrkValEDt"
WorkMappingStartDateTime="cf:wrkTranSDt"
WorkMappingEndDateTime="cf:wrkTranEDt"
WorkCDCStartDateTime="cf:wrkCdcSDt"
WorkCDCStartEndDateTime="cf:wrkCdcEDt"
WorkToCoreStartDateTime="cf:wrkCdcSDt"
WorkToCoreEndDateTime="cf:wrkCdcEDt"
PublishTableName="cf:pubTbl"
CoreTableName="cf:coreTbl"
WorkTableName="cf:wrkTbl"
WorkProcessName="cf:wrkProc"
WorkValidationProcessName="cf:wrkValProc"
WorkMappingProcessName="cf:wrkTranProc"
WorkCDCProcessName="cf:wrkCdcProc"
WorkToCoreProcessName="cf:wrkCorePrc"
WorkProcessUserId="cf:wrkCoreId"
WorkProcessRunTimeMs="cf:wrkRt"
WorkMappingRunTimeMs="cf:wrkTranRt"
WorkCDCRunTimeMs="cf:wrkCdcRt"
# Core
CoreToPublishStartDateTime="cf:corePubSDt"
CoreToPublishEndDateTime="cf:corePubEDt"
CoreProcessName="cf:coreProc"
CoreProcessStartDateTime="cf:coreSDt"
CoreProcessEndDateTime="cf:coreEDt"
PublishTotalNumberOfRows="cf:pubTot"
CoreTotalNumberOfRows="cf:coreTot"
CoreFailureRows="cf:coreFailTot"
CoreToPublishProcessName="cf:corePubProc"
PublishProcessUserId="cf:corePubId"
CoreToPublishRunTimeInMs="cf:corePubRt"
WorkToPubValidationRunTimeInMs="cf:wrkPubValRt"
# General
PublishDatabaseName="cf:pubDb"
CoreDatabaseName="cf:coreDb"
WorkDatabaseName="cf:wrkDb"
StagingDatabaseName="cf:stgDb"
SourceDatabaseName="cf:srcDb"

# Error logging
DataLakeIngestionStartDateTime="cf:inSDt"
DataLakeIngestionFailureDateTime="cf:inEDt"
FailureCode="cf:fCd"
FailureDescription="cf:fDec"
FailureProcessName="cf:fProc"
FailureZone="cf:fZone"
YarnApplicationId="cf:yarn"
FailureSqlScript="cf:fSql"
FailureDatabase="cf:fDb"
FailureTable="cf:fTbl"
FailureFunction="cf:fStp"
RowsAffected="cf:rws"
ErrorLevel="cf:lvl"
FailureLogFilePath="cf:log"
FailureLogMessage="cf:logmsg"
FailureTimestampsAffected="cf:fTsAf"
FailureAuditLinkKey="cf:fAdLKy"

# Error constants
ERR_NO_SQOOP_DATA_IMPORTED="ERR_NO_SQOOP_DATA_IMPORTED"
ERR_NO_WATERMARK_DROP="ERR_NO_WATERMARK_DROP"
ERR_SQOOP_SANITY="ERR_SQOOP_SANITY"
ERR_METADATA_FAILURE="ERR_METADATA_FAILURE"
ERR_HASH_FAILURE="ERR_HASH_FAILURE"
ERR_FULL_IMPORT_FAILURE="ERR_FULL_IMPORT_FAILURE"
ERR_ARCHIVE="ERR_ARCHIVE"
ERR_DDL="ERR_DDL"
ERR_INTERRUPT="ERR_INTERRUPT"
ERR_PUBLISH_FAILURE="ERR_PUBLISH_FAILURE"
ERR_TRANSFORM_FAILURE="ERR_TRANSFORM_FAILURE"
ERR_CDC_FAILURE="ERR_CDC_FAILURE"

# Verification constants
VER_ARCHIVE="VER_ARCHIVE"
VER_CDC="VER_CDC"
VER_SQOOP="VER_SQOOP"
VER_PUB="VER_PUB"
VER_PK_MISMATCH="VER_PK_MISMATCH"
VER_INVALID_DATA="VER_INVALID_DATA"
VER_DATA_MISMATCH="VER_DATA_MISMATCH"

# Error Levels
LOG_INFO="INFO"
LOG_WARN="WARN"
LOG_ERROR="ERROR"
LOG_FATAL="FATAL"

debug_testRow="cf:debug"

AUDIT_TABLE="audit"
ERROR_TABLE="errorlog"
# Default global vars to 0
procStartTime=0
procStopTime=0
procTime=0
verTime=0
# Init key
keydt=$(date +"%d-%m-%yT%H:%M:%S")
ERROR_ITERATOR=0
LINK_KEY=

# Used for verifying data types in table
PERF_LIMIT=1000
MISMATCH_THRESHOLD=2

#************************************************************************
#
#                      General audit
#
#************************************************************************

auditSetStartTime(){
  perfStartTime=$(date +%s%N | cut -b1-13)
}
auditSetStopTime(){
  perfStopTime=$(date +%s%N | cut -b1-13)
}
auditSetVerStartTime(){
  verStartTime=$(date +%s%N | cut -b1-13)
}
auditSetVerStopTime(){
  verStopTime=$(date +%s%N | cut -b1-13)
}
auditSetProcStartTime(){
   procStartTime=$(date +%s%N | cut -b1-13)
   printAudit "Process start time is ${procStartTime}"
}
auditSetProcStopTime(){
   procStopTime=$(date +%s%N | cut -b1-13)
   printAudit "Process end time is ${procStartTime}"
}

#--------------------------------------------------------------------
# Calculates time passed since an execution
# Parameter: N/A
# Returns: Sets to global var. ${perfTimeMs} in ms
#---------------------------------------------------------------------
auditGetPerfTime(){
  perfTime=$((${perfStopTime} - ${perfStartTime}))
  printAudit "Sub-process runtime: ${perfTime} ms"
}

#--------------------------------------------------------------------
# Calculates time passed since an execution for a sub-process
# Parameter: N/A
# Returns: Sets to global var. ${perfTimeMs} in ms
#---------------------------------------------------------------------
auditGetProcTime(){
  procTime=$((${procStopTime} - ${procStartTime}))
  printAudit "Full process runtime: ${procTime} ms"
}

#--------------------------------------------------------------------
# Calculates time passed since a verfication; as there are multiple, the total is a sum of all verifications
# Parameter: N/A
# Returns: Sets to global var. ${verTime} in ms
#---------------------------------------------------------------------
auditSumVerTime(){
  auditSetVerStopTime
  tVerTime=$((${verStopTime} - ${verStartTime}))
  verTime=$((${verTime} + ${tVerTime}))
  printAudit "Current verification runtime: ${verTime} ms"
}

#************************************************************************
#
#                      Function specific
#
#************************************************************************

#--------------------------------------------------------------------
# Prepares an HBase PUT batch using prepareRow for this script
# Parameter: (col) (val); ${AUDIT_SYSTEM},${HIVE_TABLE},${AUDIT_TABLE} needs to be set
# Returns: Appends to global var. ${PUT}
#---------------------------------------------------------------------
auditSetRow(){
  col=$1
  val=$2
  prepareRow ${AUDIT_SYSTEM} ${col} "${val}" ${HIVE_TABLE} ${AUDIT_TABLE}
}

#--------------------------------------------------------------------
# Prepares an audit row with epoch to datetime
# Parameter: (col) (val)
# Returns: N/A
#---------------------------------------------------------------------
auditPutTimeRow(){
  col=$1
  val=$2
  time=$(date -d @$((${val}/1000)) "+%Y-%m-%d %H:%M:%S")
  printAudit "Putting time row ${time} in col ${col}"
  auditSetRow ${col} "${time}"
}

#************************************************************************
#
#                      HBase
#
#************************************************************************

#--------------------------------------------------------------------
# Prepares an HBase PUT batch for Hbase table HBASE_TABLE
# Parameter: (system) (col) (val) (tbl) (HBASE_TABLE)
# Returns: Appends to global var. ${PUT}
#---------------------------------------------------------------------
prepareRow(){
  system=$1
  col=$2
  val=$3
  hiveTbl=$4
  HBASE_TABLE=$5

  if [ "${HBASE_TABLE}" == "${ERROR_TABLE}" ]; then
    getErrorKey ${system} ${hiveTbl}
  else
    getKey ${system} ${hiveTbl}
  fi

  printAudit "Appending value $3 in col $2 for row ${hbaseKey} to HBase table ${HBASE_TABLE} put batch..."
  PUT=${PUT}"put '${HBASE_TABLE}','${hbaseKey}','${col}','${val}'\n"
}

#--------------------------------------------------------------------
# Runs multiple HBase PUT commands
# Parameter: N/A
# Returns: Resets global var ${PUT}
#---------------------------------------------------------------------
batchRows(){
  if [ -z "${PUT}" ]; then
    printAudit "No audit rows were captured yet, not flushing to HBase"
    return 0
  fi

  printAudit "Running current PUT batch..."
  echo -e ${PUT} | hbase shell

  if [[ $? -eq 0 ]]; then
    printAudit "Hbase put successful"
  else
    printErr "Hbase put not successful!"
  fi

  PUT=
}

#--------------------------------------------------------------------
# Generates the HBase key
# Parameter: N/A
# Returns: Resets global var ${hbaseKey}
#---------------------------------------------------------------------
getKey(){
  system=$1
  hiveTbl=$2

  hbaseKey=${keydt}"_"${hiveTbl}"_"${system}
}

#--------------------------------------------------------------------
# Generates the HBase key for the Error table
# Parameter: N/A
# Returns: Resets global var ${hbaseErrorKey}
#---------------------------------------------------------------------
getErrorKey(){
  system=$1
  hiveTbl=$2

  hbaseKey=${keydt}"_"${hiveTbl}"_"${system}"_"${ERROR_ITERATOR}
}

#************************************************************************
#
#                      Error log specific
#
#************************************************************************

#--------------------------------------------------------------------
# Counts records two tables and compares them
# Parameter: $DATABASE_LEFT $TABLE_LEFT $DATABASE_RIGHT $TABLE_RIGHT (scd: left/right/all)
# Returns: ${COUNT_SANITY} is 0 (success) or diff (failure)
#---------------------------------------------------------------------
sanityCheck(){
  DATABASE_LEFT=$1
  TABLE_LEFT=$2
  DATABASE_RIGHT=$3
  TABLE_RIGHT=$4
  SCD=$5

  if [[ ! -z "${SCD}" ]]; then
    if [ "${SCD}" == "left" ]; then
      getTableCount ${DATABASE_LEFT} ${TABLE_LEFT} "true"
      LEFT_COUNT=${TBLCOUNT}
      getTableCount ${DATABASE_RIGHT} ${TABLE_RIGHT}
      RIGHT_COUNT=${TBLCOUNT}
    elif [[ "${SCD}" == "right" ]]; then
      getTableCount ${DATABASE_LEFT} ${TABLE_LEFT}
      LEFT_COUNT=${TBLCOUNT}
      getTableCount ${DATABASE_RIGHT} ${TABLE_RIGHT} "true"
      RIGHT_COUNT=${TBLCOUNT}
    else
      getTableCount ${DATABASE_LEFT} ${TABLE_LEFT} "true"
      LEFT_COUNT=${TBLCOUNT}
      getTableCount ${DATABASE_RIGHT} ${TABLE_RIGHT} "true"
      RIGHT_COUNT=${TBLCOUNT}
    fi
  else
      getTableCount ${DATABASE_LEFT} ${TABLE_LEFT}
      LEFT_COUNT=${TBLCOUNT}
      getTableCount ${DATABASE_RIGHT} ${TABLE_RIGHT}
      RIGHT_COUNT=${TBLCOUNT}
  fi

  if [ ${RIGHT_COUNT} -ne ${LEFT_COUNT} ]; then
    COUNT_SANITY=$((${RIGHT_COUNT}-${LEFT_COUNT}))
    COUNT_SANITY=$(echo ${COUNT_SANITY} | tr -d -)
    printErr "Comparing ${DATABASE_LEFT}.${TABLE_LEFT} with ${DATABASE_RIGHT}.${TABLE_RIGHT} resulted in a diff of: ${COUNT_SANITY}"
  else
    COUNT_SANITY=0
    log "${DATABASE_LEFT}.${TABLE_LEFT} and ${DATABASE_RIGHT}.${TABLE_RIGHT} have an identical count, successs"
  fi
}

#--------------------------------------------------------------------
# Prepares an HBase PUT batch using prepareRow for this script
# Parameter: (col) (val); ${ERROR_SYSTEM},${HIVE_TABLE},${ERROR_TABLE} needs to be set
# Returns: Appends to global var. ${PUT}
#---------------------------------------------------------------------
errorSetRow(){
  col=$1
  val=$2
  val=$(echo "${val}" | sed -e "s/'/\"/g")
  prepareRow ${ERROR_SYSTEM} ${col} "${val}" ${HIVE_TABLE} ${ERROR_TABLE}
}

#--------------------------------------------------------------------
# Prepares an HBase BINARY PUT batch using prepareRow for this script
# Parameter: (col) (val); ${ERROR_SYSTEM},${HIVE_TABLE},${ERROR_TABLE} needs to be set
# Returns: Appends to global var. ${PUT}
#---------------------------------------------------------------------
errorSetBinaryRow(){
  col=$1
  val=$(echo "${val}" | sed -e "s/'/\"/g")
  val="Bytes.toBytes('${val}')"

  getKey ${ERROR_SYSTEM} ${HIVE_TABLE}

  printAudit "Appending value ${val} in col ${col} for row ${hbaseKey} to HBase table ${HBASE_TABLE} put batch..."
  PUT=${PUT}"put '${HBASE_TABLE}','${hbaseKey}','${col}',${val}\n"
}

#--------------------------------------------------------------------
# Prepares an HBase PUT batch for Error logging
# Parameter: 1. ${FailureDescription}; 2. ${FailureProcessName}; 3. ${FailureZone}; 4. ${YarnApplicationId};
# 5. ${FailureSqlScript}; 6. ${FailureDatabase}; 7. ${FailureTable}; 8. ${RowsAffected}; 9. ${ErrorLevel};
# 10. ${FailureLogFilePath}; 11. ${FailureLogMessage}; 12. ${DataLakeIngestionStartDateTime}; 13. ${FailureTimestampsAffected}
# Returns: Appends to global var. ${PUT}
#---------------------------------------------------------------------
logError(){
  F_DESC=$1
  F_PROC=$2
  F_ZONE=$3
  F_YARN=$4
  F_SQL=$5
  F_DB=$6
  F_TBL=$7
  F_ROWS=$8
  F_LEVEL=$9
  F_LOG=${10}
  F_MSG=${11}
  F_STIME=${12}
  F_TS_AFF=${13}

  if [[ -z "${F_TS_AFF}" ]]; then
    F_TS_AFF="0"
  fi

  if [ -z "${LINK_KEY}" ]; then
    LINK_KEY=${keydt}"_"${HIVE_TABLE}"_"${AUDIT_SYSTEM}
  fi

  ftime=$(date "+%Y-%m-%d %H:%M:%S")
  F_STIME=$(date -d @$((${F_STIME}/1000)) "+%Y-%m-%d %H:%M:%S")

  ERROR_ITERATOR=$((ERROR_ITERATOR+1))

  errorSetRow ${DataLakeIngestionFailureDateTime} "${ftime}"
  errorSetRow ${FailureDescription} "${F_DESC}"
  errorSetRow ${FailureProcessName} "${F_PROC}"
  errorSetRow ${FailureZone} "${F_ZONE}"
  errorSetRow ${YarnApplicationId} "${F_YARN}"
  errorSetRow ${FailureSqlScript} "${F_SQL}"
  errorSetRow ${FailureDatabase} "${F_DB}"
  errorSetRow ${FailureTable} "${F_TBL}"
  errorSetRow ${RowsAffected} "${F_ROWS}"
  errorSetRow ${ErrorLevel} "${F_LEVEL}"
  errorSetRow ${FailureLogFilePath} "${F_LOG}"
  errorSetRow ${FailureLogMessage} "${F_MSG}"
  errorSetRow ${FailureTimestampsAffected} "${F_TS_AFF}"
  errorSetRow ${FailureCode} 0
  errorSetRow ${FailureProcessName} "${SCRIPT_NAME}"
  errorSetRow ${DataLakeIngestionStartDateTime} "${F_STIME}"
  errorSetRow ${FailureAuditLinkKey} "${LINK_KEY}"
}

#--------------------------------------------------------------------
# Called using trap on SIGINT, SIGQUIT, SIGABRT, SIGALRM, SIGTERM
# Parameter: (col) (val); ${ERROR_SYSTEM},${HIVE_TABLE},${ERROR_TABLE} needs to be set
# Returns: Appends to global var. ${PUT}
#---------------------------------------------------------------------
interrupt(){
  printErr "Process got interrupted!"
  logError "${ERR_INTERRUPT}" "${SCRIPT_NAME}->${FUNCNAME[0]}" "N/A" "N/A" "N/A" "${HIVE_DATABASE}" "${HIVE_TABLE}" "-1" "${LOG_ERROR}" "${HDFS_LOG_FILE}" "N/A" "${procStartTime}"
  cleanup
}

#--------------------------------------------------------------------
# Greps for "error" and "exception" on ${LOCAL_LOG_DIR}
# Parameter: $log_dir (optional, defaults to ${LOCAL_LOG_DIR})
# Returns: Sets global var ${errs}
#---------------------------------------------------------------------
grepErrorLogs(){
  ERROR_LOG_DIR_GREP=$1
  if [ -z ${ERROR_LOG_DIR_GREP} ]; then
    ERROR_LOG_DIR_GREP=${LOCAL_LOG_DIR}
  fi
  errs=$(grep -E -i "error|exception" ${ERROR_LOG_DIR_GREP} | grep -v "Duplicate" | grep -v "Appending value" )
  errs=$(echo "${errs}" | sed ':a;N;$!ba;s/\n/; /g' )
}

#--------------------------------------------------------------------
# Gets the latest YARN application_id from the logs
# Parameter: $log_dir (optional, defaults to ${LOCAL_LOG_DIR})
# Returns: Sets global var ${yarnId}
#---------------------------------------------------------------------
getYarnApplicationId(){
  ERROR_LOG_DIR_GREP=$1
  if [ -z ${ERROR_LOG_DIR_GREP} ]; then
    ERROR_LOG_DIR_GREP=${LOCAL_LOG_DIR}
  fi

  yarnId=$(grep "Executing on YARN cluster with App id " ${LOCAL_LOG_DIR}  |  sed 's/^.* //' | sed 's/)//' | tail -1)
}

#--------------------------------------------------------------------
# Gets the max(hivelastupdatetimestamp)
# Parameter: ${DATABASE} ${TABLE}
# Returns: Sets global var ${maxlastimporttimestamp}
#---------------------------------------------------------------------
getMaxHiveLastUpdateTimestamp(){
  maxlastimporttimestamp=$(beeline --showHeader=false --outputformat=csv2 --silent=true -u "${BEELINE_CONN_HIVE}" -n ${USER_NAME} -e "SELECT max(hivelastupdatetimestamp) FROM $1.$2")
}

#--------------------------------------------------------------------
# Checks if columns that include a NOT NULL comment are NULL; includes hashcode and hivelastupdatetimestamp
# Parameter: ${DATABASE} ${TABLE}
# Returns: Sets global var ${nullMismatch}
#---------------------------------------------------------------------
verifyTableNullDefinitions(){
  var=$(beeline --showHeader=false --outputformat=csv2 -u ${BEELINE_CONN_HIVE} -n ${USER_NAME}  -e "DESC $1.$2")

  # Extract columns as list, filter NOT NULL add static NOT NULL columns
  cols=$(echo -e "${var}" | grep -i "NOT NULL" |  cut --delimiter=, --fields=1,2 --output-delimiter=,)
  cols=$(echo -e "$cols" | sed -r 's/(varchar|VARCHAR)\(([0-9]{0,5})\)/string/g')
  cols="${cols},\nhivelastupdatetimestamp,timestamp,\nhashcode,string"

  # Build query
  COLLIST=$(echo -e "${cols}" | cut --delimiter=, --fields=1 --output-delimiter=\n)
  query="SELECT COUNT(*) FROM ${1}.${2} WHERE "
  INC=1
  for COL in ${COLLIST}
  do
    query=${query}" ${COL} IS NULL OR"
    query=${query}" ${COL} =\"\" OR"
    INC=$[$INC + 1]
  done
  query=${query}" (1=1);"
  query=$(echo -e "${query}" | sed 's/OR (1=1)//g')

  # Check mismatched NULLs
  nullMismatch=$(beeline --showHeader=false --outputformat=csv2 -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} -e "${query}")
}

#--------------------------------------------------------------------
# Checks if a table matches the given data types; ensures not shifts in columns (e.g., CSV) occur
# Accounts for a certain number of nullable columns; max difference between projected
# and actual data type is controlled by ${MISMATCH_THRESHOLD}
# Parameter: ${DATABASE} ${TABLE}
# Returns: Sets global var ${mismatchRatio} and ${mismatchRatioIsBelowThreshold} (1=true,0=false)
#---------------------------------------------------------------------
verifyTableColumnTypes(){
  printDebug "Verifying column types for $1.$2"
  var=$(beeline --showHeader=false --outputformat=csv2 -u ${BEELINE_CONN_HIVE} -n ${USER_NAME}  -e "DESC $1.$2")
  printDebug echo "$var"
  # Extract columns as list, filter NOT NULL add static NOT NULL columns
  cols=$(echo -e "${var}" | cut --delimiter=, --fields=1,2 --output-delimiter=,)
  cols=$(echo -e "$cols" | sed -r 's/(varchar|VARCHAR)\(([0-9]{0,5})\)/string/g')
  cols="${cols},\nhivelastupdatetimestamp,timestamp,\nhashcode,string"

  # VERIFY DATA TYPES
  #mts=$(beeline --showHeader=false --outputformat=csv2 -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} -e "select max(hivelastupdatetimestamp) from $1.$2")
  # Build query
  COLDTLIST=$(echo -e "${cols}" | cut --delimiter=, --fields=1,2 --output-delimiter=,)
  query="create temporary macro isNumber(s string) cast(s as double) is not null; "
  query="${query}create temporary macro isBool(s string) s like 'true' or s like 'false'; "
  query="${query}create temporary macro isDate(s string) cast(s as date) is not null; "
  query="${query}create temporary macro isTS(s string) cast(s as timestamp) is not null; "
  query="${query}WITH tmp AS ( "
  query="${query}SELECT explode(split(CONCAT_WS('-'"
  INC=1
  for COL in ${COLDTLIST}
  do
    col=$(echo -e "${COL}" | cut --delimiter=, --fields=1 --output-delimiter=,)
    dataType=$(echo -e "${COL}" | cut --delimiter=, --fields=2 --output-delimiter=,)

	printDebug "COL - ${COL}"
	printDebug "col - ${col}"
	printDebug "dataType - ${dataType}"

    if [ ! -z $(echo "${dataType}" | grep -E -i 'double|int') ]; then
      query="${query},CAST(isNumber(CAST(${col} AS STRING)) AS STRING)"
    elif [ ! -z $(echo "${dataType}" | grep -i 'date') ]; then
      query="${query},CAST(isDate(CAST(${col} AS STRING)) AS STRING)"
    elif [ ! -z $(echo "${dataType}" | grep -i 'timestamp') ]; then
      query="${query},CAST(isTS(CAST(${col} AS STRING)) AS STRING)"
    elif [ ! -z $(echo "${dataType}" | grep -i 'boolean') ]; then
      query="${query},CAST(isBool(CAST(${col} AS STRING)) AS STRING)"
    fi

    INC=$[$INC + 1]
  done
 # query="${query}),'-')) as trveCount FROM $1.$2 WHERE hivelastupdatetimestamp='${mts}' LIMIT ${PERF_LIMIT}) "
  query="${query}),'-')) as trveCount FROM $1.$2 LIMIT ${PERF_LIMIT}) "
  query="${query}select count(1),trveCount from tmp group by trveCount;"
  #query=$(echo -e "${query}" | sed 's/),/)/g')

  printDebug "QUERY"
  printDebug "${query}"

  # Run query
  mismatches=$(beeline --showHeader=false --outputformat=csv2 -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} -e "${query}")

  printDebug "${mismatches}"
  trueCount=$(echo -e "${mismatches}" | grep "TRUE" | cut --delimiter=, --fields=1 --output-delimiter=,)
  falseCount=$(echo -e "${mismatches}" | grep "FALSE" | cut --delimiter=, --fields=1 --output-delimiter=,)

  if [ -z "${trueCount}" ]; then
    trueCount=0
  fi
  if [ -z "${falseCount}" ]; then
    falseCount=-1
  fi

  if [ ${falseCount} -eq 0 ] | [ ${falseCount} -eq -1 ] ; then
    # No wrong values, falseCount can be equal to THRESHOLD
    mismatchRatio=9999
  else
    mismatchRatio=$(bc -l <<< "${trueCount}/${falseCount}")

    if [[ $? -ne 0 ]]; then
      # Div 0 exception
	  mismatchRatio=9999
    fi
  fi

  printDebug "Mismatch ratio for $1.$2 is ${mismatchRatio}"

  mismatchRatioIsBelowThreshold=$(bc -l <<< "${mismatchRatio} >= ${MISMATCH_THRESHOLD}")
}