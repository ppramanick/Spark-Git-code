#!/bin/bash
#************************************************#
#              SharedFunctions.sh
#
#                Oct 2017
#
#           All generic, shared functions for
#           all Data Lake scripts
#************************************************#

ZONE_STAGING="staging"
ZONE_LANDING="landing"
ZONE_WORK="work"
ZONE_CORE="core"
ZONE_PUBLISH="publish"
ZONE_ARCHIVE="archive"

#************************************************************************
#
#                      GENERAL
#
#************************************************************************

#--------------------------------------------------------------------
# Prints a log statement
# Parameter: (message) (level: DEBUG,INFO,ERROR,AUDIT)
# Returns: N/A
#--------------------------------------------------------------------
log(){
  lvl=$2
  if [ -z "${lvl}" ]; then
   lvl="INFO"
  fi

  lts=$(date +%FT%T.%3N)
  if [ "${lvl}" == "ERROR" ]; then
    #echo ${lts} ${lvl} $$ "-" "$1" >&2
    >&2 echo ${lvl} $$ "-" "$1"
  elif [ "${lvl}" == "AUDIT" ] || [ "${lvl}" == "DEBUG" ]; then
    echo ${lvl} $$ "-" "$1"
  else
    #echo ${lts} ${lvl} $$ "-" "$1"
    echo $$ "-" "$1"
  fi
}

#--------------------------------------------------------------------
# Prints an error
# Parameter: Error message
# Returns: N/A
#--------------------------------------------------------------------
printErr(){
  log "$1" "ERROR"
}

#--------------------------------------------------------------------
# Prints an audit message
# Parameter: Error message
# Returns: N/A
#--------------------------------------------------------------------
printAudit(){
  log "$1" "AUDIT"
}

#--------------------------------------------------------------------
# Prints a debug message
# Parameter: Error message
# Returns: N/A
#--------------------------------------------------------------------
printDebug(){
  log "$1" "DEBUG"
}


#************************************************************************
#
#                      FS and HDFS FUNCTIONS
#
#************************************************************************

#--------------------------------------------------------------------
# Checks if a directory exists
# Parameter: Dir
# Returns: exits script if not
#--------------------------------------------------------------------
checkDir(){
  if [ ! -f $1 ]; then
  	printErr "Error: $1 doesn't exist!"
  	batchRows
  	exit 1
  fi
}

#--------------------------------------------------------------------
# Checks if a HDFS directory exists
# Parameter:  ${HDFS_Dir} ${CreateIfNotExists}
# Returns: exits script if not
#--------------------------------------------------------------------
checkHdfsDir(){
  x=$(hdfs dfs -ls $1)
  if [ $? -ne 0 ]; then
    if [ -z $2 ]; then
  	  printErr "Error: $1 doesn't exist!"
  	  batchRows
  	  exit 1
  	else
  	  log "Creating dir $1..."
  	  hdfs dfs -mkdir -p $1
  	fi
  fi
}

#************************************************************************
#
#                      TABLE MANAGEMENT
#
#************************************************************************

#--------------------------------------------------------------------
# Checks if a table exits
# Parameter: N/A
# Returns: 0 if true, != 0 if not
#--------------------------------------------------------------------
tableExists(){
  var=$(beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME}  -e "SELECT * FROM  $1.$2 LIMIT 1")
  return $?
}

#--------------------------------------------------------------------
# Reads column names from a table, formats as CSV w/o data types, filters out ${EXCLUDE_COLUMNS}
# Parameter: ${DATABASE} ${TABLE} ${EXCLUDE_OVERWRITE}
# Returns: 0 if execution was successful, != 0 otherwise; pipes out ${COLUMNS}
#---------------------------------------------------------------------
readColNames(){
  COLUMNS=
  var=$(beeline --showHeader=false --outputformat=csv2 -u ${BEELINE_CONN_HIVE} -n ${USER_NAME}  -e "DESCRIBE $1.$2")

  # Extract columns as list
  cols=$(echo "$var" | cut --delimiter=, --fields=1 --output-delimiter=, )
  cols=$(echo "$cols" | sed 's/, /,/g ')

  # This extends the static EXCLUDE columns from the table_properties by zone specific values
  EXCLUDE_OVERWRITE=$3
  EXCLUDE_COLUMNS=${EXCLUDE_OVERWRITE}","${EXCLUDE_COLUMNS}",#,Partition,Information,#,col_name"

  COLLIST=$(echo ${cols} | tr "," "\n")
  EXCLUDE_LIST=$(echo ${EXCLUDE_COLUMNS} | tr "," "\n")
  INC=1
  for COL in ${COLLIST}
  do
    #log -e "Checking ${COL}\n"
    contains=$( echo -e "${EXCLUDE_LIST}" | grep -i "${COL}" )
    if [ -z "${contains}" ]; then
      COLUMNS=${COLUMNS}","${COL}
      COLUMNS_CAST=${COLUMNS_CAST}",CAST("${COL}" AS STRING)"
    else
     continue
    fi

    INC=$[$INC + 1]
  done

  COLUMNS=$(echo "${COLUMNS}" | sed '$!s/$/,/' )
  COLUMNS=$(echo "${COLUMNS}" | sed 's/,//1' )

  COLUMNS_CAST=$(echo "${COLUMNS_CAST}" | sed '$!s/$/,/' )
  COLUMNS_CAST=$(echo "${COLUMNS_CAST}" | sed 's/,//1' )

  echo -e "${COLUMNS}"

  return $?
}

#--------------------------------------------------------------------
# Checks if a table exists; creates it otherwise
# Parameter: ${DATABASE} ${TABLE} (${DDL} / optional)
# Returns: N/A
#---------------------------------------------------------------------
checkCreateTable(){
  iDB=$1
  iTable=$2
  DDL=$3
  if [ -z ${DDL} ]; then
    DDL="../DDL/${iTable}_ddl.sql"
  fi
  iTable=${iTable}
  log "Checking table ${iDB}.${iTable}..."
  var=$(beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} -e "SELECT * FROM  ${iDB}.${iTable} LIMIT 1")
  bashReturn=$?
  if [ ${bashReturn} -ne 0 ]; then
      if [ ! -f ${DDL} ]; then
      	printErr "Error: ${DDL} doesn't exist, cannot create table!"
      	batchRows
      	exit 1
      fi
      log "Creating table ${iDB}.${iTable}..."
      dos2unix ${DDL}
      beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} \
      --hivevar DATABASE=${iDB} \
      --hivevar WORK_DATABASE=${iDB} \
      --hivevar CORE_DATABASE=${iDB} \
  	  --hivevar TABLE=${iTable} \
      --hivevar TBLPATH=${TBLPATH} \
      --verbose=true \
      -f ${DDL} #&> ${HIVE_LOGS}

      if [ $? -ne 0 ]; then
  	    printErr "checkCreateTable failed, please check the logs"
  	    batchRows
  	    exit 1
      fi
  else
      log "Table ${iDB}.${iTable} already exists..."
  fi
}

#--------------------------------------------------------------------
# Checks if a table exists; creates it otherwise
# Parameter: ${WORK_DATABASE} ${CORE_DATABASE} ${CHECK_DB} ${TABLE} ${DDL}
# Returns: N/A
#---------------------------------------------------------------------
checkCreateTableWithDDL(){
  iWORK_DATABASE=$1
  iCORE_DATABASE=$2
  CHECK_DB=$3
  iTable=$4
  DDL=$5

  log "Checking table ${iDB}.${iTable}..."
  var=$(beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} -e "SELECT * FROM  ${CHECK_DB}.${iTable} LIMIT 1")
  bashReturn=$?
  if [ ${bashReturn} -ne 0 ]; then
      if [ ! -f ${DDL} ]; then
      	printErr "Error: ${DDL} doesn't exist, cannot create table!"
      	batchRows
      	exit 1
      fi
      log "Creating table ${iDB}.${iTable}..."
      beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} \
      --hivevar WORK_DATABASE=${iWORK_DATABASE} \
      --hivevar CORE_DATABASE=${iCORE_DATABASE} \
  	  --hivevar TABLE=${iTable} \
      --hivevar TBLPATH=${TBLPATH} \
      --verbose=true \
      -f ${DDL} #&> ${HIVE_LOGS}

      if [ $? -ne 0 ]; then
  	    printErr "checkCreateTableWithDDL failed, please check the logs"
  	    batchRows
  	    exit 1
      fi
  else
      log "Table ${iDB}.${iTable} already exists..."
  fi
}


#--------------------------------------------------------------------
# Dynamically generates a partitioned DDL based on an existing table
# Parameter: $(BASE_DB} ${BASE_TABLE} ${TARGET_DB} ${PARTITION} ${execute}
# e.g., createdDDL (staging_db) (table) (archive_db) CY(STRING) true
# WARNING: TRUNCATES COMMENTS AND VARCHAR OR DOUBLE LENGTH
# Returns: 0 if DDL execution was successful, != 0 otherwise
#---------------------------------------------------------------------
createDDL(){
  BASE_DB=$1
  BASE_TABLE=$2
  TARGET_DB=$3
  PARTITION=$4
  execute=$5
  var=$(beeline --showHeader=false --outputformat=csv2 -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} -e "DESCRIBE ${BASE_DB}.${BASE_TABLE}")

  # Replace comments
  var=$(echo "$var" | cut --delimiter=, --fields=1,2 --output-delimiter=, )
  # Replace odd format of describe
  # Remove Parenthesis
  var=$(echo "$var" | sed -e 's/(.*)\(.*\)/\1/g' )

  # TODO: change hard coded data types to dynamic reference
  var=$(echo "$var" | sed -e 's/,string/ string/g')
  var=$(echo "$var" | sed -e 's/,varchar/ string/g')
  var=$(echo "$var" | sed -e 's/,char/ string/g')
  var=$(echo "$var" | sed -e 's/,bigint/ bigint/g')
  var=$(echo "$var" | sed -e 's/,int/ int/g')
  var=$(echo "$var" | sed -e 's/,tinyint/ tinyint/g')
  var=$(echo "$var" | sed -e 's/,smallint/ smallint/g')
  var=$(echo "$var" | sed -e 's/,double/ double/g')
  var=$(echo "$var" | sed -e 's/,decimal(.*/ double/g')
  var=$(echo "$var" | sed -e 's/,numeric/ numeric/g')
  var=$(echo "$var" | sed -e 's/,timestamp/ timestamp/g')
  var=$(echo "$var" | sed -e 's/,date/ date/g')
  var=$(echo "$var" | sed -e 's/,interval/ interval/g')
  var=$(echo "$var" | sed -e 's/,boolean/ boolean/g')
  var=$(echo "$var" | sed -e 's/,binary/ binary/g')
  var=$(echo "$var" | sed '1 s/$/,/; 1! s/$/,/' )
  var=$(echo "$var" | sed -e '$s/\(.*\),/\1 /')

  # Generate DDL dynamically w/ partition CY
  DDL="SET hive.exec.dynamic.partition.mode = nonstrict;\nCREATE DATABASE IF NOT EXISTS ${TARGET_DB};\n"
  DDL=${DDL}"CREATE TABLE IF NOT EXISTS ${TARGET_DB}.${BASE_TABLE}\n("
  DDL=${DDL}${var}")\n"
  DDL=${DDL}"PARTITIONED BY ${PARTITION};"

  # Dynamically creates DDL
  DDL_PATH=../DDL/${BASE_TABLE}_part_ddl.sql
  echo -e "${DDL}" > ${DDL_PATH}

  if [ ! -z "${execute}" ]; then
    log "Executing DDL ${DDL_PATH}"
    res=$(beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} -f ${DDL_PATH})
    return $?
  else
    printDebug "Skipping DDL execution for ${DDL_PATH}"
    return 0
  fi
}

#--------------------------------------------------------------------
# Takes a table's DDL, changes BUCKET to partition, writes back
# Parameters: ${DATABASE} ${table} ${PARTITION} ${execute}
# Returns: 0 if successful, != 0 if not; Sets global variable ${PART_DDL}
#---------------------------------------------------------------------
transformTableToPartition(){
  db=$1
  table=$2
  part=$3
  execute=$4
  DDL_PATH="../DDL/${table}_ddl.sql"
  DDL_PATH_PART="../DDL/${table}_part_ddl.sql"
  dos2unix ${DDL_PATH}
  PART_DDL=$(cat ${DDL_PATH})

  PART_DDL=$(echo -e "${PART_DDL}" | sed '1s/^/SET hive.exec.dynamic.partition.mode = nonstrict;\n/')
  PART_DDL=$(echo -e "${PART_DDL}" | sed 's/INTO .* BUCKETS//g')
  PART_DDL=$(echo -e "${PART_DDL}" | sed "/CLUSTERED BY/c\PARTITIONED BY ${part}")
  echo -e "${PART_DDL}" > ${DDL_PATH_PART}

  if [ ! -z "${execute}" ]; then
    log "Executing DDL ${DDL_PATH_PART}"
    res=$(beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} -f ${DDL_PATH_PART} --hivevar DATABASE=${db} --hivevar WORK_DATABASE=${db} )
    return $?
  else
    printDebug "Skipping DDL execution for ${DDL_PATH_PART}"
    return 0
  fi
}



#--------------------------------------------------------------------
# Drops a Hive table with a return code
# Parameter: N/A
# Returns: 0 if successful, != 0 if not
#---------------------------------------------------------------------
dropTableWithReturn(){
  # Check if the table exists
  returnCode=$(beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME}  -e "SELECT * FROM  $1.$2 LIMIT 1")
  returnCode=$?

  if [ ${returnCode} == "0" ]; then
   log "Dropping table ${HIVE_DATABASE}.${DROP_TABLE}"
  	beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME}  -e "DROP TABLE $1.$2 PURGE;"
    beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME}  -e "DROP TABLE $1.$2_temp PURGE;"
  fi
  return returnCode
}

#--------------------------------------------------------------------
# Drops a Hive table w/o a return code
# Parameter: N/A
# Returns: N/A
#---------------------------------------------------------------------
dropTable(){
  log "Dropping table $1.$2"
  beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME}  -e "DROP TABLE IF EXISTS $1.$2 PURGE;"
}

#--------------------------------------------------------------------
# DEBUG FUNCTION: Truncates a Hive table w/o a return code
# Parameter: N/A
# Returns: N/A
#---------------------------------------------------------------------
truncateTable(){
  log "Truncating table $1.$2"
  beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME}  -e "TRUNCATE TABLE $1.$2;"
}

#************************************************************************
#
#                      CDC
#
#************************************************************************

#--------------------------------------------------------------------
# Reads last hivelastupdatetimestamp for limiting CDC
# Parameter: $DATABASE $TABLE
# Returns: ${LAST_CDC_TS} is set
#---------------------------------------------------------------------
readLastCdcTs(){

  QUERY="select COALESCE(max(hivelastupdatetimestamp),cast(from_unixtime(0) as timestamp)) from $1.$2"

  LAST_CDC_TS=$(beeline --showHeader=false --outputformat=csv2 -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} -e "${QUERY}")

  if [ -z "${LAST_CDC_TS}" ] | [ "${LAST_CDC_TS}" = "NULL" ]; then
    LAST_CDC_TS="1969-12-31 19:00:00"
  fi

  log ${LAST_CDC_TS}
}


#--------------------------------------------------------------------
# Counts records in a table
# Parameter: $DATABASE $TABLE (optional: scd)
# Returns: ${TBLCOUNT} is set
#---------------------------------------------------------------------
getTableCount(){

  QUERY="select count(*) from $1.$2"

  if [ "$#" -ge 3 ]; then
    QUERY=${QUERY}" where scd_flag=true"
  fi

  TBLCOUNT=$(beeline --showHeader=false --outputformat=csv2 -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} -e "${QUERY}")

  if [ -z "${TBLCOUNT}" ]; then
    TBLCOUNT=0
  fi

  log "$1.$2 has ${TBLCOUNT} records"
}

#--------------------------------------------------------------------
# Adds scd columns (scd_flag, start_date, end_date) to a table
# Parameter: ${DATABASE} ${TABLE}
# Returns: N/A
#---------------------------------------------------------------------
addScdColumns(){
  # Add columns
  log "Adding SCD columns to $1.$2"
  beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME}  \
  --hivevar DATABASE=$1 \
  --hivevar TABLE=$2 \
  --force=true \
  --verbose=true \
  -f "../SQL/addScdCols.sql" #&> ${HIVE_LOGS}
}

#--------------------------------------------------------------------
# Generates variables for SQL execution
# Parameter: N/A
# Returns: N/A
#---------------------------------------------------------------------
prepareSql(){
  log "Preparing SQL..."
  PKLIST=$(echo ${PRIMARY_KEYS} | tr "," "\n")
  INC=1
  for PK in ${PKLIST}
  do
    CONDITION="t1.$PK = t2.$PK AND "
    CONDITION2="t2.$PK IS NULL AND "
    JOIN_CONDITIONS="$JOIN_CONDITIONS$CONDITION"
    EXCLUDE_CONDITIONS="$EXCLUDE_CONDITIONS$CONDITION2"

    ALIAS_CONDITION="t1.${PK} = t2.TablePK$INC AND "
    ALIAS_CONDITION2="t2.TablePK$INC IS NULL AND "

    ALIAS_JOIN="$ALIAS_JOIN$ALIAS_CONDITION"
    ALIAS_EXCLUDE="$ALIAS_EXCLUDE$ALIAS_CONDITION2"

    SELECT_CONDITION="${PK} AS TablePK$INC, "
    MULTI_SELECT_CONDITION="${MULTI_SELECT_CONDITION}${SELECT_CONDITION}"

    INC=$[$INC + 1]
  done

  ALIAS_JOIN=${ALIAS_JOIN%?????}
  ALIAS_EXCLUDE=${ALIAS_EXCLUDE%?????}
  MULTI_SELECT_CONDITION_TRIMED=${MULTI_SELECT_CONDITION%??}

  AND_CHOP=${JOIN_CONDITIONS%?????}
  EXCLUDE_CONDITIONS=${EXCLUDE_CONDITIONS%?????}
}

#--------------------------------------------------------------------
# Generates variables for SQL execution w/ exclude statements
# Parameter: N/A
# Returns: N/A
#---------------------------------------------------------------------
prepareSqlWithExclude(){
  log "Preparing SQL..."
  PKLIST=$(echo ${PRIMARY_KEYS} | tr "," "\n")
  INC=1
  for PK in ${PKLIST}
  do
    CONDITION="t1.$PK = t2.$PK AND "
    CONDITION2="t2.$PK IS NULL AND "
    JOIN_CONDITIONS="$JOIN_CONDITIONS$CONDITION"
    EXCLUDE_CONDITIONS="$EXCLUDE_CONDITIONS$CONDITION2"

    ALIAS_CONDITION="t1.${PK} = t2.TablePK$INC AND "
    ALIAS_CONDITION2="t2.TablePK$INC IS NULL AND "

    ALIAS_JOIN="$ALIAS_JOIN$ALIAS_CONDITION"
    ALIAS_EXCLUDE="$ALIAS_EXCLUDE$ALIAS_CONDITION2"

    SELECT_CONDITION="${PK} AS TablePK$INC, "
    MULTI_SELECT_CONDITION="${MULTI_SELECT_CONDITION}${SELECT_CONDITION}"

    INC=$[$INC + 1]
  done

   # Build exclude conditions
   EXCLUDE_COLUMN_LIST=$(echo ${EXCLUDE_COLUMNS} | tr "," "\n")
   INC=1
   EXCLUDE_COLUMNS_T=""
   for EC in ${EXCLUDE_COLUMN_LIST}
   do
     EXCLUDE_COLUMNS_T=${EXCLUDE_COLUMNS_T}"t2.${EC},"
     INC=$[$INC + 1]
   done

  ALIAS_JOIN=${ALIAS_JOIN%?????}
  ALIAS_EXCLUDE=${ALIAS_EXCLUDE%?????}
  MULTI_SELECT_CONDITION_TRIMED=${MULTI_SELECT_CONDITION%??}

  JOIN_CONDITIONS=${JOIN_CONDITIONS%?????}
  EXCLUDE_CONDITIONS=${EXCLUDE_CONDITIONS%?????}
  EXCLUDE_COLUMNS_T=$(echo ${EXCLUDE_COLUMNS_T} | sed 's/.$//' )

  # Static exclude values
  EXCLUDE_COLUMNS=${EXCLUDE_COLUMNS}",hivelastupdatetimestamp"
  # Replace comma w/ pipe for exclude query
  EXCLUDE_COLUMNS_REGEX=$(echo ${EXCLUDE_COLUMNS} | sed -e 's/,/|/g')
  # Add hashcode, otherwise the SELECT returns an invalid col no
  EXCLUDE_COLUMNS_REGEX=${EXCLUDE_COLUMNS_REGEX}"|hashcode"
  EXCLUDE_COLUMNS_T=${EXCLUDE_COLUMNS_T}",t2.hivelastupdatetimestamp"
}

#--------------------------------------------------------------------
# Calculates hash codes used for CDC
# Parameter: $DATABASE $TABLE; requires ${SQL_HASH} to be set
# $PRIMARY_KEYS, $COLUMNS need to be set
# Returns: Exits with 1 if not successful
#---------------------------------------------------------------------
calculateHashCodes(){
  log "Using columns ${COLUMNS} for hash-generation..."
  log "${COLUMNS_CAST}"
  log "Computing Hashcode for loaded records..."
  log "PRIMARY_KEYS = ${PRIMARY_KEYS}"

  beeline -u ${BEELINE_CONN_HIVE} -n ${USER_NAME}  \
  --hivevar DATABASE=$1 \
  --hivevar TABLE=$2 \
  --hivevar PK=${PRIMARY_KEYS} \
  --hivevar COLUMNS="${COLUMNS}" \
  --hivevar COLUMNS_CAST="${COLUMNS_CAST}" \
  --verbose=true \
  -f ${SQL_HASH} #&> ${HIVE_LOGS}

  if [ $? -ne 0 ]; then
    printErr "Error: Hash not successful"
    batchRows
    exit 1
  else
    log "Full row hash completed for $1.$2"
  fi
}

setEnvironment(){
  # Get environment setting
  if [ -z "${ENVIRONMENT}" ]; then
    ENVIRONMENT="dev"
  fi

  if [ -z "${NAMESERVICE}" ]; then
    NAMESERVICE="AFLACHADDEV"
  fi

  # Uppercase
  ENVIRONMENT=$(echo ${ENVIRONMENT} | awk '{print toupper($0)}')
  NAMESERVICE=$(echo ${NAMESERVICE} | awk '{print toupper($0)}')
}

#--------------------------------------------------------------------
# Gets a kerberos ticket for service accounts
# Parameter: N/A
# Returns: N/A
#---------------------------------------------------------------------
initKerberos(){
  case "${USER_NAME}" in
   "genel-hadoop-d-user")
       kinit -kt genelco-user.headless.keytab genel-hadoop-d-user@NT.LAB.COM
       ;;
   "wflw-hadoop-d-user")
       kinit -kt wflw-user.headless.keytab wflw-hadoop-d-user@NT.LAB.COM
       ;;
   "pmc-hadoop-d-user")
       kinit -kt pmc-user.headless.keytab pmc-hadoop-d-user@NT.LAB.COM
       ;;
   "cds-hadoop-d-user")
       kinit -kt cds-user.headless.keytab cds-hadoop-d-user@NT.LAB.COM
       ;;
   "genel-hadoop-s-user")
       # SYST starts
       kinit -kt genelco-user.headless.keytab genel-hadoop-s-user@NT.LAB.COM
       ;;
   "wflw-hadoop-s-user")
       kinit -kt wflw-user.headless.keytab wflw-hadoop-s-user@NT.LAB.COM
       ;;
   "pmc-hadoop-s-user")
       kinit -kt pmc-user.headless.keytab pmc-hadoop-s-user@NT.LAB.COM
       ;;
   "cds-hadoop-s-user")
       kinit -kt cds-user.headless.keytab cds-hadoop-s-user@NT.LAB.COM
       ;;
   *)
       echo "Not using keytab, user is ${USER_NAME}"
       ;;
   esac
}