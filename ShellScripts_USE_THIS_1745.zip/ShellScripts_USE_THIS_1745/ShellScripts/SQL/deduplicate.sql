set hive.support.quoted.identifiers=none;
set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx12288m -XX:NewRatio=8;
set tez.am.resource.memory.mb=6144;

-- Deduplicate
WITH tmp AS (
  SELECT t1.*, ROW_NUMBER() OVER (PARTITION BY hashcode ORDER BY hivelastupdatetimestamp DESC) AS row_num
  FROM ${DB}.${TABLE}_stg t1
)
INSERT OVERWRITE TABLE ${DB}.${TABLE}_stg
SELECT `(t.row_num|row_num)?+.+`
FROM tmp t
WHERE t.row_num = 1;

--Drop temporary table
--DROP TABLE IF EXISTS ${DB}.${TABLE}_temp;

-- Beeline
SELECT * FROM ${DB}.${TABLE}_stg WHERE 1=0 LIMIT 1;
