create database dev_stage_pmc   ;
create database dev_stage_fscd  ;

create database dev_work_pmc    ;
create database dev_work_fscd   ;

create database dev_core_pmc    ;
create database dev_core_fscd   ;

create database dev_publish_pmc ;
create database dev_publish_fscd;

-- PM&C
CREATE TABLE dev_work_pmc.Producer                                 LIKE  dev_work_group_plus.Producer                                       ;
CREATE TABLE dev_work_pmc.ProducerWritingNumber                    LIKE  dev_work_group_plus.ProducerWritingNumber                          ;
CREATE TABLE dev_work_pmc.MemberInsuranceAgreementCoverageProducer LIKE  dev_work_group_plus.MemberInsuranceAgreementCoverageProducer       ;
CREATE TABLE dev_work_pmc.Commission                               LIKE  dev_work_group_plus.Commission                                     ;
CREATE TABLE dev_work_pmc.CommissionLine                           LIKE  dev_work_group_plus.CommissionLine                                 ;

CREATE TABLE dev_core_pmc.Producer                                 LIKE  dev_core_group_plus.Producer                                       ;
CREATE TABLE dev_core_pmc.ProducerWritingNumber                    LIKE  dev_core_group_plus.ProducerWritingNumber                          ;
CREATE TABLE dev_core_pmc.MemberInsuranceAgreementCoverageProducer LIKE  dev_core_group_plus.MemberInsuranceAgreementCoverageProducer       ;
CREATE TABLE dev_core_pmc.Commission                               LIKE  dev_core_group_plus.Commission                                     ;
CREATE TABLE dev_core_pmc.CommissionLine                           LIKE  dev_core_group_plus.CommissionLine                                 ;

CREATE TABLE dev_publish_pmc.Producer                                 LIKE dev_publish_db_group_plus.Producer                                 ;
CREATE TABLE dev_publish_pmc.ProducerWritingNumber                    LIKE dev_publish_db_group_plus.ProducerWritingNumber                    ;
CREATE TABLE dev_publish_pmc.MemberInsuranceAgreementCoverageProducer LIKE dev_publish_db_group_plus.MemberInsuranceAgreementCoverageProducer ;
CREATE TABLE dev_publish_pmc.Commission                               LIKE dev_publish_db_group_plus.Commission                               ;
CREATE TABLE dev_publish_pmc.CommissionLine                           LIKE dev_publish_db_group_plus.CommissionLine                           ;

INSERT OVERWRITE TABLE dev_work_pmc.Producer                                 SELECT * FROM dev_work_group_plus.Producer                                 ;
INSERT OVERWRITE TABLE dev_work_pmc.ProducerWritingNumber                    SELECT * FROM dev_work_group_plus.ProducerWritingNumber                    ;
INSERT OVERWRITE TABLE dev_work_pmc.MemberInsuranceAgreementCoverageProducer SELECT * FROM dev_work_group_plus.MemberInsuranceAgreementCoverageProducer ;
INSERT OVERWRITE TABLE dev_work_pmc.Commission                               SELECT * FROM dev_work_group_plus.Commission                               ;
INSERT OVERWRITE TABLE dev_work_pmc.CommissionLine                           SELECT * FROM dev_work_group_plus.CommissionLine                           ;
                  
INSERT OVERWRITE TABLE dev_core_pmc.Producer                                 SELECT * FROM dev_core_group_plus.Producer                                 ;
INSERT OVERWRITE TABLE dev_core_pmc.ProducerWritingNumber                    SELECT * FROM dev_core_group_plus.ProducerWritingNumber                    ;
INSERT OVERWRITE TABLE dev_core_pmc.MemberInsuranceAgreementCoverageProducer SELECT * FROM dev_core_group_plus.MemberInsuranceAgreementCoverageProducer ;
INSERT OVERWRITE TABLE dev_core_pmc.Commission                               SELECT * FROM dev_core_group_plus.Commission                               ;
INSERT OVERWRITE TABLE dev_core_pmc.CommissionLine                           SELECT * FROM dev_core_group_plus.CommissionLine                           ;

INSERT OVERWRITE TABLE dev_publish_pmc.Producer                                 SELECT * FROM dev_publish_db_group_plus.Producer                                 ;
INSERT OVERWRITE TABLE dev_publish_pmc.ProducerWritingNumber                    SELECT * FROM dev_publish_db_group_plus.ProducerWritingNumber                    ;
INSERT OVERWRITE TABLE dev_publish_pmc.MemberInsuranceAgreementCoverageProducer SELECT * FROM dev_publish_db_group_plus.MemberInsuranceAgreementCoverageProducer ;
INSERT OVERWRITE TABLE dev_publish_pmc.Commission                               SELECT * FROM dev_publish_db_group_plus.Commission                               ;
INSERT OVERWRITE TABLE dev_publish_pmc.CommissionLine                           SELECT * FROM dev_publish_db_group_plus.CommissionLine                           ;

DROP TABLE dev_work_group_plus.Producer                                ;
DROP TABLE dev_work_group_plus.ProducerWritingNumber                   ;
DROP TABLE dev_work_group_plus.MemberInsuranceAgreementCoverageProducer;
DROP TABLE dev_work_group_plus.Commission                              ;
DROP TABLE dev_work_group_plus.CommissionLine                          ;
         
DROP TABLE dev_core_group_plus.Producer                                ;
DROP TABLE dev_core_group_plus.ProducerWritingNumber                   ;
DROP TABLE dev_core_group_plus.MemberInsuranceAgreementCoverageProducer;
DROP TABLE dev_core_group_plus.Commission                              ;
DROP TABLE dev_core_group_plus.CommissionLine                          ;

DROP TABLE dev_publish_db_group_plus.Producer                                ;
DROP TABLE dev_publish_db_group_plus.ProducerWritingNumber                   ;
DROP TABLE dev_publish_db_group_plus.MemberInsuranceAgreementCoverageProducer;
DROP TABLE dev_publish_db_group_plus.Commission                              ;
DROP TABLE dev_publish_db_group_plus.CommissionLine                          ;


-- FSCD
CREATE TABLE dev_work_fscd.CDSDisbursement                                 LIKE  dev_work_group_plus.CDSDisbursement                                       ;
CREATE TABLE dev_core_fscd.CDSDisbursement                                 LIKE  dev_core_group_plus.CDSDisbursement                                       ;
CREATE TABLE dev_publish_fscd.CDSDisbursement                                 LIKE dev_publish_db_group_plus.CDSDisbursement                                 ;
INSERT OVERWRITE TABLE dev_work_fscd.CDSDisbursement                                 SELECT * FROM dev_work_group_plus.CDSDisbursement                                 ;
INSERT OVERWRITE TABLE dev_core_fscd.CDSDisbursement                                 SELECT * FROM dev_core_group_plus.CDSDisbursement                                 ;
INSERT OVERWRITE TABLE dev_publish_fscd.CDSDisbursement                                 SELECT * FROM dev_publish_db_group_plus.CDSDisbursement                                 ;

DROP TABLE dev_work_group_plus.CDSDisbursement                                ;
DROP TABLE dev_core_group_plus.CDSDisbursement                                ;
DROP TABLE dev_publish_db_group_plus.CDSDisbursement                                ;

-- PM&C WORK
CREATE TABLE dev_work_pmc.dim_work_AgentDemographics  LIKE  dev_work_group_plus.dim_work_AgentDemographics  ;
CREATE TABLE dev_work_pmc.dim_work_Commissions        LIKE  dev_work_group_plus.dim_work_Commissions        ;
CREATE TABLE dev_work_pmc.dim_work_SubscriberCoverage LIKE  dev_work_group_plus.dim_work_SubscriberCoverage ;
CREATE TABLE dev_work_pmc.dim_work_AgentArrangements  LIKE  dev_work_group_plus.dim_work_AgentArrangements  ;

INSERT OVERWRITE TABLE dev_work_pmc.dim_work_AgentDemographics   SELECT * FROM dev_work_group_plus.dim_work_AgentDemographics  ;
INSERT OVERWRITE TABLE dev_work_pmc.dim_work_Commissions         SELECT * FROM dev_work_group_plus.dim_work_Commissions        ;
INSERT OVERWRITE TABLE dev_work_pmc.dim_work_SubscriberCoverage  SELECT * FROM dev_work_group_plus.dim_work_SubscriberCoverage ;
INSERT OVERWRITE TABLE dev_work_pmc.dim_work_AgentArrangements   SELECT * FROM dev_work_group_plus.dim_work_AgentArrangements  ;

DROP TABLE dev_work_group_plus.dim_work_AgentDemographics  ;
DROP TABLE dev_work_group_plus.dim_work_Commissions        ;
DROP TABLE dev_work_group_plus.dim_work_SubscriberCoverage ;
DROP TABLE dev_work_group_plus.dim_work_AgentArrangements  ;

-- CDS WORK
CREATE TABLE dev_work_fscd.dim_work_CDS  LIKE  dev_work_group_plus.dim_work_CDS  ;

INSERT OVERWRITE TABLE dev_work_fscd.dim_work_CDS   SELECT * FROM dev_work_group_plus.dim_work_CDS  ;

DROP TABLE dev_work_group_plus.dim_work_CDS  ;
