create database dev_work_db_pmc    ;
create database dev_work_db_fscd   ;

create database dev_core_db_pmc    ;
create database dev_core_db_fscd   ;

create database dev_publish_db_pmc    ;
create database dev_publish_db_fscd   ;


-- PM&C
CREATE TABLE dev_work_db_pmc.Producer                                 LIKE  dev_work_pmc.Producer                                       ;
CREATE TABLE dev_work_db_pmc.ProducerWritingNumber                    LIKE  dev_work_pmc.ProducerWritingNumber                          ;
CREATE TABLE dev_work_db_pmc.MemberInsuranceAgreementCoverageProducer LIKE  dev_work_pmc.MemberInsuranceAgreementCoverageProducer       ;
CREATE TABLE dev_work_db_pmc.Commission                               LIKE  dev_work_pmc.Commission                                     ;
CREATE TABLE dev_work_db_pmc.CommissionLine                           LIKE  dev_work_pmc.CommissionLine                                 ;

CREATE TABLE dev_core_db_pmc.Producer                                 LIKE  dev_core_pmc.Producer                                       ;
CREATE TABLE dev_core_db_pmc.ProducerWritingNumber                    LIKE  dev_core_pmc.ProducerWritingNumber                          ;
CREATE TABLE dev_core_db_pmc.MemberInsuranceAgreementCoverageProducer LIKE  dev_core_pmc.MemberInsuranceAgreementCoverageProducer       ;
CREATE TABLE dev_core_db_pmc.Commission                               LIKE  dev_core_pmc.Commission                                     ;
CREATE TABLE dev_core_db_pmc.CommissionLine                           LIKE  dev_core_pmc.CommissionLine                                 ;

CREATE TABLE dev_publish_db_pmc.Producer                                 LIKE  dev_publish_pmc.Producer                                       ;
CREATE TABLE dev_publish_db_pmc.ProducerWritingNumber                    LIKE  dev_publish_pmc.ProducerWritingNumber                          ;
CREATE TABLE dev_publish_db_pmc.MemberInsuranceAgreementCoverageProducer LIKE  dev_publish_pmc.MemberInsuranceAgreementCoverageProducer       ;
CREATE TABLE dev_publish_db_pmc.Commission                               LIKE  dev_publish_pmc.Commission                                     ;
CREATE TABLE dev_publish_db_pmc.CommissionLine                           LIKE  dev_publish_pmc.CommissionLine                                 ;

INSERT OVERWRITE TABLE dev_work_db_pmc.Producer                                 SELECT * FROM dev_work_pmc.Producer                                 ;
INSERT OVERWRITE TABLE dev_work_db_pmc.ProducerWritingNumber                    SELECT * FROM dev_work_pmc.ProducerWritingNumber                    ;
INSERT OVERWRITE TABLE dev_work_db_pmc.MemberInsuranceAgreementCoverageProducer SELECT * FROM dev_work_pmc.MemberInsuranceAgreementCoverageProducer ;
INSERT OVERWRITE TABLE dev_work_db_pmc.Commission                               SELECT * FROM dev_work_pmc.Commission                               ;
INSERT OVERWRITE TABLE dev_work_db_pmc.CommissionLine                           SELECT * FROM dev_work_pmc.CommissionLine                           ;
                  
INSERT OVERWRITE TABLE dev_core_db_pmc.Producer                                 SELECT * FROM dev_core_pmc.Producer                                 ;
INSERT OVERWRITE TABLE dev_core_db_pmc.ProducerWritingNumber                    SELECT * FROM dev_core_pmc.ProducerWritingNumber                    ;
INSERT OVERWRITE TABLE dev_core_db_pmc.MemberInsuranceAgreementCoverageProducer SELECT * FROM dev_core_pmc.MemberInsuranceAgreementCoverageProducer ;
INSERT OVERWRITE TABLE dev_core_db_pmc.Commission                               SELECT * FROM dev_core_pmc.Commission                               ;
INSERT OVERWRITE TABLE dev_core_db_pmc.CommissionLine                           SELECT * FROM dev_core_pmc.CommissionLine                           ;

INSERT OVERWRITE TABLE dev_publish_db_pmc.Producer                                 SELECT * FROM dev_publish_pmc.Producer                                 ;
INSERT OVERWRITE TABLE dev_publish_db_pmc.ProducerWritingNumber                    SELECT * FROM dev_publish_pmc.ProducerWritingNumber                    ;
INSERT OVERWRITE TABLE dev_publish_db_pmc.MemberInsuranceAgreementCoverageProducer SELECT * FROM dev_publish_pmc.MemberInsuranceAgreementCoverageProducer ;
INSERT OVERWRITE TABLE dev_publish_db_pmc.Commission                               SELECT * FROM dev_publish_pmc.Commission                               ;
INSERT OVERWRITE TABLE dev_publish_db_pmc.CommissionLine                           SELECT * FROM dev_publish_pmc.CommissionLine                           ;

DROP TABLE dev_work_pmc.Producer                                ;
DROP TABLE dev_work_pmc.ProducerWritingNumber                   ;
DROP TABLE dev_work_pmc.MemberInsuranceAgreementCoverageProducer;
DROP TABLE dev_work_pmc.Commission                              ;
DROP TABLE dev_work_pmc.CommissionLine                          ;
         
DROP TABLE dev_core_pmc.Producer                                ;
DROP TABLE dev_core_pmc.ProducerWritingNumber                   ;
DROP TABLE dev_core_pmc.MemberInsuranceAgreementCoverageProducer;
DROP TABLE dev_core_pmc.Commission                              ;
DROP TABLE dev_core_pmc.CommissionLine                          ;

DROP TABLE dev_publish_pmc.Producer                                ;
DROP TABLE dev_publish_pmc.ProducerWritingNumber                   ;
DROP TABLE dev_publish_pmc.MemberInsuranceAgreementCoverageProducer;
DROP TABLE dev_publish_pmc.Commission                              ;
DROP TABLE dev_publish_pmc.CommissionLine                          ;

-- PM&C WORK
CREATE TABLE dev_work_db_pmc.dim_work_AgentDemographics  LIKE  dev_work_pmc.dim_work_AgentDemographics  ;
CREATE TABLE dev_work_db_pmc.dim_work_Commissions        LIKE  dev_work_pmc.dim_work_Commissions        ;
CREATE TABLE dev_work_db_pmc.dim_work_SubscriberCoverage LIKE  dev_work_pmc.dim_work_SubscriberCoverage ;
CREATE TABLE dev_work_db_pmc.dim_work_AgentArrangements  LIKE  dev_work_pmc.dim_work_AgentArrangements  ;

INSERT OVERWRITE TABLE dev_work_db_pmc.dim_work_AgentDemographics   SELECT * FROM dev_work_pmc.dim_work_AgentDemographics  ;
INSERT OVERWRITE TABLE dev_work_db_pmc.dim_work_Commissions         SELECT * FROM dev_work_pmc.dim_work_Commissions        ;
INSERT OVERWRITE TABLE dev_work_db_pmc.dim_work_SubscriberCoverage  SELECT * FROM dev_work_pmc.dim_work_SubscriberCoverage ;
INSERT OVERWRITE TABLE dev_work_db_pmc.dim_work_AgentArrangements   SELECT * FROM dev_work_pmc.dim_work_AgentArrangements  ;

DROP TABLE dev_work_pmc.dim_work_AgentDemographics  ;
DROP TABLE dev_work_pmc.dim_work_Commissions        ;
DROP TABLE dev_work_pmc.dim_work_SubscriberCoverage ;
DROP TABLE dev_work_pmc.dim_work_AgentArrangements  ;


-- FSCD
CREATE TABLE dev_work_db_fscd.CDSDisbursement                                 LIKE  dev_work_fscd.CDSDisbursement                                       ;
CREATE TABLE dev_core_db_fscd.CDSDisbursement                                 LIKE  dev_core_fscdc.CDSDisbursement                                       ;
CREATE TABLE dev_publish_db_fscd.CDSDisbursement                                 LIKE  dev_publish_fscdc.CDSDisbursement                                       ;

INSERT OVERWRITE TABLE dev_work_db_fscd.CDSDisbursement                                 SELECT * FROM dev_work_fscd.CDSDisbursement                                 ;
INSERT OVERWRITE TABLE dev_core_db_fscd.CDSDisbursement                                 SELECT * FROM dev_core_fscd.CDSDisbursement                                 ;
INSERT OVERWRITE TABLE dev_publish_db_fscd.CDSDisbursement                                 SELECT * FROM dev_publish_fscd.CDSDisbursement                                 ;

DROP TABLE dev_work_fscd.CDSDisbursement                                ;
DROP TABLE dev_core_fscd.CDSDisbursement                                ;
DROP TABLE dev_publish_fscd.CDSDisbursement                                ;

-- CDS WORK
CREATE TABLE dev_work_db_fscd.dim_work_CDS  LIKE  dev_work_pmc.dim_work_CDS  ;

INSERT OVERWRITE TABLE dev_work_db_fscd.dim_work_CDS   SELECT * FROM dev_work_pmc.dim_work_CDS  ;

DROP TABLE dev_work_fscd.dim_work_CDS  ;


DROP database dev_stage_pmc   ;
DROP database dev_stage_fscd  ;

DROP database dev_work_pmc    ;
DROP database dev_work_fscd   ;

DROP database dev_core_pmc    ;
DROP database dev_core_fscd   ;

DROP database dev_publish_pmc    ;
DROP database dev_publish_fscd   ;

-- list 
use dev_work_db_pmc ;
show tables;
use dev_work_db_pmc;    
show tables;
use dev_work_db_fscd ;  
show tables;
use dev_core_db_pmc  ;  
show tables;
use dev_core_db_fscd  ; 
show tables;
use dev_publish_db_pmc   ; 
show tables;
use dev_publish_db_fscd   ;