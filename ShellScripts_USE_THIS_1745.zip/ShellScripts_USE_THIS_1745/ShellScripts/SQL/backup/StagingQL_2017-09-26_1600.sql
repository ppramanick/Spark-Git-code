set hive.support.quoted.identifiers=none;
INSERT OVERWRITE TABLE ${StagingDB}.${StagingTable}
SELECT t1.*
--,t2.LastUpdated_ts
--,t2.hashbyte_cd
--,t2.HiveLastUpdateTimestamp
,hash(t1.*) AS hashcode
FROM 
(
 SELECT `(HiveLastUpdateTimestamp|${TS_COL}|${HASH_COL}|LastUpdateDateTime|ETL_UpdateDateTime|hashcode)?+.+`
 FROM ${StagingDB}.${StagingTable}
) t1
INNER JOIN
(
 SELECT ${PK}
 , HiveLastUpdateTimestamp
 --,LastUpdated_ts
 --,hashbyte_cd
 FROM ${StagingDB}.${StagingTable}
) t2
ON ${JOINS};