-- Add missing columns
ALTER TABLE ${WorkDB}.dim_work_${Table} ADD COLUMNS (start_date timestamp, end_date timestamp, scd_flag boolean) CASCADE;
-- Add bucketing
ALTER TABLE ${WorkDB}.dim_work_${Table} CLUSTERED BY (${PK}) INTO ${BUCKETS} BUCKETS;