--PK = Driver_Id
--Table = Driver
--StagingDB = dev_stage_source
--StagingTable = Driver
--WorkDB = dev_work_source
--WorkTable = dim_work_Driver
--WorkTableTemp = dim_work_Driver_new
--TS_COL = import_ts
--HASH_COL = license_no
--JOINS = t1.Driver_Id = t2.Driver_Id
--EXCLUDE = t2.Driver_Id IS NULL
--ALIAS_EXCLUDE = t2.TablePK1 IS NULL
--PK_SELECT_ALIAS = Driver_Id AS TablePK1

--> Is this taken from https://www.softserveinc.com/en-us/tech/blogs/process-slowly-changing-dimensions-hive/ ?
--> If so, how can it apply to this situation? 

--Create Temperory Dimension table
CREATE TABLE IF NOT EXISTS dev_work_source.dim_work_Driver_new LIKE dev_work_source.dim_work_Driver;
TRUNCATE TABLE dev_work_source.dim_work_Driver_new;

--Copy all the records from the production table that dont exist in the staging table:
--> ZERO RESULTS - Primary key cannot be null to begin with! Also, the staging table is empty anyways! / _new STILL EMPTY
INSERT INTO TABLE dev_work_source.dim_work_Driver_new
SELECT t1.* FROM dev_work_source.dim_work_Driver t1
LEFT JOIN dev_stage_source.Driver t2
ON t1.Driver_Id = t2.Driver_Id
WHERE t2.Driver_Id IS NULL;

--Copy all inactive (historical) records from the production table (apply SCD Type 1 changes if needed):
--> ZERO RESULTS - scd_flag is always null? / _new STILL EMPTY
INSERT INTO dev_work_source.dim_work_Driver_new
SELECT t1.* FROM dev_work_source.dim_work_Driver t1
INNER JOIN dev_stage_source.Driver t2
ON t1.Driver_Id = t2.Driver_Id AND t1.scd_flag = false;

--Copy all the active records from the production table which dont have SCD Type 2 changes (apply SCD Type 1 changes if needed):
--> ZERO RESULTS - scd_flag is always null? Also, this is pointless - query above tries to do the same with scd_flag = false. You need to compare the hash here! / _new STILL EMPTY
INSERT INTO TABLE dev_work_source.dim_work_Driver_new
SELECT t1.* FROM dev_work_source.dim_work_Driver t1
INNER JOIN dev_stage_source.Driver t2
ON t1.Driver_Id = t2.Driver_Id AND t1.scd_flag = true;

--Insert new inactive (historical) versions of records from the production table which have SCD Type 2 changes:
--> ZERO RESULTS - scd_flag is always null? It should also be "false as scd_flag" / _new STILL EMPTY
set hive.support.quoted.identifiers=none;
INSERT INTO TABLE dev_work_source.dim_work_Driver_new
SELECT t1.*, current_timestamp AS end_date, false 
FROM 
(
  SELECT `(end_date|scd_flag)?+.+` FROM dev_work_source.dim_work_Driver
  WHERE scd_flag = true
) t1
INNER JOIN dev_stage_source.Driver t2
ON t1.Driver_Id = t2.Driver_Id 
WHERE t1.hashcode != t2.hashcode;

--Insert new active versions of records from the production table which have SCD Type 2 changes:
--> ZERO RESULTS - scd_flag is still empty and hence the join condition remains false - this is the part where it's being written, but it wasn't set in the first place. Also, shouldn't "WHERE t2.TablePK1 IS NULL" be "WHERE t1.hashcode <> t2.hashcode" ? / _new STILL EMPTY
INSERT INTO TABLE dev_work_source.dim_work_Driver_new
SELECT n.*, 
current_timestamp AS start_date, --current timestamp for scd_start_date
CAST(NULL AS TIMESTAMP) AS end_date, --default timestamp for scd_end_date
true AS scd_flag --true for scd_active
FROM 
(
  SELECT `(start_date|scd_flag|end_date|^TablePK(.*))?+.+`
  FROM dev_work_source.dim_work_Driver t1
  INNER JOIN 
  (
    SELECT Driver_Id AS TablePK1 FROM dev_stage_source.Driver 
  ) t2
  ON t1.Driver_Id = t2.TablePK1 AND t1.scd_flag = true
  WHERE t2.TablePK1 IS NULL
) n;

--Copy all the records from the staging table which dont exist in the production table:
--> ZERO RESULTS / _new STILL EMPTY
INSERT INTO TABLE dev_work_source.dim_work_Driver_new
SELECT n.*,
current_timestamp AS start_date, -- current timestamp for scd_start_date
CAST(NULL AS TIMESTAMP) AS end_date, -- default timestamp for scd_end_date
true AS scd_flag -- true for scd_active
FROM 
(
  SELECT `(start_date|scd_flag|end_date|^TablePK(.*))?+.+`
  FROM dev_stage_source.Driver t1
  LEFT JOIN
  (
  SELECT Driver_Id AS TablePK1 FROM dev_work_source.dim_work_Driver
  ) t2
  ON t1.Driver_Id = t2.TablePK1
  WHERE t2.TablePK1 IS NULL
) n;

--Replace the content of the production table in a transactional manner:
--> EMPTIES OUT THE TARGET TABLE
INSERT OVERWRITE TABLE dev_work_source.dim_work_Driver
SELECT * FROM dev_work_source.dim_work_Driver_new;

--Drop Temporary Table
DROP TABLE IF EXISTS dev_work_source.dim_work_Driver_new;
