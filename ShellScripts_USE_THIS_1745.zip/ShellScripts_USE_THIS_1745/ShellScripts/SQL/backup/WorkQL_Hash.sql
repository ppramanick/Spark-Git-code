set hive.support.quoted.identifiers=none;

DROP TABLE ${StagingDB}.${StagingTable}_temp PURGE;

CREATE TABLE IF NOT EXISTS {StagingDB}.${StagingTable}_temp LIKE {StagingDB}.${StagingTable};

INSERT OVERWRITE TABLE ${StagingDB}.${StagingTable}_temp
SELECT t1.*, t2.LastUpdated_ts, t2.hashbyte_cd, t2.HiveLastUpdateTimestamp,
hash(t1.*) AS hashcode
FROM 
(
 SELECT `(HiveLastUpdateTimestamp|${TS_COL}|${HASH_COL}|LastUpdateDateTime|ETL_UpdateDateTime|hashcode)?+.+`
 FROM ${StagingDB}.${StagingTable}
) t1
INNER JOIN
(
 SELECT ${PK}, HiveLastUpdateTimestamp, LastUpdated_ts, hashbyte_cd
 FROM ${StagingDB}.${StagingTable}
) t2
ON ${JOINS};

INSERT OVERWRITE TABLE ${StagingDB}.${StagingTable}
SELECT *FROM ${StagingDB}.${StagingTable}_temp;

DROP TABLE ${StagingDB}.${StagingTable}_temp PURGE;