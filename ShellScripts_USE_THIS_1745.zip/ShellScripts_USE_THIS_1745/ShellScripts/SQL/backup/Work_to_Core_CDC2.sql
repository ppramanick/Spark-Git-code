set hive.support.quoted.identifiers=none;

-- Cleanup
DROP TABLE IF EXISTS ${CORE_DATABASE}.${DIM}_cdc;
DROP TABLE IF EXISTS ${CORE_DATABASE}.${DIM}_cdc_temp;

-- Add missing cols
ALTER TABLE ${CORE_DATABASE}.${DIM} ADD COLUMNS (start_date timestamp, end_date timestamp, scd_flag boolean);

-- Create a temp table which will hold the cdc records after the previous run
CREATE TABLE IF NOT EXISTS ${CORE_DATABASE}.${DIM}_cdc LIKE ${CORE_DATABASE}.${DIM};
CREATE TABLE IF NOT EXISTS ${CORE_DATABASE}.${DIM}_cdc_temp LIKE ${CORE_DATABASE}.${DIM};

-- Insert new records in work table into cdc table
INSERT INTO TABLE ${CORE_DATABASE}.${DIM}_cdc
SELECT *, current_timestamp as start_date, from_unixtime(0) as end_date, true as scd_flag
from ${WORK_DATABASE}.${DIM}
where hivelastupdatetimestamp > ${TS_COL};

-- Insert new records in cdc table into core table
INSERT INTO TABLE ${CORE_DATABASE}.${DIM}
SELECT `(hivelastupdatetimestamp|hashcode|start_date|end_Date|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, current_timestamp as start_date, from_unixtime(0) as end_date, true as scd_flag FROM
(
  SELECT t1.* FROM ${CORE_DATABASE}.${DIM}_cdc AS t1
  LEFT JOIN ${CORE_DATABASE}.${DIM} as t2
  ON ${JOINS}
  WHERE ${EXCLUDE}
) x1;

-- Copy over records to temp from core that were changed in work (only records having scd_flag=true)
INSERT OVERWRITE TABLE ${CORE_DATABASE}.${DIM}_cdc_temp
SELECT `(hivelastupdatetimestamp|hashcode|start_date|end_Date|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, x1.start_date as start_date, current_timestamp as end_date, false as scd_flag FROM
(
  SELECT t2.* FROM ${CORE_DATABASE}.${DIM}_cdc t1
  INNER JOIN ${CORE_DATABASE}.${DIM} t2
  ON ${JOINS}
  WHERE t1.hashcode <> t2.hashcode and t2.scd_flag=true
) x1;

-- Remove the old copy of the changed records in core i.e. overwrite the core table and keep only those records which haven't changed (scd_flag=false)
INSERT OVERWRITE TABLE ${CORE_DATABASE}.${DIM}
SELECT t1.* FROM ${CORE_DATABASE}.${DIM} t1
LEFT JOIN ${CORE_DATABASE}.${DIM}_cdc_temp t2
ON ${JOINS}
WHERE ${EXCLUDE} or t1.scd_flag=false;

-- Insert the changed records with scd_flag=false in the core table
INSERT INTO TABLE ${CORE_DATABASE}.${DIM} select * from ${CORE_DATABASE}.${DIM}_cdc_temp;

-- Insert the changed records from cdc table into core table with scd_flag=true
INSERT OVERWRITE TABLE ${CORE_DATABASE}.${DIM}
SELECT `(hivelastupdatetimestamp|hashcode|start_date|end_Date|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, x1.start_date as start_date, from_unixtime(0) as end_date, true as scd_flag FROM
(
  SELECT t1.* FROM ${CORE_DATABASE}.${DIM}_cdc t1
  INNER JOIN ${CORE_DATABASE}.${DIM} t2
  ON ${JOINS}
  WHERE t1.hashcode <> t2.hashcode
) x1;

-- Cleanup
DROP TABLE IF EXISTS ${CORE_DATABASE}.${DIM}_cdc;
DROP TABLE IF EXISTS ${CORE_DATABASE}.${DIM}_cdc_temp;

select * from ${CORE_DATABASE}.${DIM} where 1=0;