set hive.support.quoted.identifiers=none;

-- Cleanup
DROP TABLE IF EXISTS d${WorkDB}.${WorkTableTemp} PURGE;
CREATE TABLE ${WorkDB}.${WorkTableTemp} LIKE ${WorkDB}.${WorkTable};
TRUNCATE TABLE ${WorkDB}.${WorkTableTemp};

-- Copy over records to temp from staging that were changed in source
INSERT OVERWRITE TABLE ${WorkDB}.${WorkTableTemp}
SELECT `(xvc|scd_flag)?+.+`, t1.xvc as scd_flag FROM
(
  SELECT t1.*, true as xvc FROM ${WorkDB}.${WorkTable} t1
  LEFT JOIN ${StagingDB}.${Table} t2
  ON ${JOINS}
  WHERE t1.hashcode <> t2.hashcode
) x1;

-- Overwrite all old records in target, changing scd_flag = false
INSERT INTO TABLE ${WorkDB}.${WorkTable}
SELECT x1.*, false as scd_flag FROM
(
  SELECT t1.* FROM ${WorkDB}.${WorkTable} t1
  INNER JOIN ${WorkDB}.${WorkTableTemp} t2
  ON ${JOINS}
) x1
;

-- Clean tmp  table
TRUNCATE TABLE ${WorkDB}.${WorkTableTemp};

-- Copy over all other records from staging that have NO match
INSERT OVERWRITE ${WorkDB}.dim_work_${Table}
SELECT t1.*, true as scd_flag FROM ${StagingDB}.${Table} AS t1
LEFT JOIN ${WorkDB}.${WorkTable} as t2
ON ${JOINS}
WHERE ${EXCLUDE};

-------------- OLD -----------------

--Create Temperory Dimension table
DROP TABLE IF EXISTS ${WorkDB}.dim_work_${Table}_new PURGE;
CREATE TABLE ${WorkDB}.dim_work_${Table}_new LIKE ${WorkDB}.dim_work_${Table};

--Copy all the records from the production table that dont exist in the staging table:
INSERT INTO TABLE ${WorkDB}.dim_work_${Table}_new
SELECT t1.* FROM ${WorkDB}.dim_work_${Table} t1
LEFT JOIN ${StagingDB}.${Table} t2
ON ${JOINS}
WHERE ${EXCLUDE};

--Copy all inactive (historical) records from the production table (apply SCD Type 1 changes if needed):
INSERT INTO ${WorkDB}.dim_work_${Table}_new
SELECT t1.* FROM ${WorkDB}.dim_work_${Table} t1
INNER JOIN ${StagingDB}.${Table} t2
ON ${JOINS} AND t1.scd_flag = false;

--Copy all the active records from the production table which dont have SCD Type 2 changes (apply SCD Type 1 changes if needed):
INSERT INTO TABLE ${WorkDB}.dim_work_${Table}_new
SELECT t1.* FROM ${WorkDB}.dim_work_${Table} t1
INNER JOIN ${StagingDB}.${Table} t2
ON ${JOINS} AND t1.scd_flag = true;

--Insert new inactive (historical) versions of records from the production table which have SCD Type 2 changes:
set hive.support.quoted.identifiers=none;
INSERT INTO TABLE ${WorkDB}.dim_work_${Table}_new
SELECT t1.*, current_timestamp AS end_date, false
FROM 
(
  SELECT `(end_date|scd_flag)?+.+` FROM ${WorkDB}.dim_work_${Table}
  WHERE scd_flag = true
) t1
INNER JOIN ${StagingDB}.${Table} t2
ON ${JOINS} 
WHERE t1.hashcode != t2.hashcode;

--Insert new active versions of records from the production table which have SCD Type 2 changes:
set hive.support.quoted.identifiers=none;
INSERT INTO TABLE ${WorkDB}.dim_work_${Table}_new
SELECT n.*, 
current_timestamp AS start_date, --current timestamp for scd_start_date
CAST(NULL AS TIMESTAMP) AS end_date, --default timestamp for scd_end_date
true AS scd_flag --true for scd_active
FROM 
(
  SELECT `(start_date|scd_flag|end_date|^TablePK(.*))?+.+`
  FROM ${WorkDB}.dim_work_${Table} t1
  INNER JOIN 
  (
    SELECT ${PK_SELECT_ALIAS} FROM ${StagingDB}.${Table} 
  ) t2
  ON ${ALIAS_JOIN} AND t1.scd_flag = true
  WHERE ${ALIAS_EXCLUDE}
) n;

--Copy all the records from the staging table which dont exist in the production table:
INSERT INTO TABLE ${WorkDB}.dim_work_${Table}_new
SELECT n.*,
current_timestamp AS start_date, -- current timestamp for scd_start_date
CAST(NULL AS TIMESTAMP) AS end_date, -- default timestamp for scd_end_date
true AS scd_flag -- true for scd_active
FROM 
(
  SELECT `(start_date|scd_flag|end_date|^TablePK(.*))?+.+`
  FROM ${StagingDB}.${Table} t1
  LEFT JOIN
  (
  SELECT ${PK_SELECT_ALIAS} FROM ${WorkDB}.dim_work_${Table}
  ) t2
  ON ${ALIAS_JOIN}
  WHERE ${ALIAS_EXCLUDE}
) n;

--Replace the content of the production table in a transactional manner:
INSERT OVERWRITE TABLE ${WorkDB}.dim_work_${Table}
SELECT * FROM ${WorkDB}.dim_work_${Table}_new;

--Drop Temporary Table
DROP TABLE IF EXISTS ${WorkDB}.dim_work_${Table}_new;