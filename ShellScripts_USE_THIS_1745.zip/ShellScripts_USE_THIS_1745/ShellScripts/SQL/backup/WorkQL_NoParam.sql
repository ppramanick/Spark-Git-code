set hive.support.quoted.identifiers=none;
--Create Temperory dimension table

DROP TABLE IF EXISTS dev_work_group_plus.dim_work_grpctrl_new PURGE;

CREATE TABLE dev_work_group_plus.dim_work_grpctrl_new LIKE dev_work_group_plus.dim_work_grpctrl;

--Copy all the records from the production table that dont exist in the staging table:

INSERT INTO TABLE dev_work_group_plus.dim_work_grpctrl_new
SELECT t1.* FROM dev_work_group_plus.dim_work_grpctrl t1
LEFT JOIN dev_stage_group_plus.grpctrl t2
ON t1.gcgrp = t2.gcgrp
WHERE t2.gcgrp IS NULL;

--Copy all inactive (historical) records from the production table (apply SCD Type 1 changes if needed):

INSERT INTO dev_work_group_plus.dim_work_grpctrl_new
SELECT t1.* FROM dev_work_group_plus.dim_work_grpctrl t1
INNER JOIN dev_stage_group_plus.grpctrl t2
ON t1.gcgrp = t2.gcgrp AND t1.scd_flag = false;

--Copy all the active records from the production table which dont have SCD Type 2 changes (apply SCD Type 1 changes if needed):
INSERT INTO TABLE dev_work_group_plus.dim_work_grpctrl_new
SELECT t1.* FROM dev_work_group_plus.dim_work_grpctrl t1
INNER JOIN dev_stage_group_plus.grpctrl t2
ON t1.gcgrp = t2.gcgrp AND t1.scd_flag = true;

--Insert new inactive (historical) versions of records from the production table which have SCD Type 2 changes:

set hive.support.quoted.identifiers=none;
INSERT INTO TABLE dev_work_group_plus.dim_work_grpctrl_new
SELECT t1.*, current_timestamp AS end_date, false
FROM 
(
  SELECT `(end_date|scd_flag)?+.+` FROM dev_work_group_plus.dim_work_grpctrl
  WHERE scd_flag = true
) t1
INNER JOIN dev_stage_group_plus.grpctrl t2
ON t1.gcgrp = t2.gcgrp 
WHERE t1.hashcode != t2.hashcode;

--Insert new active versions of records from the production table which have SCD Type 2 changes:
set hive.support.quoted.identifiers=none;
INSERT INTO TABLE dev_work_group_plus.dim_work_grpctrl_new
SELECT n.*, 
current_timestamp AS start_date, --current timestamp for scd_start_date
CAST(NULL AS TIMESTAMP) AS end_date, --default timestamp for scd_end_date
true AS scd_flag --true for scd_active
FROM 
(
 SELECT `(start_date|scd_flag|end_date|TablePK)?+.+`
 FROM dev_work_group_plus.dim_work_grpctrl t1
 INNER JOIN 
 (
  SELECT gcgrp AS TablePK FROM dev_stage_group_plus.grpctrl 
 ) t2
 ON t1.gcgrp = t2.TablePK AND t1.scd_flag = true
 WHERE t2.TablePK IS NULL
) n;

--Copy all the records from the staging table which dont exist in the production table:
INSERT INTO TABLE dev_work_group_plus.dim_work_grpctrl_new
SELECT n.*,
current_timestamp AS start_date, -- current timestamp for scd_start_date
CAST(NULL AS TIMESTAMP) AS end_date, -- default timestamp for scd_end_date
true AS scd_flag -- true for scd_active
FROM 
(
 SELECT `(start_date|scd_flag|end_date|TablePK)?+.+`
 FROM dev_stage_group_plus.grpctrl t1
 LEFT JOIN
 (
  SELECT gcgrp AS TablePK FROM dev_work_group_plus.dim_work_grpctrl 
 ) t2
 ON t1.gcgrp = t2.TablePK
 WHERE t2.TablePK IS NULL
) n;

--Replace the content of the production table in a transactional manner:

INSERT OVERWRITE TABLE dev_work_group_plus.dim_work_grpctrl
SELECT *FROM dev_work_group_plus.dim_work_grpctrl_new;

--Drop Temp Table

DROP TABLE IF EXISTS dev_work_group_plus.dim_work_grpctrl_new;