ALTER TABLE Driver ADD COLUMN (import_ts bigint);
UPDATE Driver SET import_ts = 1506360248 WHERE Driver_Id <= 5;
UPDATE Driver SET import_ts = 1507360248 WHERE Driver_Id > 5;

DROP TABLE IF EXISTS Driver_Sub;
CREATE TABLE IF NOT EXISTS Driver_Sub AS 
SELECT * 
FROM Driver
WHERE Driver_Id <= 5;

DROP TABLE IF EXISTS Driver_Sub2;
CREATE TABLE IF NOT EXISTS Driver_Sub2 AS 
SELECT * 
FROM Driver
WHERE Driver_Id > 5;

ALTER TABLE policy ADD COLUMN (import_ts bigint);
UPDATE policy SET import_ts = 1706360248;

ALTER TABLE policy CHANGE start_date sdate varchar(255);
ALTER TABLE policy CHANGE end_date edate varchar(255);

-- Hive
drop table dev_work_source.dim_work_driver;
drop table dev_work_source.dim_work_driver_new;
drop table dev_stage_source.driver;