set hive.support.quoted.identifiers=none;

DROP TABLE IF EXISTS ${StagingDB}.${StagingTable}_temp;

--Create Temporary table
CREATE TABLE IF NOT EXISTS ${StagingDB}.${StagingTable}_temp LIKE ${StagingDB}.${StagingTable};

--Overwrite temporary table with hash values computed
INSERT OVERWRITE TABLE  ${StagingDB}.${StagingTable}_temp
SELECT `(hashcode)?+.+`, hash(${COLUMNS}) AS hashcode
FROM ${StagingDB}.${StagingTable};

-- De-duplicate
WITH tmp AS (
  SELECT t1.*, ROW_NUMBER() OVER (PARTITION BY hashcode ORDER BY hivelastupdatetimestamp DESC) AS row_num
  FROM ${StagingDB}.${StagingTable}_temp t1
)
INSERT OVERWRITE TABLE ${StagingDB}.${StagingTable}_temp
SELECT `(t.row_num|row_num)?+.+`
FROM tmp t
WHERE t.row_num = 1;

--Replace original table with computed hash from temporary table
INSERT OVERWRITE TABLE ${StagingDB}.${StagingTable}
SELECT * FROM ${StagingDB}.${StagingTable}_temp;

--Drop temporary table
TRUNCATE TABLE ${StagingDB}.${StagingTable}_temp;
DROP TABLE IF EXISTS ${StagingDB}.${StagingTable}_temp;

--Beeline Bug
select * from ${StagingDB}.${StagingTable}; where 1=0;

