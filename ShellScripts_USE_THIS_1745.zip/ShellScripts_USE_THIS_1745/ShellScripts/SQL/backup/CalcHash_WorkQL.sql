set hive.support.quoted.identifiers=none;

DROP TABLE IF EXISTS ${WORK_DATABASE}.${DIM}_temp;

--Create Temporary table
CREATE TABLE IF NOT EXISTS ${WORK_DATABASE}.${DIM}_temp LIKE ${WORK_DATABASE}.${DIM};

--Overwrite temporary table with hash values computed
INSERT OVERWRITE TABLE  ${WORK_DATABASE}.${DIM}_temp
SELECT `(hashcode)?+.+`, hash(${COLUMNS}) AS hashcode
FROM ${WORK_DATABASE}.${DIM};

-- De-duplicate
WITH tmp AS (
  SELECT t1.*, ROW_NUMBER() OVER (PARTITION BY hashcode ORDER BY hivelastupdatetimestamp DESC) AS row_num
  FROM ${WORK_DATABASE}.${DIM}_temp t1
)
INSERT OVERWRITE TABLE ${WORK_DATABASE}.${DIM}_temp
SELECT `(t.row_num|row_num)?+.+`
FROM tmp t
WHERE t.row_num = 1;

--Replace original table with computed hash from temporary table
INSERT OVERWRITE TABLE ${WORK_DATABASE}.${DIM}
SELECT * FROM ${WORK_DATABASE}.${DIM}_temp;

--Drop temporary table
TRUNCATE TABLE ${WORK_DATABASE}.${DIM}_temp;
DROP TABLE IF EXISTS ${WORK_DATABASE}.${DIM}_temp;

--Beeline Bug
select * from ${WORK_DATABASE}.${DIM} where 1=0;

