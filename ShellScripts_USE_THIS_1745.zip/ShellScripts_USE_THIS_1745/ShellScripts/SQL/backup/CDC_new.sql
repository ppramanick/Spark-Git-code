--Step 1: Create INT table same as Target and copy expired records.
DROP TABLE IF EXISTS ${TMP_DB}.${TMP_TABLE};
CREATE TABLE ${TMP_DB}.${TMP_TABLE} AS
SELECT * FROM ${TARGET_DB}.${TARGET_TABLE}
WHERE scd_flag = false AND end_date IS NOT NULL;

-- Step 2: Copy all going to expire records
INSERT INTO ${TMP_DB}.${TMP_TABLE}
SELECT ${TRGT_COLUMNS}, -------------------------------------------------- NEW FIELD
start_date,
current_timestamp() as end_date,
false as scd_flag
FROM ${TARGET_DB}.${TARGET_TABLE} trgt
JOIN ${SOURCE_DB}.${SOURCE_TABLE} src
ON (${JOIN})-- (trgt.sk = src.sk)
WHERE (trgt.hashcode <> src.hashcode)
AND trgt.scd_flag = false;

-- Step 3: Copy active records from trgt to INT table
INSERT INTO ${TMP_DB}.${TMP_TABLE}
SELECT ${COLUMNS},
start_date,
end_date,
scd_flag
FROM ${TARGET_DB}.${TARGET_TABLE} trgt
WHERE scd_flag = true
AND NOT EXISTS 
(SELECT 1 FROM
 ${SOURCE_DB}.${SOURCE_TABLE} src
 WHERE ${JOIN}  -- (trgt.sk = src.sk) 
)

UNION ALL -- include unchanged records

SELECT ${COLUMNS},
start_date,
end_date,
scd_flag
FROM ${TARGET_DB}.${TARGET_TABLE} trgt
WHERE trgt.scd_flag = true
AND EXISTS 
(SELECT 1 
  FROM ${SOURCE_DB}.${SOURCE_TABLE} src
  WHERE ${JOIN}
);
 
-- Step 4: Copy only updated records from LOAD table
INSERT INTO ${TMP_DB}.${TMP_TABLE}
SELECT ${COLUMNS},
current_timestamp() as start_date,
NULL as end_date,
true as scd_flag
FROM ${SOURCE_DB}.${SOURCE_TABLE} src
WHERE EXISTS (
SELECT 1
 FROM ${TMP_DB}.${TMP_TABLE} INT1
 WHERE ${JOIN_SRC_INT} -------------------------------------------------- NEW FIELD
 AND scd_flag = false
 AND NOT EXISTS
 (
SELECT 1
 FROM ${TMP_DB}.${TMP_TABLE} INT2
 WHERE ${JOIN_INT} -------------------------------------------------- NEW FIELD
 AND scd_flag = true 
 )
);
 
-- Step 5: Copy new records from LOAD to INT
INSERT INTO ${TMP_DB}.${TMP_TABLE}
SELECT {COLUMNS},
current_timestamp as start_date,
NULL as end_date,
true as scd_flag
FROM ${SOURCE_DB}.${SOURCE_TABLE} src
WHERE NOT EXISTS (SELECT 1
 FROM ${TMP_DB}.${TMP_TABLE} INT1
 WHERE src.SK = INT1.SK);
 
-- Step 6: Perform Insert Overwroite on trgt table.
INSERT OVERWRITE TABLE ${TARGET_DB}.${TARGET_TABLE}
SELECT * FROM ${TMP_DB}.${TMP_TABLE};

-- Step 7. Drop table
DROP TABLE ${TMP_DB}.${TMP_TABLE};