set hive.support.quoted.identifiers=none;

DROP TABLE IF EXISTS ${WORK_DATABASE}.${DIM}_temp;
--Create Temporary table
CREATE TABLE IF NOT EXISTS ${WORK_DATABASE}.${DIM}_temp LIKE ${WORK_DATABASE}.${DIM};

--Overwrite temporary table with hash values computed
INSERT OVERWRITE TABLE ${WORK_DATABASE}.${DIM}_temp
SELECT t1.*, ${EXCLUDE_COLUMNS_T}, hash(t1.*) AS hashcode
FROM
(
 SELECT `(${EXCLUDE_COLUMNS_REGEX})?+.+`
 FROM ${WORK_DATABASE}.${DIM}
) t1
INNER JOIN
(
 SELECT ${PK}, ${EXCLUDE_COLUMNS}
 FROM ${WORK_DATABASE}.${DIM}
) t2
ON (${JOINS});

-- De-duplicate
INSERT OVERWRITE TABLE ${WORK_DATABASE}.${DIM}_temp
SELECT DISTINCT * FROM ${WORK_DATABASE}.${DIM}_temp;

--Replace original table with computed hash from temporary table
INSERT OVERWRITE TABLE ${WORK_DATABASE}.${DIM}
SELECT * FROM ${WORK_DATABASE}.${DIM}_temp;

--Drop temporary table
TRUNCATE TABLE ${WORK_DATABASE}.${DIM}_temp;
DROP TABLE IF EXISTS ${WORK_DATABASE}.${DIM}_temp;