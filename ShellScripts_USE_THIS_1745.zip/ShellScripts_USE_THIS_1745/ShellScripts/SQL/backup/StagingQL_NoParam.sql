INSERT OVERWRITE TABLE dev_stage_group_plus.grpctrl
SELECT t1.*, t2.LastUpdated_ts, t2.hashbyte_cd, t2.HiveLastUpdateTimestamp,
hash(t1.*) AS hashcode
FROM 
(
 SELECT `(HiveLastUpdateTimestamp|LastUpdated_ts|hashbyte_cd|LastUpdateDateTime|ETL_UpdateDateTime|hashcode)?+.+`
 FROM dev_stage_group_plus.grpctrl
) t1
INNER JOIN
(
 SELECT gcgrp, HiveLastUpdateTimestamp, LastUpdated_ts, hashbyte_cd
 FROM dev_stage_group_plus.grpctrl
) t2
ON t1.gcgrp = t2.gcgrp;