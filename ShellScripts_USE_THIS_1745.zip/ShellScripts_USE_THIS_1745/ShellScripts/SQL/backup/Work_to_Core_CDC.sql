set hive.support.quoted.identifiers=none;
-- 4x YARN min container size
set hive.tez.container.size=24576;
-- 1/3 of TEZ container
set hive.auto.convert.join.noconditionaltask.size=8192;
-- 40% of TEZ container
set tez.runtime.io.sort.mb=9830;
-- 10% of TEZ container
set tez.runtime.unordered.output.buffer.size-mb=2457;
-- 75% of the container size
set hive.tez.java.opts=-Xmx18432m -XX:NewRatio=8;
-- equal to container size
set tez.am.resource.memory.mb=6144;

-- Cleanup
DROP TABLE IF EXISTS ${CORE_DATABASE}.${DIM}_cdc;

-- Add missing cols
-- HARD CODED IN DLL FOR NOW
--ALTER TABLE ${CORE_DATABASE}.${DIM} ADD COLUMNS (start_date timestamp, end_date timestamp, scd_flag boolean);

-- Create a temp table which will hold the cdc records after the previous run
CREATE TABLE IF NOT EXISTS ${CORE_DATABASE}.${DIM}_cdc LIKE ${CORE_DATABASE}.${DIM};

-- Insert new records in cdc table into core table
INSERT INTO TABLE ${CORE_DATABASE}.${DIM}
SELECT `(hivelastupdatetimestamp|hashcode|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, current_timestamp as start_date, from_unixtime(0) as end_date, true as scd_flag FROM
(
  SELECT t1.* FROM ${WORK_DATABASE}.${DIM} AS t1
  LEFT JOIN ${CORE_DATABASE}.${DIM} as t2
  ON ${JOINS}
  WHERE ${EXCLUDE}
  AND t1.hivelastupdatetimestamp > '${LAST_CDC_TS}'
) x1;

-- Copy over records to temp from core that were changed in work (only records having scd_flag=true)
INSERT OVERWRITE TABLE ${CORE_DATABASE}.${DIM}_cdc
SELECT `(hivelastupdatetimestamp|hashcode|start_date|end_Date|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, x1.start_date as start_date, current_timestamp as end_date, false as scd_flag FROM
(
  SELECT t1.* FROM ${CORE_DATABASE}.${DIM} t1
  INNER JOIN ${WORK_DATABASE}.${DIM} t2
  ON ${JOINS}
  WHERE t1.hashcode <> t2.hashcode
  AND t2.hivelastupdatetimestamp > '${LAST_CDC_TS}'
) x1;

-- Remove the old copy of the changed records in core i.e. overwrite the core table and keep only those records which haven't changed (scd_flag=false)
INSERT OVERWRITE TABLE ${CORE_DATABASE}.${DIM}
SELECT t1.* FROM ${CORE_DATABASE}.${DIM} t1
LEFT JOIN ${CORE_DATABASE}.${DIM}_cdc t2
ON ${JOINS}
WHERE ${EXCLUDE};

-- Insert the changed records with scd_flag=false in the core table
INSERT INTO TABLE ${CORE_DATABASE}.${DIM} select * from ${CORE_DATABASE}.${DIM}_cdc;

-- Insert the changed records from cdc table into core table with scd_flag=true
INSERT INTO TABLE ${CORE_DATABASE}.${DIM}
SELECT `(hivelastupdatetimestamp|hashcode|start_date|end_Date|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, current_timestamp as start_date, from_unixtime(0) as end_date, true as scd_flag FROM
(
  SELECT t2.* FROM ${CORE_DATABASE}.${DIM} t1
  INNER JOIN ${WORK_DATABASE}.${DIM} t2
  ON ${JOINS}
  WHERE t1.hashcode <> t2.hashcode
) x1;

-- Cleanup
TRUNCATE TABLE ${CORE_DATABASE}.${DIM}_cdc;
DROP TABLE IF EXISTS ${CORE_DATABASE}.${DIM}_cdc;

select * from ${CORE_DATABASE}.${DIM} where 1=0;