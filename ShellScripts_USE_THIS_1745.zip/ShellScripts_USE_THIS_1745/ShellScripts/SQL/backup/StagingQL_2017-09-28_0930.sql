set hive.support.quoted.identifiers=none;

--Create Temporary table
CREATE TABLE IF NOT EXISTS ${StagingDB}.${StagingTable}_temp LIKE ${StagingDB}.${StagingTable};

--Overwrite temporary table with hash values computed
INSERT OVERWRITE TABLE ${StagingDB}.${StagingTable}_temp 
SELECT t1.*, t2.${TS_COL}, t2.${HASH_COL}, t2.HiveLastUpdateTimestamp,
hash(t1.*) AS hashcode
FROM 
(
 SELECT `(HiveLastUpdateTimestamp|${TS_COL}|${HASH_COL}|LastUpdateDateTime|ETL_UpdateDateTime|hashcode)?+.+`
 FROM ${StagingDB}.${StagingTable}
) t1
INNER JOIN
(
 SELECT ${PK}, HiveLastUpdateTimestamp, ${TS_COL}, ${HASH_COL}
 FROM ${StagingDB}.${StagingTable}
) t2
ON ${JOINS};

--Replace original table with computed hash from temporary table
INSERT OVERWRITE TABLE ${StagingDB}.${StagingTable}
SELECT * FROM ${StagingDB}.${StagingTable}_temp;

--Drop temporary table
DROP TABLE IF EXISTS ${StagingDB}.${StagingTable}_temp PURGE;