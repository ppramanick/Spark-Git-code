set hive.support.quoted.identifiers=none;
-- 4x YARN min container size
set hive.tez.container.size=24576;
-- 1/3 of TEZ container
set hive.auto.convert.join.noconditionaltask.size=8192;
-- 40% of TEZ container
set tez.runtime.io.sort.mb=9830;
-- 10% of TEZ container
set tez.runtime.unordered.output.buffer.size-mb=2457;
-- 75% of the container size
set hive.tez.java.opts=-Xmx18432m -XX:NewRatio=8;
-- equal to container size
set tez.am.resource.memory.mb=6144;

DROP TABLE IF EXISTS ${DATABASE}.${TABLE}_temp;

--Create Temporary table
CREATE TABLE IF NOT EXISTS ${DATABASE}.${TABLE}_temp LIKE ${DATABASE}.${TABLE};

--Overwrite temporary table with hash values computed
INSERT OVERWRITE TABLE  ${DATABASE}.${TABLE}_temp
SELECT `(hashcode)?+.+`, md5(CONCAT_WS('-',${COLUMNS_CAST})) AS hashcode
FROM ${DATABASE}.${TABLE};

-- De-duplicate
WITH tmp AS (
  SELECT t1.*, ROW_NUMBER() OVER (PARTITION BY ${PK} ORDER BY hivelastupdatetimestamp DESC) AS row_num
  FROM ${DATABASE}.${TABLE}_temp t1
)
INSERT OVERWRITE TABLE ${DATABASE}.${TABLE}_temp
SELECT `(t.row_num|row_num)?+.+`
FROM tmp t
WHERE t.row_num = 1;

--Replace original table with computed hash from temporary table
INSERT OVERWRITE TABLE ${DATABASE}.${TABLE}
SELECT * FROM ${DATABASE}.${TABLE}_temp;

--Drop temporary table
TRUNCATE TABLE ${DATABASE}.${TABLE}_temp;
DROP TABLE IF EXISTS ${DATABASE}.${TABLE}_temp;


--Beeline Bug
select * from ${DATABASE}.${TABLE} where 1=0;

