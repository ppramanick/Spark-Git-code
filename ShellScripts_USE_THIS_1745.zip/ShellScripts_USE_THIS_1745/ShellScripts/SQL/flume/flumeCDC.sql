set hive.support.quoted.identifiers=none;
-- 4x YARN min container size
set hive.tez.container.size=24576;
-- 1/3 of TEZ container
set hive.auto.convert.join.noconditionaltask.size=8192;
-- 40% of TEZ container
set tez.runtime.io.sort.mb=9830;
-- 10% of TEZ container
set tez.runtime.unordered.output.buffer.size-mb=2457;
-- 75% of the container size
set hive.tez.java.opts=-Xmx18432m -XX:NewRatio=8;
-- equal to container size
set tez.am.resource.memory.mb=6144;

-- Cleanup
DROP TABLE IF EXISTS ${TARGET_DATABASE}.${TRGT_TABLE}_cdc;

-- Add missing cols
-- HARD CODED IN DLL FOR NOW
-- ALTER TABLE ${TARGET_DATABASE}.${TRGT_TABLE} ADD COLUMNS (start_date timestamp, end_date timestamp, scd_flag boolean);

-- Create a temp table which will hold the cdc records after the previous run
CREATE TABLE IF NOT EXISTS ${TARGET_DATABASE}.${TRGT_TABLE}_cdc LIKE ${TARGET_DATABASE}.${TRGT_TABLE};

-- Insert new records in cdc table into core table
INSERT INTO TABLE ${TARGET_DATABASE}.${TRGT_TABLE}
SELECT `(hivelastupdatetimestamp|hashcode|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, current_timestamp as start_date, from_unixtime(0) as end_date, true as scd_flag FROM
(
  SELECT t1.* FROM ${SOURCE_DATABASE}.${SRC_TABLE} AS t1
  LEFT JOIN ${TARGET_DATABASE}.${TRGT_TABLE} as t2
  ON ${JOINS}
  WHERE ${EXCLUDE}
  AND t1.hivelastupdatetimestamp > '${LAST_CDC_TS}'
) x1;

-- Copy over records to temp from core that were changed in work (only records having scd_flag=true)
INSERT OVERWRITE TABLE ${TARGET_DATABASE}.${TRGT_TABLE}_cdc
SELECT `(hivelastupdatetimestamp|hashcode|start_date|end_Date|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, x1.start_date as start_date, current_timestamp as end_date, false as scd_flag FROM
(
  SELECT t1.* FROM ${TARGET_DATABASE}.${TRGT_TABLE} t1
  INNER JOIN ${SOURCE_DATABASE}.${SRC_TABLE} t2
  ON ${JOINS}
  WHERE t1.hashcode <> t2.hashcode
  AND t2.hivelastupdatetimestamp > '${LAST_CDC_TS}'
) x1;

-- Remove the old copy of the changed records in core i.e. overwrite the core table and keep only those records which haven't changed (scd_flag=false)
INSERT OVERWRITE TABLE ${TARGET_DATABASE}.${TRGT_TABLE}
SELECT t1.* FROM ${TARGET_DATABASE}.${TRGT_TABLE} t1
LEFT JOIN ${TARGET_DATABASE}.${TRGT_TABLE}_cdc t2
ON ${JOINS}
WHERE ${EXCLUDE};

-- Insert the changed records with scd_flag=false in the core table
INSERT INTO TABLE ${TARGET_DATABASE}.${TRGT_TABLE} select * from ${TARGET_DATABASE}.${TRGT_TABLE}_cdc;

-- Insert the changed records from cdc table into core table with scd_flag=true
INSERT INTO TABLE ${TARGET_DATABASE}.${TRGT_TABLE}
SELECT `(hivelastupdatetimestamp|hashcode|start_date|end_Date|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, current_timestamp as start_date, from_unixtime(0) as end_date, true as scd_flag FROM
(
  SELECT t2.* FROM ${TARGET_DATABASE}.${TRGT_TABLE} t1
  INNER JOIN ${SOURCE_DATABASE}.${SRC_TABLE} t2
  ON ${JOINS}
  WHERE t1.hashcode <> t2.hashcode
) x1;

-- De-duplicate due to questionable test data
WITH tmp AS (
  SELECT t1.*, ROW_NUMBER() OVER (PARTITION BY hashcode ORDER BY hivelastupdatetimestamp DESC) AS row_num
  FROM ${TARGET_DATABASE}.${TRGT_TABLE} t1
)
INSERT OVERWRITE TABLE ${TARGET_DATABASE}.${TRGT_TABLE}
SELECT `(t.row_num|row_num)?+.+`
FROM tmp t
WHERE t.row_num = 1;

-- Cleanup
TRUNCATE TABLE ${TARGET_DATABASE}.${TRGT_TABLE}_cdc;
DROP TABLE IF EXISTS ${TARGET_DATABASE}.${TRGT_TABLE}_cdc;
-- this is used for additional drops, especially in the work to work ase
--DROP TABLE IF EXISTS ${DROP_DB}.${DROP_TABLE};

select * from ${TARGET_DATABASE}.${TRGT_TABLE} where 1=0;


