set hive.support.quoted.identifiers=none;
-- Add columns
ALTER TABLE ${DB}.${TABLE}_temp SET LOCATION ${TBLPATH};
CREATE TABLE IF NOT EXISTS ${DB}.${TABLE}_stg LIKE ${DB}.${TABLE}_temp;
ALTER TABLE ${DB}.${TABLE}_stg ADD COLUMNS (hivelastupdatetimestamp TIMESTAMP, hashcode STRING);
-- Prepare the target table, as this script uses --force=true
ALTER TABLE ${DB}.dim_work_${TABLE} ADD COLUMNS (hivelastupdatetimestamp TIMESTAMP, hashcode STRING);

-- Beeline
SELECT * FROM ${DB}.${TABLE}_temp WHERE 1=0 LIMIT 1;
