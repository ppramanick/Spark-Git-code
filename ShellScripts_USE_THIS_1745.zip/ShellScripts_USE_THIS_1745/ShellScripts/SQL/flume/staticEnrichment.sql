set hive.support.quoted.identifiers=none;
set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx12288m -XX:NewRatio=8;
set tez.am.resource.memory.mb=6144;

-- Copy records, add hash
-- cast current_timestamp as string to avoid external/internal copy issues
INSERT OVERWRITE TABLE ${DB}.${TABLE}_stg
SELECT `(hashcode|hivelastupdatetimestamp)?+.+`, current_timestamp as hivelastupdatetimestamp, md5(CONCAT_WS('-',${COLUMNS_CAST})) AS hashcode
FROM ${DB}.${TABLE}_temp;

-- Beeline
SELECT * FROM ${DB}.${TABLE}_stg WHERE 1=0 LIMIT 1;


