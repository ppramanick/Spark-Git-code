set hive.support.quoted.identifiers=none;
-- 4x YARN min container size
set hive.tez.container.size=24576;
-- 1/3 of TEZ container
set hive.auto.convert.join.noconditionaltask.size=8192;
-- 40% of TEZ container
set tez.runtime.io.sort.mb=9830;
-- 10% of TEZ container
set tez.runtime.unordered.output.buffer.size-mb=2457;
-- 75% of the container size
set hive.tez.java.opts=-Xmx18432m -XX:NewRatio=8;
-- equal to container size
set tez.am.resource.memory.mb=6144;

-- Cleanup
DROP TABLE IF EXISTS ${TARGET_DATABASE}.${TABLE}_cdc;


-- Create a temp table which will hold the cdc records after the previous run
CREATE TABLE IF NOT EXISTS ${TARGET_DATABASE}.${TABLE}_cdc LIKE ${TARGET_DATABASE}.${TABLE};

-- Insert all true records in temp table from core table
INSERT INTO TABLE ${TARGET_DATABASE}.${TABLE}_cdc partition(scd_flag) select * from ${TARGET_DATABASE}.${TABLE} where scd_flag=true;

-- Insert new records in temp table from core table
INSERT INTO TABLE ${TARGET_DATABASE}.${TABLE}_cdc partition(scd_flag)
SELECT ${COLUMNS}, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, current_timestamp as start_date, from_unixtime(0) as end_date, true as scd_flag FROM
(
  SELECT t1.* FROM ${SOURCE_DATABASE}.${TABLE} AS t1
  LEFT JOIN ${TARGET_DATABASE}.${TABLE}_cdc as t2
  ON ${JOINS}
  WHERE ${EXCLUDE}
  --AND t1.hivelastupdatetimestamp > '${LAST_CDC_TS}'
) x1;

-- Insert records to temp that were changed in work (records having scd_flag=false)
INSERT INTO TABLE ${TARGET_DATABASE}.${TABLE}_cdc partition(scd_flag)
SELECT ${COLUMNS}, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, x1.start_date as start_date, current_timestamp as end_date, false as scd_flag FROM
(
  SELECT t1.* FROM ${TARGET_DATABASE}.${TABLE}_cdc t1
  INNER JOIN ${SOURCE_DATABASE}.${TABLE} t2
  ON ${JOINS}
  WHERE t1.hashcode <> t2.hashcode
  --AND t2.hivelastupdatetimestamp > '${LAST_CDC_TS}'
) x1;

-- Insert the changed records with scd_flag=false in the core table
INSERT INTO TABLE ${TARGET_DATABASE}.${TABLE} partition(scd_flag) select * from ${TARGET_DATABASE}.${TABLE}_cdc where scd_flag=false;

-- Insert the changed records from temp table into core table with scd_flag=true
INSERT OVERWRITE TABLE ${TARGET_DATABASE}.${TABLE} partition(scd_flag)
SELECT ${COLUMNS}, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, current_timestamp as start_date, from_unixtime(0) as end_date, true as scd_flag FROM
(
  SELECT *, row_number() over (partition by ${PK} order by hivelastupdatetimestamp desc) as row_num FROM ${TARGET_DATABASE}.${TABLE}_cdc
  WHERE scd_flag=true
) x1 where x1.row_num=1;

-- Cleanup
TRUNCATE TABLE ${TARGET_DATABASE}.${TABLE}_cdc;
DROP TABLE IF EXISTS ${TARGET_DATABASE}.${TABLE}_cdc;

select * from ${TARGET_DATABASE}.${TABLE} where 1=0;




