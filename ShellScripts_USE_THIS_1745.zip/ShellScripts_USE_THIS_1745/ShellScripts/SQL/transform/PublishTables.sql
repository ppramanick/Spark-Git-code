set hive.support.quoted.identifiers=none;
-- 4x YARN min container size
set hive.tez.container.size=24576;
-- 1/3 of TEZ container
set hive.auto.convert.join.noconditionaltask.size=8192;
-- 40% of TEZ container
set tez.runtime.io.sort.mb=9830;
-- 10% of TEZ container
set tez.runtime.unordered.output.buffer.size-mb=2457;
-- 75% of the container size
set hive.tez.java.opts=-Xmx18432m -XX:NewRatio=8;
-- equal to container size
set tez.am.resource.memory.mb=6144;

INSERT OVERWRITE TABLE ${PUBLISH_DATABASE}.${TABLE}
SELECT ${COLUMNS}
FROM ${CORE_DATABASE}.${TABLE} t
WHERE scd_flag = true AND hivelastupdatetimestamp > '${LAST_RUN_TIME}';


SELECT * FROM ${CORE_DATABASE}.${TABLE} WHERE 1=0 LIMIT 1;
