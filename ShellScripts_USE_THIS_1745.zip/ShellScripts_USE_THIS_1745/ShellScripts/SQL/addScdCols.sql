--ALTER TABLE ${DATABASE}.${TABLE} ADD COLUMNS (hivelastupdatetimestamp TIMESTAMP, hashcode STRING);
ALTER TABLE ${DATABASE}.${TABLE} ADD COLUMNS (start_date timestamp, end_date timestamp);
ALTER TABLE ${DATABASE}.${TABLE} ADD COLUMNS (scd_flag boolean);
-- test

-- Mitigates Beeline Bug
SELECT * FROM ${DATABASE}.${TABLE} WHERE 1=0 LIMIT 1;