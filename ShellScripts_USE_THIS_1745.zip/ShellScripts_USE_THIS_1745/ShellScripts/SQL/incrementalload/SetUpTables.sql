-- Create DB
CREATE DATABASE IF NOT EXISTS ${WorkDB};
-- Create actual dimension table 
CREATE TABLE IF NOT EXISTS ${WorkDB}.dim_work_${Table} LIKE ${StagingDB}.${StagingTable} STORED AS ORC;
-- Add missing columns
ALTER TABLE ${WorkDB}.dim_work_${Table} ADD COLUMNS (start_date timestamp, end_date timestamp, scd_flag boolean);
-- Add bucketing
ALTER TABLE ${WorkDB}.dim_work_${Table} CLUSTERED BY (${PK}) INTO ${BUCKETS} BUCKETS;
-- Add bucketing stage
ALTER TABLE ${StagingDB}.${Table} CLUSTERED BY (${PK}) INTO ${BUCKETS} BUCKETS;