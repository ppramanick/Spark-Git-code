TRUNCATE TABLE ${WorkDB}.${WorkTable};
-- Copy
INSERT OVERWRITE TABLE ${WorkDB}.${WorkTable}
SELECT t.*,from_unixtime(unix_timestamp()) as start_date, from_unixtime(0) as end_date, true as scd_flag
FROM ${StagingDB}.${StagingTable} t;

select * from ${WorkDB}.${WorkTable} where 1=0;