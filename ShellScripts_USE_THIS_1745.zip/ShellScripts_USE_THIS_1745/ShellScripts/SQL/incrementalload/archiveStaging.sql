SET hive.exec.dynamic.partition.mode = nonstrict;
INSERT OVERWRITE TABLE ${ArchiveDB}.${Table}
PARTITION (CY)
SELECT t.*, CONCAT(year(t.hivelastupdatetimestamp),'-',month(t.hivelastupdatetimestamp)) as CY
FROM ${StagingDB}.${Table} t;

-- Mitigates beeline bug
SELECT * FROM ${ArchiveDB}.${Table} where 1=0;