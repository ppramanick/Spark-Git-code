set hive.support.quoted.identifiers=none;
set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx12288m -XX:NewRatio=8;
set tez.am.resource.memory.mb=6144;

-- Cleanup
DROP TABLE IF EXISTS ${WorkDB}.${WorkTableTemp};

-- Create a temp table (replica of the work table)
CREATE TABLE IF NOT EXISTS ${WorkDB}.${WorkTableTemp} LIKE ${WorkDB}.dim_work_${Table};

-- Insert new records in Staging into work table
INSERT INTO TABLE ${WorkDB}.dim_work_${Table}
SELECT `(hivelastupdatetimestamp|hashcode|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, current_timestamp as start_date, from_unixtime(0) as end_date, true as scd_flag FROM
(
  SELECT t1.* FROM ${StagingDB}.${Table} AS t1
  LEFT JOIN ${WorkDB}.dim_work_${Table} as t2
  ON ${JOINS}
  WHERE ${EXCLUDE}
  AND t1.hivelastupdatetimestamp > '${LAST_CDC_TS}'
) x1;

-- Copy over records to temp from work that were changed in source (scd_flag would be set to false for these records)
INSERT OVERWRITE TABLE ${WorkDB}.${WorkTableTemp}
SELECT `(hivelastupdatetimestamp|hashcode|start_date|end_Date|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode, x1.start_date as start_date, current_timestamp as end_date,false as scd_flag FROM
(
  SELECT t1.* FROM ${WorkDB}.dim_work_${Table} t1
  INNER JOIN ${StagingDB}.${Table} t2
  ON ${JOINS}
  WHERE t1.hashcode <> t2.hashcode
  AND t2.hivelastupdatetimestamp > '${LAST_CDC_TS}'
) x1;

-- Remove the old copy of the changed records in work i.e. overwrite the work table and keep only those records which haven't changed
INSERT OVERWRITE TABLE ${WorkDB}.dim_work_${Table}
SELECT t1.* FROM ${WorkDB}.dim_work_${Table} t1
LEFT JOIN ${WorkDB}.${WorkTableTemp} t2
ON ${JOINS}
WHERE ${EXCLUDE};

-- Insert the changed records with scd_flag=false in the work table
INSERT INTO TABLE ${WorkDB}.dim_work_${Table} select * from ${WorkDB}.${WorkTableTemp};

-- Insert the changed records from staging table into work table with scd_flag=true
INSERT INTO TABLE ${WorkDB}.dim_work_${Table}
SELECT `(hivelastupdatetimestamp|hashcode|start_date|end_Date|scd_flag)?+.+`, current_timestamp as hivelastupdatetimestamp, x1.hashcode as hashcode,current_timestamp as start_date, from_unixtime(0) as end_date,true as scd_flag FROM
(
  SELECT t2.* FROM ${WorkDB}.dim_work_${Table} t1
  INNER JOIN ${StagingDB}.${Table} t2
  ON ${JOINS}
  WHERE t1.hashcode <> t2.hashcode
) x1;

-- Cleanup
DROP TABLE IF EXISTS ${WorkDB}.${WorkTableTemp};

select * from ${WorkDB}.dim_work_${Table} where 1=0;