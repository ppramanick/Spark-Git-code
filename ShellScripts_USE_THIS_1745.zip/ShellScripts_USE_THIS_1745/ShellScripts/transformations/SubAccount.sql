INSERT OVERWRITE TABLE ${WORK_DATABASE}.SubAccount
SELECT
CASE WHEN LENGTH(SubAccountNumber) < 1 THEN '-' ELSE COALESCE(SubAccountNumber, '-') END AS SubAccountNumber, --Natural Key Lookup for PayorPartyID
COALESCE(TRIM(GroupNumber), '-') AS GroupNumber, --Natural Key Lookup for AccountID & PayorPartyID
COALESCE(TRIM(InternalCompanyCode), '-'),
'Group Certificate' AS InsuranceAgreementTypeCode,
COALESCE(TRIM(GroupInsuranceAgreementNumber), '-') AS GroupInsuranceAgreementNumber,
'-' AS SubAccountName,
CASE WHEN LENGTH(TRIM(CAST(SubAccountType AS STRING))) < 1 THEN '-' ELSE COALESCE(SubAccountType,'-') END AS SubAccountType,
COALESCE(SubAccountTerminationReason,0) AS SubAccountTerminationReason, --Look up required
'-' AS OccupationClassCode,
COALESCE(SubAcctEstablishedDate, CAST('1900-01-01' AS DATE)) AS SubAccountEstablishedDate,
COALESCE(TerminationDate, CAST('1900-01-01' AS DATE)) AS SubAccountTerminationDate,
0 AS EmployerContributionAmount,
0 AS EmployerContributionPercentage,
CAST('1900-01-01' AS DATE) AS BillingFromDate,
CAST('1900-01-01' AS DATE) AS BillingToDate,
0 AS BillLeadTimeNumberofDays,
'-' AS BillingLeadTimeMethodCode,
'-' AS BillingTypeCode,
COALESCE(TRIM(BillFrequencyTypeCode), '-') AS BillFrequencyTypeCode,
CurrentRecordInd AS CurrentRecordIndicator,
'Genelco' AS SourceSystemCode,
LogicalDelIndicator AS LogicalDeleteIndicator,
'-' AS PayrollDeductionFrequencyCode,
'-' AS PaymentMethodTypeCode,
CASE WHEN LENGTH(TRIM(SubAccountStatusCode)) < 1 THEN '-' ELSE COALESCE(TRIM(SubAccountStatusCode),'-') END AS SubAccountStatusCode,
'-' AS DisbursementPaymentMethodCode,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS BillingSynchronizationDate,
COALESCE(PremiumPaidTODate, CAST('1900-01-01' AS DATE)) AS PremiumPaidToDate,
0 AS PremiumPaidToDateAmount,
'-' AS InvoiceFrequencyCode,
'-' AS BillDeliveryMethodCode,
0 AS ServicingProducerPartyID,
0 AS ClaimGracePeriodCount,
'-' AS ClaimGracePeriodUnitTypeCode,
'-' AS BillGroupIndicator,
COALESCE(TRIM(SubAccountStatusDescription), '-') AS SubAccountStatusDescription,
current_user() AS LastUpdateUserID,
current_timestamp AS LastUpdateDateTime,
current_timestamp AS hivelastupdatetimestamp,
"0" as hashcode
FROM 
(
  SELECT 
  AMGRP AS GroupNumber,
  TRIM(CAST(AMACCT AS STRING)) AS SubAccountNumber,
  GRP.GCCMPC AS InternalCompanyCode,
  AMGRP AS GroupInsuranceAgreementNumber,
  CAST(CONCAT_WS('-',CONCAT(CAST(CAST(AMEDCY AS INT) AS STRING),lpad(CAST(CAST(AMEDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(AMEDMT AS INT) AS STRING),2,"0"), lpad(CAST(CAST(AMEDDY AS INT) AS STRING),2,"0")) AS DATE) AS SubAcctEstablishedDate,
  CAST(CONCAT_WS('-',CONCAT(CAST(CAST(BUPTCY AS INT) AS STRING),lpad(CAST(CAST(BUPTYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(BUPTMT AS INT) AS STRING),2,"0"), lpad(CAST(CAST(BUPTDY AS INT) AS STRING),2,"0")) AS DATE) AS PremiumPaidTODate,
  AMACTY AS SubAccountType,
  AMTRCD AS SubAccountTerminationReason,
  BUBLMD AS BillFrequencyTypeCode,
  case when AMTDCY <> 0 then
    COALESCE(
      CAST(
        CONCAT_WS('-',CONCAT(CAST(CAST(AMTDCY AS INT) AS STRING),lpad(CAST(CAST(AMTDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(AMTDMT AS INT) AS STRING),2,"0"), lpad(CAST(CAST(AMTDDY AS INT) AS STRING),2,"0"))
        AS DATE
      ), 
      CAST('1900-01-01' AS DATE)
    )
    else CAST('1900-01-01' AS DATE) 
  end AS TerminationDate,
  case when AMTRCD <> 0 then 'Terminated' else 'Active' end AS SubAccountStatusCode,
  case when AMTRCD <> 0 then 'Terminated' else 'Active' end AS SubAccountStatusDescription,
  ACT.LogicalDel_ind AS LogicalDelIndicator,
  case when ACT.LogicalDel_ind = 'N' then 'Y' end AS CurrentRecordInd
  FROM ${WORK_DATABASE}.dim_work_grpctrl GRP
  Inner Join ${WORK_DATABASE}.dim_work_actmstr ACT
  on GRP.GCGRP = ACT.AMGRP AND GRP.scd_flag = true AND ACT.scd_flag = true
  AND GRP.LogicalDel_ind = 'N' AND ACT.LogicalDel_ind = 'N'
  left JOIN ${WORK_DATABASE}.dim_work_bumstr BU
  ON ACT.AMGRP = BU.BUGRP AND BU.LogicalDel_ind = 'N'
  AND ACT.AMACCT = BU.BUACCT AND BU.scd_flag = true
  and AMACCT <=999
  AND AMACCT >= 100 --->= 1000 ported policies ---move individual ppl after they quit the company
) SubAccount;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.SubAccount WHERE 1=0 LIMIT 1;

