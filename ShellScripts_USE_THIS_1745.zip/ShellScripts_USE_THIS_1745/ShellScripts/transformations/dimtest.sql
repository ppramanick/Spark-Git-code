INSERT OVERWRITE TABLE ${DATABASE}.dimtest
SELECT d.Driver_Id, p.Policy_Id FROM ${DATABASE}.dim_work_Driver d
LEFT OUTER JOIN ${DATABASE}.dim_work_Policy p
ON d.Driver_Id = p.Driver_Id
WHERE d.end_date=from_unixtime(1) AND p.end_date=from_unixtime(1);