INSERT OVERWRITE TABLE ${WORK_DATABASE}.PMCPartyContact
SELECT
PartyContact.NPN AS NPN,
PartyContact.PartyContactRoleCode  AS PartyContactRoleCode,  
partyContact.PreferredContactTypeCode AS PreferredContactTypeCode,
PartyContact.FullName AS FullName,                
PartyContact.AddressLine1 AS AddressLine1,            
PartyContact.AddressLine2 AddressLine2,            
'-' AS AddressLine3,            
PartyContact.AddressCityName AS AddressCityName ,        
PartyContact.AddressPostalCode AS AddressPostalCode,       
PartyContact.StateCode  AS StateCode,              
PartyContact.CountryCode AS CountryCode,            
PartyContact.EmailAddressName  AS EmailAddressName,       
PartyContact.ContactTitle   AS ContactTitle,         
PartyContact.FirstName AS FirstName,             
PartyContact.LastName   AS LastName,             
PartyContact.MiddleName  AS MiddleName,            
CURRENT_TIMESTAMP AS LastUpdateDateTime,    
'Y' AS CurrentRecordIndicator, 
'VUE' AS SourceSystemCode,      
'N' AS LogicalDeleteIndicator, 
CURRENT_USER() AS LastUpdateUserID,
CURRENT_TIMESTAMP AS hivelastupdatetimestamp,
'0' AS hashcode
FROM
(
  SELECT
  CASE WHEN TRIM(NPN) = '' OR NPN IS NULL
  THEN '-'
  ELSE TRIM(NPN)
  END AS NPN,
  CASE WHEN TRIM(PC.FieldOfficeContactCode) = '' OR PC.FieldOfficeContactCode IS NULL
  THEN '-'
  ELSE TRIM(PC.FieldOfficeContactCode)
  END AS PartyContactRoleCode,
  CASE WHEN TRIM(PC.PREFERREDCONTACTMODE) = '' OR PC.PREFERREDCONTACTMODE IS NULL
  THEN '-'
  ELSE TRIM(PC.PREFERREDCONTACTMODE)
  END AS PreferredContactTypeCode,
  CASE WHEN TRIM(PC.FIRSTNAME) = '' OR PC.FIRSTNAME IS NULL
  THEN '-'
  ELSE TRIM(PC.FIRSTNAME)
  END AS FullName,
  CASE WHEN TRIM(PC.AddressLine1) = '' OR PC.AddressLine1 IS NULL
  THEN '-'
  ELSE TRIM(PC.AddressLine1)
  END AS AddressLine1,
  CASE WHEN TRIM(PC.AddressLine2) = '' OR PC.AddressLine2 IS NULL
  THEN '-'
  ELSE TRIM(PC.AddressLine2)
  END AS AddressLine2,
  CASE WHEN TRIM(PC.City) = '' OR PC.City IS NULL
  THEN '-'
  ELSE TRIM(PC.City)
  END AS AddressCityName,
  CASE WHEN TRIM(PC.ZipCode) = '' OR PC.ZipCode IS NULL
  THEN '-'
  ELSE TRIM(PC.ZipCode)
  END AS AddressPostalCode,
  CASE WHEN TRIM(PC.STATE) = '' OR PC.STATE IS NULL
  THEN '-'
  ELSE TRIM(PC.STATE)
  END AS StateCode,
  CASE WHEN TRIM(PC.Country) = '' OR PC.Country IS NULL
  THEN '-'
  ELSE TRIM(PC.Country)
  END AS CountryCode,
  CASE WHEN TRIM(PC.BusinessEmail) = '' OR PC.BusinessEmail IS NULL
  THEN '-'
  ELSE TRIM(PC.BusinessEmail)
  END AS EmailAddressName,
  CASE WHEN TRIM(PC.TITLE) = '' OR PC.TITLE IS NULL
  THEN '-'
  ELSE TRIM(PC.TITLE)
  END AS ContactTitle,
  CASE WHEN TRIM(PC.FirstName) = '' OR PC.FirstName IS NULL
  THEN '-'
  ELSE TRIM(PC.FirstName)
  END AS FirstName,
  CASE WHEN TRIM(PC.LastName) = '' OR PC.LastName IS NULL
  THEN '-'
  ELSE TRIM(PC.LastName)
  END AS LastName,
  CASE WHEN TRIM(PC.MiddleName) = '' OR PC.MiddleName  IS NULL
  THEN '-'
  ELSE TRIM(PC.MiddleName)
  END AS MiddleName
  FROM ${WORK_DATABASE}.dim_work_agentdemographics PC
  WHERE PC.scd_flag = true
)  PartyContact
WHERE NPN <> '-' AND PartyContactRoleCode <> '-';


-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PMCPartyContact WHERE 1=0 LIMIT 1;

