INSERT OVERWRITE TABLE ${WORK_DATABASE}.BillLine
SELECT
COALESCE(AccountLineNumber,'-') as AccountLineNumber, -- Natural key
COALESCE(BillNumber,'-') as BillNumber, -- Natural Key
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS BillLineEffectiveDate,
CAST(CAST('9999-12-31' AS DATE) AS TIMESTAMP) AS BillLineEndDate,
'-' AS BillLineIsAdjustmentIndicator,
0 AS BillLineAmountWIthoutTax,
0 AS BillLinePaidAmount,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS BillLineTransactionMonthStartDate,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS BillLineReversalMonthStartDate,
0 AS BillLineUnAllocatedAmount,
0 AS BillLineDayPriceAmount,
0 AS BillLineGroupContributionAmount,
0 AS BillLineDayPriceWithoutTaxAmount,
0 AS BillLineGroupContributionWithoutTaxAmount,
0 AS BillLineMemberContributionAmount,
0 AS BIllLineMemberContributionWithoutTaxAmount,
'-' AS BillLineStatusCode,
'Y' AS CurrentRecordIndicator,
'Genelco' AS SourceSystemCode,
'N' AS LogicalDeleteIndicator,
0 AS ProductCoverageID,
0 AS MemberInsuranceAgreementID,
0 AS BillLineAmount,
0 AS GroupInsuranceAgreementID,
current_user() AS LastUpdateUserID,
current_timestamp AS LastUpdateDateTime,
current_timestamp AS HiveUpdateTimestamp,
'0' as hashcode
FROM
(
  SELECT BillLine.* from
  (
    SELECT
    CONCAT_WS
    (
      '-',
      TRIM(EBGRP),
      CAST(CAST(EBACCT AS INT) as STRING),
      CAST(CAST((EBSDCY * 1000000 + EBSDYR * 10000 + EBSDMT * 100 + EBSDDY) AS INT) as STRING),
      CAST(CAST(EBTRLN AS INT) as STRING),
      TRIM(EBINVN),
      TRIM(EBUSER)
    ) AS BillNumber,
    CAST(MAX(EBSTIM) AS INT) AS TMSTMP ---- taking max timestamp to eliminate duplicate bill records
    from ${WORK_DATABASE}.dim_work_BILLHIST A
    WHERE A.scd_flag = true AND A.LogicalDel_ind = 'N' 
    AND A.EBSSN = '0000000000' AND EBACCT >= 100 AND EBINVN>' ' AND EBTTPC>0
    GROUP BY EBGRP, EBACCT, EBSDCY, EBSDYR, EBSDMT, EBSDDY, EBTRLN, EBINVN, EBUSER
  ) Bill
  INNER JOIN
  (
    SELECT
    CONCAT_WS
    (
      '-',
      TRIM(EBGRP),
      CAST(CAST(EBACCT AS INT) as STRING),
      CAST(CAST((EBSDCY * 1000000 + EBSDYR * 10000 + EBSDMT * 100 + EBSDDY) AS INT) as STRING),
      CAST(CAST(EBTRLN AS INT) as STRING),
      TRIM(EBINVN),
      TRIM(EBUSER)
    ) AS BillNumber,
    CONCAT_WS
    (
      '-',
      TRIM(EBGRP),
      CAST(CAST(EBACCT AS INT) AS STRING),
      CAST(CAST((EBSDCY * 1000000 + EBSDYR * 10000 + EBSDMT * 100 + EBSDDY) AS INT) AS STRING),
      CAST(CAST(EBSTIM AS INT) AS STRING),
      TRIM(EBSSN),
      CAST(CAST(EBTRLN AS INT) AS STRING),
      TRIM(EBUSER)
    ) AS AccountLineNumber,    
    CAST(EBSTIM AS INT) AS TMSTMP, ------- BillLine is generated after the bill    
    '-' as GroupInsuranceAgreementNumber--,
    FROM ${WORK_DATABASE}.dim_work_BILLHIST
    WHERE EBSSN > '0000000000'
    AND EBACCT >= 100
    AND EBINVN>' '
    and EBTTPC>0
  ) BillLine
  on Bill.BillNumber = BillLine.BillNumber
  WHERE Bill.TMSTMP < BillLine.TMSTMP

) BillLineTransform;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.BillLine WHERE 1=0 LIMIT 1;


