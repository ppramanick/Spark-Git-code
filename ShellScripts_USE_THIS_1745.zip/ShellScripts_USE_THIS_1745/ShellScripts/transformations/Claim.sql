INSERT OVERWRITE TABLE ${WORK_DATABASE}.Claim
SELECT
Claim.ClaimNumber as ClaimNumber,
Claim.SourceGNLGroupNumber as SourceGNLGroupNumber,
Claim.SourceGNLParticipantID as SourceGNLParticipantID,
Claim.SourceGNLDependentSequenceNumber as SourceGNLDependentSequenceNumber,
Claim.MemberInsuranceAgreementNumber as MemberInsuranceAgreementNumber,
'1900-01-01 00:00:00' as ClaimCreationDateTime,
'1900-01-01 00:00:00' as ClaimIncurredDate,
0.00 as ClaimTotalBenefitAmount,
Claim.ClaimCloseDate as ClaimCloseDate,
'-' as ClaimExaminerEmployeeNumber,
'-' as ClaimApproverEmployeeNumber,
Claim.ClaimNoteText as ClaimNoteText,
Claim.ClaimReceivedDate as ClaimReceivedDate,
'-' as ClaimDecisionCode,
'-' as ClaimStatusReasonCode,
Claim.ClaimStatusTypeCode as ClaimStatusTypeCode,
'1900-01-01' as ClaimStatusDate,
0.00 as BenefitChargedNotCoveredAmount,
'-' as ClaimTreatmentDecisionReasonCode,
0.00 as ClaimOverPaymentAmount,
0.00 as ClaimFeeAmount,
'-' as ClaimFeeBudgetCenter,
CURRENT_TIMESTAMP as LastUpdateDateTime,
Claim.CurrentRecordInd as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
Claim.LogicalDel_ind as LogicalDeleteIndicator,
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetimestamp,
"0" as hashcode
FROM (
SELECT
trim(coalesce(concat(CASE WHEN LENGTH(Cast(CSJYR AS INT)) = 1 THEN concat('0',cast(Cast(CSJYR AS INT) as varchar(10))) ELSE cast(Cast(CSJYR AS INT) as varchar(10)) END,
CASE WHEN LENGTH(Cast(CSJDAY AS INT)) = 1 THEN concat('00',cast(Cast(CSJDAY AS INT) as varchar(10))) WHEN LENGTH(Cast(CSJDAY AS INT))  = 2 THEN concat('0',cast(Cast(CSJDAY AS INT) as varchar(10))) ELSE cast(Cast(CSJDAY AS INT) as varchar(10)) END, CASE WHEN LENGTH(Cast(CSSEQ AS INT)) = 1  THEN concat('000',cast(Cast(CSSEQ AS INT) as varchar(10))) WHEN LENGTH(Cast(CSSEQ AS INT)) = 2 THEN concat('00',cast(Cast(CSSEQ AS INT) as varchar(10))) WHEN LENGTH(Cast(CSSEQ AS INT)) = 3 THEN concat('0',cast(Cast(CSSEQ AS INT) as varchar(10))) ELSE Cast(CSSEQ AS INT) END, Cast(TRIM(CSSUFX) AS VARCHAR(10))),'-')) AS ClaimNumber,
CSGRP as SourceGNLGroupNumber,
COALESCE(TRIM(CSSSN), '0000000000') AS SourceGNLParticipantID,
CSDSEQ as SourceGNLDependentSequenceNumber,
concat_ws('-',EMP.EEGRP,EMP.EECERT,SUBSTR(EMP.EESSN,-4)) as MemberInsuranceAgreementNumber,
CASE WHEN CSRECY = 0 OR CSREYR = 0 OR CSREMT = 0 OR CSREDY= 0 THEN cast('1900-01-01' as date) ELSE CAST(CONCAT_WS('-',CONCAT(CAST(CAST(CSRECY AS INT) AS STRING),lpad(CAST(CAST(CSREYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(CSREMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(CSREDY AS INT) AS STRING),2,"0")) AS DATE) END AS ClaimReceivedDate,
CASE WHEN CSLACY = 0 OR CSLAYR = 0 OR CSLAMT = 0 OR CSLADY= 0 THEN cast('1900-01-01' as date) ELSE CAST(CONCAT_WS('-',CONCAT(CAST(CAST(CSLACY AS INT) AS STRING),lpad(CAST(CAST(CSLAYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(CSLAMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(CSLADY AS INT) AS STRING),2,"0")) AS DATE) END AS ClaimCloseDate,
trim(coalesce(CSCMNT,'-')) AS ClaimNoteText,
trim(coalesce(CASE WHEN CSPCLM ='P' THEN 'PENDING' ELSE CSCLST END,'-')) AS ClaimStatusTypeCode,
'N' as LogicalDel_ind,
'Y' AS CurrentRecordInd
FROM ${WORK_DATABASE}.dim_work_CSRMSTR CSR
INNER JOIN ${WORK_DATABASE}.dim_work_EMPMSTR EMP
ON CSR.CSGRP = EMP.EEGRP
AND CSR.CSSSN = EMP.EESSN
WHERE CSR.LogicalDel_ind = 'N' and CSR.scd_flag=true and EMP.LogicalDel_ind = 'N' and EMP.scd_flag=true
) Claim;


-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.Claim WHERE 1=0 LIMIT 1;