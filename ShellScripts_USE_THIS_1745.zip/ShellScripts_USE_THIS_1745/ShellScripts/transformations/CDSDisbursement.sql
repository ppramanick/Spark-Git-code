INSERT OVERWRITE TABLE ${WORK_DATABASE}.CDSDisbursement
SELECT
-1 AS DisbursementRecipientPartyID,
'-' AS DisbursementOperationCode,
DisbursementAmount AS DisbursementAmount,
COALESCE(DisbursementCreationDate, CAST('1900-01-01' AS DATE)) AS DisbursementCreationDate,
CAST('1900-01-01' AS DATE) AS DisbursementSentDate,
COALESCE(DisbursementCashedDate, CAST('1900-01-01' AS DATE)) AS DisbursementCashedDate,
CAST('1900-01-01' AS DATE) AS DisbursementCancelDate,
'-' AS DisbursementMoneyChannelCode,
DisbursementNumber AS DisbursementNumber,
'-' AS DisbursementTypeCode,
DisbursementCancelReason AS DisbursementCancelReasonCode,
DisbursementPaymentMethodCode AS DisbursementPaymentMethodCode,
0.00 AS InterestPaymentAmount,
DisbursementStatusCode AS DisbursementStatusCode,
'-' AS BackupWithholdingIndicator,
0.00 AS TaxWithholdingAmount,
CAST('1900-01-01' AS DATE) AS DisbursementStatusDate,
DisbursementPaymentMethodNumber AS DisbursementPaymentMethodNumber,
DisbursementRequestSourceSystemCode AS DisbursementRequestSourceSystemCode,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS BackupWIthholdingDate,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS BackupWithholdingStopDate,
0.00 AS BackupWithholdingAmount,
CAST(DisbursementCreationTime AS TIMESTAMP) AS DisbursementCreationTime,
COALESCE(DisbursementPaymentTypeCode, '-') AS DisbursementPaymentTypeCode,
'-' AS InternalCompanyCode,
ACHReturnCode AS ACHReturnCode,
'-' AS BackupWithholdingRemarkCode,
CheckStatus AS DisbursementCheckStatusCode,
IssueTypeCode AS DisbursementIssueTypeCode,
'Y' AS CurrentRecordIndicator,
'FSCD' AS SourceSystemCode,
'N' AS LogicalDeleteIndicator,
current_timestamp AS LastUpdateDateTime,
current_user() AS LastUpdateUserID,
current_timestamp AS hivelastupdatetimestamp,
'0' AS hashcode
FROM
(
  SELECT

  CASE WHEN TRIM(DisbursementNumber) = '' OR TRIM(DisbursementNumber) = ' ' OR TRIM(DisbursementNumber) IS NULL
    THEN '-'
    ELSE COALESCE(TRIM(DisbursementNumber), '-')
  END AS DisbursementNumber,

  CASE WHEN TRIM(DisbursementRequestSourceSystemCode) = '' OR TRIM(DisbursementRequestSourceSystemCode) = ' ' OR TRIM(DisbursementRequestSourceSystemCode) IS NULL
    THEN '-'
    WHEN LOWER(TRIM(DisbursementRequestSourceSystemCode)) = 'wynsure'
    THEN 'WYN'
    ELSE COALESCE(TRIM(DisbursementRequestSourceSystemCode), '-')
  END AS DisbursementRequestSourceSystemCode,

  CASE WHEN TRIM(DisbursementPaymentMethodCode) = '' OR TRIM(DisbursementPaymentMethodCode) = ' ' OR TRIM(DisbursementPaymentMethodCode) IS NULL
    THEN '-'
    ELSE COALESCE(TRIM(DisbursementPaymentMethodCode), '-')
  END AS DisbursementPaymentMethodCode,

  CASE WHEN TRIM(CheckNumber) = '' OR TRIM(CheckNumber) = ' ' OR TRIM(CheckNumber) IS NULL
    THEN '-'
    ELSE COALESCE(TRIM(CheckNumber), '-')
  END AS  DisbursementPaymentMethodNumber,

  CASE WHEN TRIM(PaymentTypeCode) = '' OR TRIM(PaymentTypeCode) = ' ' OR TRIM(PaymentTypeCode) IS NULL
    THEN '-'
    ELSE COALESCE(TRIM(PaymentTypeCode), '-')
  END AS  DisbursementPaymentTypeCode,
  COALESCE
  (
    CASE
    WHEN TRIM(PaymentDateText) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(PaymentDateText), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(PaymentDateText) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(PaymentDateText), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(PaymentDateText) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(PaymentDateText), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(PaymentDateText) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(PaymentDateText), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      ELSE CAST(TRIM(PaymentDateText) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS DisbursementCreationDate,

  CASE WHEN TRIM(DisbursedStatusCode) = '' OR TRIM(DisbursedStatusCode) = ' ' OR TRIM(DisbursedStatusCode) IS NULL
    THEN '-'
    ELSE COALESCE(TRIM(DisbursedStatusCode), '-')
  END AS DisbursementStatusCode,

  CASE WHEN TRIM(CheckStatus) = '' OR TRIM(CheckStatus) = ' ' OR TRIM(CheckStatus) IS NULL
    THEN '-'
    ELSE COALESCE(TRIM(CheckStatus), '-')
  END AS CheckStatus,
  COALESCE(CAST(DisbursementAmount AS DOUBLE), 0) AS DisbursementAmount,
 
  CASE WHEN TRIM(IssueTypeCode) = '' OR TRIM(IssueTypeCode) = ' ' OR TRIM(IssueTypeCode) IS NULL
    THEN '-'
    ELSE COALESCE(TRIM(IssueTypeCode), '-')
  END AS  IssueTypeCode,

  CASE WHEN TRIM(ACHReturnCode) = '' OR TRIM(ACHReturnCode) = ' '
    THEN '-'
    ELSE COALESCE(TRIM(ACHReturnCode), '-')
  END AS  ACHReturnCode,

  COALESCE
  (
    CASE
    WHEN TRIM(DisbursementCashedDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCashedDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(DisbursementCashedDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCashedDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(DisbursementCashedDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCashedDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(DisbursementCashedDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCashedDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      ELSE CAST(TRIM(DisbursementCashedDate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS DisbursementCashedDate,

  COALESCE
  (
    CASE
    WHEN TRIM(DisbursementCreationTime) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCreationTime), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(DisbursementCreationTime) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCreationTime), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(DisbursementCreationTime) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCreationTime), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(DisbursementCreationTime) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCreationTime), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      ELSE CAST(TRIM(DisbursementCreationTime) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS DisbursementCreationTime,

  COALESCE
  (
    CASE
    WHEN TRIM(DisbursementCancelDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCancelDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(DisbursementCancelDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCancelDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(DisbursementCancelDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCancelDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(DisbursementCancelDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DisbursementCancelDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      ELSE CAST(TRIM(DisbursementCancelDate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS DisbursementCancelDate,

  CASE WHEN TRIM(DisbursementCancelReason) = '' OR TRIM(DisbursementCancelReason) IS NULL
    THEN '-'
    ELSE TRIM(DisbursementCancelReason)
  END AS DisbursementCancelReason

  FROM ${WORK_DATABASE}.dim_work_cds
) CDSDisbursement;



-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.CDSDisbursement WHERE 1=0 LIMIT 1;




