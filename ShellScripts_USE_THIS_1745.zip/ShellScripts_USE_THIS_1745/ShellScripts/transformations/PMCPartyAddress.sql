INSERT OVERWRITE TABLE ${WORK_DATABASE}.PMCPartyAddress
SELECT 
partyAddr.NPN AS NPN,
'-' AS PartyAddressCategoryCode,          
'-' AS AddressLine1,                      
'-' AS AddressLine2 ,                     
'-' AS AddressLine3 ,                     
'-' AS AddressCityName ,                  
'-' AS AddressPostalCode,                 
'-' AS StateCode,                         
partyAddr.PreferredAddressCategoryIndicator AS PreferredAddressCategoryIndicator,
'-' AS CountryCode ,                      
'-' AS AddressValidationIndicator,        
CURRENT_TIMESTAMP AS LastUpdateDateTime,                
'Y' AS CurrentRecordIndicator ,           
'VUE' AS SourceSystemCode ,                 
'N' AS LogicalDeleteIndicator ,           
CURRENT_USER() AS LastUpdateUserID,                
partyAddr.County AS County,
CURRENT_TIMESTAMP AS hivelastupdatetimestamp,
'0' AS hashcode
FROM
(
  SELECT
  CASE WHEN TRIM(NPN) = '' OR TRIM(NPN) IS NULL
    THEN '-'
    ELSE TRIM(NPN)
  END AS NPN,
  CASE WHEN AD.IsPrimary = 1
    THEN 'Y'
    ELSE 'N' 
  END AS PreferredAddressCategoryIndicator,
  CASE WHEN TRIM(AD.County) = '' OR AD.County IS NULL
    THEN '-'
    ELSE TRIM(AD.County)
  END AS County
  FROM ${WORK_DATABASE}.dim_work_AgentDemographics AD
  WHERE AD.scd_flag = true
) partyAddr
WHERE npn <> '-';




--Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PMCPartyAddress WHERE 1=0 LIMIT 1;


