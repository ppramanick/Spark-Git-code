set hive.support.quoted.identifiers=none;
-- 4x YARN min container size
set hive.tez.container.size=24576;
-- 1/3 of TEZ container
set hive.auto.convert.join.noconditionaltask.size=8192;
-- 40% of TEZ container
set tez.runtime.io.sort.mb=9830;
-- 10% of TEZ container
set tez.runtime.unordered.output.buffer.size-mb=2457;
-- 75% of the container size
set hive.tez.java.opts=-Xmx18432m -XX:NewRatio=8;
-- equal to container size
set tez.am.resource.memory.mb=6144;

INSERT OVERWRITE TABLE ${WORK_DATABASE}.PMCDisbursement
SELECT
PMCDISBR.NPN AS NPN,
'-' AS DisbursementOperationCode,
0 AS DisbursementRecipientPartyID,
0 AS DisbursementAmount,
'1900-01-01 00:00:00.000000' AS DisbursementCreationDate,
'1900-01-01' AS DisbursementSentDate,
'1900-01-01' AS DisbursementCashedDate,
'1900-01-01' AS DisbursementCancelDate,
'-' AS DisbursementMoneyChannelCode,
PMCDISBR.DisbursementNumber AS DisbursementNumber,
'Commission' AS DisbursementTypeCode,
'-' AS DisbursementCancelReasonCode,
'-' AS DisbursementPaymentMethodCode,
0.0 AS InterestPaymentAmount,
'-' AS DisbursementStatusCode,
'-' AS BackupWithholdingIndicator,
0.0 AS TaxWithholdingAmount,
'1900-01-01' AS DisbursementStatusDate,
0.0 AS DisbursementPaymentMethodNumber,
'-' AS DisbursementRequestSourceSystemCode,
'1900-01-01 00:00:00.000000'  AS BackupWIthholdingDate,
'1900-01-01 00:00:00.000000'  AS BackupWithholdingStopDate,
0.0 AS BackupWithholdingAmount,
CURRENT_TIMESTAMP AS LastUpDateTime,
'Y' AS CurrentRecordIndicator,
'VUE' AS SourceSystemCode,
'N' AS LogicalDeleteIndicator,
CURRENT_USER() AS LastUpDateUserID,
'1900-01-01 00:00:00.000000' AS DisbursementCreationTime,
'-' AS DisbursementPaymentTypeCode,
'-' AS InternalCompanyCode,
'-' AS ACHReturnCode,
'-' AS BackupWithholdingRemarkCode,
'-' AS DisbursementCheckStatusCode,
'-' AS DisbursementIssueTypeCode,
current_timestamp AS hivelastupdatetimestamp,
"0" as hashcode
FROM
(
  SELECT 
  CASE WHEN TRIM(NPN) = '' OR NPN is NULL
    THEN '-'
    ELSE TRIM(NPN) 
  END AS NPN, 
  COALESCE(TRIM(DepositNumber) , '-') AS DisbursementNumber
  FROM ${WORK_DATABASE}.dim_work_commissions a
  INNER JOIN ${WORK_DATABASE}.dim_work_agentdemographics b
  on TRIM(a.agentcode)=TRIM(b.agentcode)
  AND a.scd_flag = true AND b.scd_flag = true
) PMCDISBR
WHERE NPN <> '-';

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PMCDisbursement WHERE 1=0 LIMIT 1;


