INSERT OVERWRITE TABLE ${WORK_DATABASE}.InsuranceAgreement -- Use this 1st line of SQL only to Load data between stage to work otherwise start with select statement of the query
SELECT
AccountNumber,
COALESCE(TRIM(InternalCompanyCode),'-') as InternalCompanyCode,
COALESCE(TRIM(InsuranceAgreementNumber),'-') as InsuranceAgreementNumber,
InsuranceAgreementTypeCode,
InsuranceAgreementEffectiveDate,
InsuranceAgreementEndDate,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS SignatureDate,
CAST(CAST('9999-12-31' AS DATE) AS TIMESTAMP) AS TerminationDate,
CAST(CAST('9999-12-31' AS DATE) AS TIMESTAMP) AS RenewalDate,
'-' AS BillingActivatedIndicator,
'-' AS InsuranceAgreementStatusCode,
'-' AS IssueStateCode,
OriginalIssueDate,
IssueDate,
'-' AS InsuranceAgreementModificationapprovalUserID,
CurrentRecordInd,
'Genelco' AS SourceSystemCode,
LogicalDel_ind,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS InsuranceAgreementStatusDate,
current_user() AS LastUpdateUserID,
current_timestamp AS LastUpdateDateTime,
current_timestamp AS HiveLastUpdateDateTimeStamp,
0 AS HashCode
FROM
(
  SELECT 
  AccountNumber,
  InsuranceAgreementNumber,
  InternalCompanyCode,
  COALESCE(IssueDate, CAST('9999-12-31' AS DATE)) AS IssueDate,
  COALESCE(InsuranceAgreementEffectiveDate, CAST('9999-12-31' AS DATE)) AS InsuranceAgreementEffectiveDate,
  COALESCE(InsuranceAgreementEndDate, CAST('9999-12-31' AS DATE)) AS InsuranceAgreementEndDate,
  COALESCE(OriginalIssueDate, CAST('9999-12-31' AS DATE)) AS OriginalIssueDate,
  LogicalDel_ind,
  CurrentRecordInd,
  InsuranceAgreementTypeCode
  FROM
  (
    SELECT 
    TRIM(GRP.GCGRP) AS AccountNumber,
    TRIM(GRP.GCGRP) AS InsuranceAgreementNumber, 
    COALESCE(TRIM(GRP.GCCMPC), '-') AS InternalCompanyCode,
    '0000000000' AS SourceGNLParticipantID,
    0 AS SourceGNLAccountNumber,
    MIN(CAST(concat_ws('-',concat(CAST(PDEFCY AS INT),SUBSTR(CONCAT('0',cast(CAST(PDEFYR AS INT) as string)),-2)),SUBSTR(CONCAT('0',cast(CAST(PDEFMT AS INT) as string)),-2),SUBSTR(CONCAT('0',cast(CAST(PDEFDY AS INT) as string)),-2)) AS date)) AS IssueDate,
    MIN(CAST(concat_ws('-',concat(CAST(PDEDCY AS INT),SUBSTR(CONCAT('0',cast(CAST(PDEDYR AS INT) as string)),-2)),SUBSTR(CONCAT('0',cast(CAST(PDEDMT AS INT) as string)),-2),SUBSTR(CONCAT('0',cast(CAST(PDEDDY AS INT) as string)),-2)) AS date)) AS InsuranceAgreementEffectiveDate,
    MAX(case when PDTDCY = 0 then CAST('9999-12-31' AS DATE) else CAST(concat_ws('-',concat(CAST(PDTDCY AS INT),SUBSTR(CONCAT('0',cast(CAST(PDTDYR AS INT) as string)),-2)),SUBSTR(CONCAT('0',cast(CAST(PDTDMT AS INT) as string)),-2),SUBSTR(CONCAT('0',cast(CAST(PDTDDY AS INT) as string)),-2)) AS date) end) InsuranceAgreementEndDate,----- if 0/0/000 then 12-31-9999
    MIN(CAST(concat_ws('-',concat(CAST(PDEFCY AS INT),SUBSTR(CONCAT('0',cast(CAST(PDEFYR AS INT) as string)),-2)),SUBSTR(CONCAT('0',cast(CAST(PDEFMT AS INT) as string)),-2),SUBSTR(CONCAT('0',cast(CAST(PDEFDY AS INT) as string)),-2)) AS date)) AS OriginalIssueDate,
    GRP.LogicalDel_ind AS LogicalDel_ind,
    case when GRP.LogicalDel_ind = 'N' then 'Y'else 'N' end AS CurrentRecordInd,
    'Group Certificate' AS InsuranceAgreementTypeCode
    from ${WORK_DATABASE}.dim_work_GRPCTRL GRP
    inner join ${WORK_DATABASE}.dim_work_PDTDEFN PDT
    on GRP.GCGRP = PDT.PDGRP
    AND GRP.scd_flag = true and PDT.scd_flag = true
    AND GRP.LogicalDel_ind = 'N' AND PDT.LogicalDel_ind = 'N'
    GROUP BY GCGRP, GCCMPC, GRP.LogicalDel_ind 

    union all
    
    select 
    TRIM(GRP.GCGRP) AS AccountNumber,
    CONCAT_WS('-', TRIM(COV.CVGRP),TRIM(EMP.EECERT), SUBSTR(EESSN, -4)) as InsuranceAgreementNumber, ---pdlobc not found in the below tables
    COALESCE(TRIM(GRP.GCCMPC), '-') AS InternalCompanyCode,
    max(EMP.EESSN) AS SourceGNLParticipantID,
    max(COV.CVACCT) AS SourceGNLAccountNumber,
    MIN(CAST(concat_ws('-',concat(CAST(CVIHCY AS INT),SUBSTR(CONCAT('0',cast(CAST(CVIHYR AS INT) as string)),-2)),SUBSTR(CONCAT('0',cast(CAST(CVIHMT AS INT) as string)),-2),SUBSTR(CONCAT('0',cast(CAST(CVIHDY AS INT) as string)),-2)) AS date)) AS IssueDate,
    MIN(CAST(concat_ws('-',concat(CAST(CVEDCY AS INT),SUBSTR(CONCAT('0',cast(CAST(CVEDYR AS INT) as string)),-2)),SUBSTR(CONCAT('0',cast(CAST(CVEDMT AS INT) as string)),-2),SUBSTR(CONCAT('0',cast(CAST(CVEDDY AS INT) as string)),-2)) AS date)) AS InsuranceAgreementEffectiveDate,
    MAX(CAST(concat_ws('-',concat(CAST(CVTDCY AS INT),SUBSTR(CONCAT('0',cast(CAST(CVTDYR AS INT) as string)),-2)),SUBSTR(CONCAT('0',cast(CAST(CVTDMT AS INT) as string)),-2),SUBSTR(CONCAT('0',cast(CAST(CVTDDY AS INT) as string)),-2)) AS date)) AS InsuranceAgreementEndDate,
    MIN(CAST(concat_ws('-',concat(CAST(CVIHCY AS INT),SUBSTR(CONCAT('0',cast(CAST(CVIHYR AS INT) as string)),-2)),SUBSTR(CONCAT('0',cast(CAST(CVIHMT AS INT) as string)),-2),SUBSTR(CONCAT('0',cast(CAST(CVIHDY AS INT) as string)),-2)) AS date)) AS OriginalIssueDate, ----Translate to 8 digit and convert
    EMP.LogicalDel_ind AS LogicalDel_ind,
    case when EMP.LogicalDel_ind = 'N' then 'Y'else 'N' end AS CurrentRecordInd,
    'Individual Certificate' AS InsuranceAgreementTypeCode
    from ${WORK_DATABASE}.dim_work_GRPCTRL GRP
    inner join ${WORK_DATABASE}.dim_work_COVMSTR COV
    on GRP.GCGRP = COV.CVGRP
    AND GRP.scd_flag = true AND COV.scd_flag = true
    AND GRP.LogicalDel_ind = 'N' AND COV.LogicalDel_ind = 'N'
    INNER join ${WORK_DATABASE}.dim_work_EMPMSTR EMP
    ON COV.CVGRP = EMP.EEGRP
    AND COV.CVSSN = EMP.EESSN 
    AND EMP.EECERT <> '0000000000'
    and COV.CVTDCY = 0
    AND EMP.LogicalDel_ind = 'N'
    and EMP.scd_flag = true
    GROUP BY CVGRP, EECERT, GCCMPC, EMP.LogicalDel_ind, GCGRP, SUBSTR(EESSN,-4)
  ) IA

)TransformQuery;


-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.InsuranceAgreement WHERE 1=0 LIMIT 1;


