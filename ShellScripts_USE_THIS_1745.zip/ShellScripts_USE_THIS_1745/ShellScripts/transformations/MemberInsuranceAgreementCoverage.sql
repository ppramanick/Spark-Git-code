set hive.support.quoted.identifiers=none;
set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx12288m -XX:NewRatio=8;
set tez.am.resource.memory.mb=6144;

INSERT OVERWRITE TABLE ${WORK_DATABASE}.MemberInsuranceAgreementCoverage
SELECT
MemberInsuranceAgreementCoverage.MemberInsuranceAgreementNumber as MemberInsuranceAgreementNumber,
CASE WHEN LENGTH(MemberInsuranceAgreementCoverage.InternalCompanyCode) < 1 THEN '-' ELSE 
  COALESCE(MemberInsuranceAgreementCoverage.InternalCompanyCode, '-') END AS InternalCompanyCode,
MemberInsuranceAgreementCoverage.InsuranceAgreementTypeCode as InsuranceAgreementTypeCode,
MemberInsuranceAgreementCoverage.ProductCode as ProductCode,
MemberInsuranceAgreementCoverage.GroupInsuranceAgreementNumber as GroupInsuranceAgreementNumber,
MemberInsuranceAgreementCoverage.GroupInsuranceAgreementTypeCode as GroupInsuranceAgreementTypeCode,
MemberInsuranceAgreementCoverage.MemberInsuranceAgreementCoverageEffectiveDate as MemberInsuranceAgreementCoverageEffectiveDate,
MemberInsuranceAgreementCoverage.MemberInsuranceAgreementCoverageEndDate as MemberInsuranceAgreementCoverageEndDate,
0.00 as AnnualPremiumAmount,
'-' as MemberInsuranceAgreementCoverageStatusCode,
0.00 as RequestedCoverageBenefitAmount,
'-' as CoverageTypeCode,
'-' as MemberInsuranceAgreementCoverageTerminationReasonCode,
0.00 as BillFrequencyPremiumAmount,
0.00 as AnnualizedPremiumAmount,
MemberInsuranceAgreementCoverage.PremiumPaidToDate as PremiumPaidToDate,
'-' as TaxStatusCode,
MemberInsuranceAgreementCoverage.SubAccountNumber as SubAccountNumber,
'-' as MemberCoveragePortedIndicator,
0 as PremiumPaidInAdvanceMonthCount,
'-' as WaiverOfPremiumCoverageIndicator,
0.00 as PayrollDeductionAmount,
0.00 as PremiumPaidToDateAmount,
'1900-01-01 00:00:00.000000' as MemberInsuranceAgreementCoverageStatusChangeDateTime,
'-' as OutOfForceIndicator,
0.00 as InitialAnnualPremiumAmount,
0.00 as ApprovedCoverageBenefitAmount,
CURRENT_TIMESTAMP as LastUpdateDateTime,
MemberInsuranceAgreementCoverage.CurrentRecordInd as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
MemberInsuranceAgreementCoverage.LogicalDel_ind as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetime,
'0' as hashcode
FROM
(
  select 
  trim(coalesce(concat_ws('-',TRIM(EMP.EEGRP),TRIM(EMP.EECERT),SUBSTR(EMP.EESSN,-4)),'-')) as MemberInsuranceAgreementNumber,
  COALESCE(CONCAT_WS('-', TRIM(PDGRP), TRIM(PDPRID)), '-') as ProductCode,
  trim(PDCACD) as InternalCompanyCode,
  MIN(coalesce(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(PHEDCY AS INT) AS STRING),CAST(CAST(PHEDYR AS INT) AS STRING)),CAST(CAST(PHEDMT AS INT) AS STRING),CAST(CAST(PHEDDY AS INT) AS STRING)) AS DATE), cast('1900-01-01' as date))) AS MemberInsuranceAgreementCoverageEffectiveDate,
  max(coalesce(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(PHTDCY AS INT) AS STRING),CAST(CAST(PHTDYR AS INT) AS STRING)),CAST(CAST(PHTDMT AS INT) AS STRING),CAST(CAST(PHTDDY AS INT) AS STRING)) AS DATE), cast('9999-12-31' as date))) AS MemberInsuranceAgreementCoverageEndDate,
  max(coalesce(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(BUPTCY AS INT) AS STRING),CAST(CAST(BUPTYR AS INT) AS STRING)),CAST(CAST(BUPTMT AS INT) AS STRING),CAST(CAST(BUPTDY AS INT) AS STRING)) AS DATE), cast('1900-01-01' as date))) AS PremiumPaidToDate,
  max(coalesce(PHACCT,0)) as SubAccountNumber,
  trim(coalesce(TRIM(PDGRP),'-')) as GroupInsuranceAgreementNumber,
  'Individual Certificate' InsuranceAgreementTypeCode,
  'Group Certificate' GroupInsuranceAgreementTypeCode,
  'N' as LogicalDel_ind,
  'Y' as CurrentRecordInd
  from ${WORK_DATABASE}.dim_work_PDTHIST PH
  inner join ${WORK_DATABASE}.dim_work_EMPMSTR EMP
  on EMP.EEGRP = PH.PHGRP
  and EMP.EESSN = PH.PHSSN and PH.scd_flag=true and EMP.scd_flag=true and PH.LogicalDel_ind='N' and EMP.LogicalDel_ind='N'
  inner join ${WORK_DATABASE}.dim_work_PDTDEFN PDT
  on PH.PHGRP = PDT.PDGRP
  and PH.PHPRID = PDT.PDPRID
  and PH.PHCEDT = PDT.PDCEDT and PDT.scd_flag=true and PDT.LogicalDel_ind='N'
  left JOIN ${WORK_DATABASE}.dim_work_BUMSTR BU
  ON PH.PHGRP  = BU.BUGRP
  AND PH.PHACCT = BU.BUACCT and BU.scd_flag=true and BU.LogicalDel_ind='N'
  where PH.PHACCT >= 100
  GROUP BY 
  EMP.EEGRP,EMP.EECERT,PDPRID,PDCACD,PDGRP,PDPRID,PDCEDT,SUBSTR(EMP.EESSN,-4), PDT.LogicalDel_ind
) MemberInsuranceAgreementCoverage;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.MemberInsuranceAgreementCoverage WHERE 1=0 LIMIT 1;




