set hive.support.quoted.identifiers=none;
set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx12288m -XX:NewRatio=8;
set tez.am.resource.memory.mb=6144;

INSERT OVERWRITE TABLE ${WORK_DATABASE}.MemberInsuranceAgreementCoveredParty
SELECT
MemberInsuranceAgreementCoveredParty.MemberInsuranceAgreementNumber as MemberInsuranceAgreementNumber,
MemberInsuranceAgreementCoveredParty.InternalCompanyCode as InternalCompanyCode,
MemberInsuranceAgreementCoveredParty.InsuranceAgreementTypeCode as InsuranceAgreementTypeCode,
MemberInsuranceAgreementCoveredParty.ProductCode as ProductCode,
MemberInsuranceAgreementCoveredParty.SourceGNLGroupNumber as SourceGNLGroupNumber,
MemberInsuranceAgreementCoveredParty.SourceGNLDependentSequenceNumber as SourceGNLDependentSequenceNumber,
MemberInsuranceAgreementCoveredParty.SourceGNLParticipantID as SourceGNLParticipantID,
'1900-01-01' as MemberInsuranceAgreementCoveredPartyEffectiveDate,
coalesce(MemberInsuranceAgreementCoveredParty.MemberInsuranceAgreementCoverageEndDate,CAST('9999-12-31' AS DATE)) as MemberInsuranceAgreementCoverageEndDate,
'9999-12-31' as MemberInsuranceAgreementCoveredPartyEndDate,
coalesce(MemberInsuranceAgreementCoveredParty.MemberInsuranceAgreementCoverageEffectiveDate,CAST('1900-01-01' AS DATE)) as MemberInsuranceAgreementCoverageEffectiveDate,
'-' as HasPreExistingConditionIndicator,
'-' as TobaccoHabitCode,
'-' as CoveredPartyStatusCode,
'9999-12-31' as CoveredPartyStatusDate,
COALESCE(TRIM(CoveredPartyTypeCode), '-') AS CoveredPartyTypeCode,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
'N' as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetime,
'0' as hashcode
FROM
(
  select 
  COALESCE(CONCAT_WS('-',TRIM(EMP.EEGRP),TRIM(EMP.EECERT), SUBSTR(TRIM(EESSN), -4)),'-') as MemberInsuranceAgreementNumber,
  COALESCE(CONCAT_WS('-',TRIM(PHGRP),TRIM(PHPRID)),'-') as ProductCode,
  trim(coalesce(GCCMPC,'-')) as InternalCompanyCode,
  --min(CAST(concat_ws('-',concat(PHEDCY,SUBSTR(CONCAT('0',cast(PHEDYR as string)),-2)),SUBSTR(CONCAT('0',cast(PHEDMT as string)),-2),SUBSTR(CONCAT('0',cast(PHEDDY as string)),-2)) AS date)) as MemberInsuranceAgreementCoverageEffectiveDate,
  MIN(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(PHEDCY AS INT) AS STRING),CAST(CAST(PHEDYR AS INT) AS STRING)),CAST(CAST(PHEDMT AS INT) AS STRING),CAST(CAST(PHEDDY AS INT) AS STRING)) AS DATE)) AS MemberInsuranceAgreementCoverageEffectiveDate,
  trim(coalesce(PHSSN,'0000000000')) as SourceGNLParticipantID,
  PHDSEQ as SourceGNLDependentSequenceNumber,
  trim(coalesce(EEGRP,'-')) as SourceGNLGroupNumber,
  MAX(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(PHTDCY AS INT) AS STRING),CAST(CAST(PHTDYR AS INT) AS STRING)),CAST(CAST(PHTDMT AS INT) AS STRING),CAST(CAST(PHTDDY AS INT) AS STRING)) AS DATE)) AS MemberInsuranceAgreementCoverageEndDate,
  MAX(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(BUPTCY AS INT) AS STRING),CAST(CAST(BUPTYR AS INT) AS STRING)),CAST(CAST(BUPTMT AS INT) AS STRING),CAST(CAST(BUPTDY AS INT) AS STRING)) AS DATE)) AS PremiumPaidToDate,
  max(PHACCT) as SubAccountNumber,
  TRIM(EMP.EEGRP) as GroupInsuranceAgreementNumber,
  DEP.DEDREL as CoveredPartyTypeCode,
  'Individual Certificate' as InsuranceAgreementTypeCode
  from 
  ${WORK_DATABASE}.dim_work_PDTHIST PH
  inner join ${WORK_DATABASE}.dim_work_EMPMSTR EMP
  on EMP.EEGRP = PH.PHGRP
  and EMP.EESSN = PH.PHSSN and PH.scd_flag=true and EMP.scd_flag=true and PH.LogicalDel_ind='N' and EMP.LogicalDel_ind='N'
  INNER JOIN ${WORK_DATABASE}.dim_work_GRPCTRL GRP
  ON PH.PHGRP = GRP.GCGRP and GRP.scd_flag=true and GRP.LogicalDel_ind='N'
  left JOIN ${WORK_DATABASE}.dim_work_BUMSTR BU
  ON PH.PHGRP = BU.BUGRP AND PH.PHACCT >= 100
  AND PH.PHACCT = BU.BUACCT and BU.scd_flag=true and BU.LogicalDel_ind='N'
  left join ${WORK_DATABASE}.dim_work_DEPMSTR DEP
  ON EMP.EEGRP = DEP.DEGRP
  and EMP.EESSN = DEP.DEDSSN
  AND DEP.DEDSEQ = PH.PHDSEQ
  AND DEP.scd_flag = true AND DEP.LogicalDel_ind='N'
  GROUP BY 
  EMP.EEGRP,EMP.EECERT,PHPRID,PHSSN,PHDSEQ,DEDREL,GRP.GCCMPC,PHGRP,SUBSTR(TRIM(EESSN), -4)
) MemberInsuranceAgreementCoveredParty;



-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.MemberInsuranceAgreementCoveredParty WHERE 1=0 LIMIT 1;



