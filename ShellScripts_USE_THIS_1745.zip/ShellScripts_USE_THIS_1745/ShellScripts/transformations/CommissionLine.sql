set hive.support.quoted.identifiers=none;
-- 4x YARN min container size
set hive.tez.container.size=24576;
-- 1/3 of TEZ container
set hive.auto.convert.join.noconditionaltask.size=8192;
-- 40% of TEZ container
set tez.runtime.io.sort.mb=9830;
-- 10% of TEZ container
set tez.runtime.unordered.output.buffer.size-mb=2457;
-- 75% of the container size
set hive.tez.java.opts=-Xmx18432m -XX:NewRatio=8;
-- equal to container size
set tez.am.resource.memory.mb=6144;

INSERT OVERWRITE TABLE ${WORK_DATABASE}.CommissionLine
SELECT
CommissionLine.NPN,
CommissionLine.DepositNumber,
CommissionLine.StatementDate,
CommissionLine.ProducerWritingNumber,
CommissionLine.InternalCompanyCode,
CommissionLine.InsuranceAgreementNumber,
CommissionLine.MemberInsuranceAgreementCoverageEffectiveDate,
CommissionLine.ProducerRoleTypeCode,
'-' as CommissionLinesAdjustmentFlag,
cast('1900-01-01 00:00:00.000000' as timestamp) as CommissionLineReversalDate,
CommissionLine.CommissionBaseRate,
CommissionLine.CommissionPaidAmount,
CommissionLine.CommissionPaymentReasonTypeCode,
CommissionLine.CommissionPaymentDistributionTypeCode,
CommissionLine.CommissionablePremiumAmount,
CommissionLine.EarnedCommissionAmount,
0.00 as AdvanceCommissionPaidAmount,
0.00 as FederalTaxWithheldAmount,
0.00 as StateTaxWithheldAmount,
CommissionLine.CommissionPaidInAdvanceMonthCount,
CommissionLine.CommissionType,
'-' as FirstYearCommissionIndicator,
cast('1900-01-01 00:00:00.000000' as timestamp) as CommissionPaidFromPremiumDate,
cast('9999-12-31 23:59:59.000000' as timestamp) as CommissionPaidToPremiumDate,
'-' as CommissionTransactionTypeCode,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'VUE' as SourceSystemCode,
'N' as LogicalDeleteIndicator,
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetimestamp,
'0' as hashcode
FROM
(
  SELECT
  CASE
    WHEN TRIM(b.NPN) = '' OR b.NPN IS NULL THEN '-'
    ELSE TRIM(b.NPN)
  END AS NPN,
  CASE
    WHEN TRIM(CAST(a.depositNumber AS STRING))='' OR TRIM(CAST(a.depositNumber AS STRING)) IS NULL THEN '-'
  ELSE TRIM(CAST(a.depositNumber AS STRING))
  END AS DepositNumber,
  COALESCE
  (
    CASE
      WHEN TRIM(a.statementdate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.statementdate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(a.statementdate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.statementdate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(a.statementdate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.statementdate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(a.statementdate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.statementdate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(a.statementdate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(a.statementdate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(a.statementdate) AS DATE)
    END,
	CAST('1900-01-01' AS DATE)
  ) AS StatementDate,
  CASE
    WHEN TRIM(a.writingnumber)='' OR TRIM(a.writingnumber) IS NULL THEN '-'
	ELSE TRIM(a.writingnumber)
  END AS ProducerWritingNumber,
  CASE
    WHEN TRIM(a.carriercode)='' OR TRIM(a.carriercode) IS NULL THEN '-'
    ELSE TRIM(a.carriercode)
  END AS InternalCompanyCode,
  CASE
    WHEN TRIM(c.certnumber)='' OR TRIM(c.certnumber) IS NULL THEN '-'
    ELSE TRIM(c.certnumber)
  END AS InsuranceAgreementNumber,
  COALESCE
  (
    CASE
    WHEN TRIM(c.effectivedate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.effectivedate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(c.effectivedate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.effectivedate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(c.effectivedate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.effectivedate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(c.effectivedate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.effectivedate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(c.effectivedate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(c.effectivedate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(c.effectivedate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS MemberInsuranceAgreementCoverageEffectiveDate,
  CASE
    WHEN TRIM(d.role)=''
    THEN '-'
    WHEN TRIM(d.role) IS NULL
    THEN '-'
    ELSE TRIM(d.role)
  END AS ProducerRoleTypeCode,
  COALESCE(a.commissionrate, 0) as CommissionBaseRate,
  COALESCE(a.revenue, 0) as CommissionPaidAmount,
  COALESCE(TRIM(b.paymentmethod), '-') as CommissionPaymentReasonTypeCode,
  COALESCE(TRIM(b.distributioncode), '-') as CommissionPaymentDistributionTypeCode,
  COALESCE(a.commissionablepremium, 0) as CommissionablePremiumAmount,
  COALESCE(a.earnedCommission, 0) as EarnedCommissionAmount,
  COALESCE(a.advancemonths, 0) as CommissionPaidInAdvanceMonthCount,
  COALESCE(TRIM(a.commissiontype), '-') as CommissionType
  FROM ${WORK_DATABASE}.dim_work_commissions a
  inner join ${WORK_DATABASE}.dim_work_agentdemographics b
  on TRIM(a.agentcode)=TRIM(b.agentcode)
  inner join ${WORK_DATABASE}.dim_work_agentarrangements d
  ON TRIM(a.agentcode) = CONCAT('AA',TRIM(d.agentcode))
  inner join ${WORK_DATABASE}.dim_work_subscribercoverage c
  on TRIM(d.arrangementcode)=TRIM(c.arrangmentcode)
) CommissionLine
WHERE NPN <> '-' AND StatementDate <> CAST('1900-01-01' AS DATE)  AND DepositNumber <> '-';



-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.CommissionLine WHERE 1=0 LIMIT 1;


