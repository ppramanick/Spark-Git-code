INSERT OVERWRITE TABLE ${WORK_DATABASE}.PartyAddress
SELECT
--PartyID
CASE WHEN LENGTH(TRIM(SourceGNLGroupNumber)) < 1 THEN '-' ELSE COALESCE(TRIM(SourceGNLGroupNumber), '-') END AS SourceGNLGroupNumber, --Natural Key, used to populate FK PartyID
CASE WHEN LENGTH(TRIM(SourceGNLParticipantID)) < 1 THEN '-' ELSE COALESCE(TRIM(SourceGNLParticipantID), '-') END AS SourceGNLParticipantID, --Natural Key, used to populate FK PartyID
COALESCE(SourceGNLAccountNumber, 0) AS SourceGNLAccountNumber, --Natural Key, used to populate FK PartyID
CASE WHEN LENGTH(TRIM(PartyAddressCategoryCode)) < 1 THEN '-' ELSE COALESCE(TRIM(PartyAddressCategoryCode), '-') END AS PartyAddressCategoryCode,
CASE WHEN LENGTH(TRIM(AddressLine1)) < 1 THEN '-' ELSE COALESCE(TRIM(AddressLine1), '-') END AS AddressLine1,
CASE WHEN LENGTH(TRIM(AddressLine2)) < 1 THEN '-' ELSE COALESCE(TRIM(AddressLine2), '-') END AS AddressLine2,
CASE WHEN LENGTH(TRIM(AddressLine3)) < 1 THEN '-' ELSE COALESCE(TRIM(AddressLine3), '-') END AS AddressLine3,
CASE WHEN LENGTH(TRIM(AddressCityName)) < 1 THEN '-' ELSE COALESCE(TRIM(AddressCityName), '-') END AS AddressCityName,
CASE WHEN LENGTH(TRIM(AddressPostalCode)) < 1 THEN '-' ELSE COALESCE(TRIM(AddressPostalCode), '-') END AS AddressPostalCode,
CASE WHEN LENGTH(TRIM(StateCode)) < 1 THEN 'Unknown-Genelco' ELSE COALESCE(TRIM(StateCode), 'Unknown-Genelco') END AS StateCode,
'-' AS PreferredAddressCategoryIndicator,
'-' AS CountryCode,
'-' AS AddressValidationIndicator,
TRIM(CurrentRecordInd) AS CurrentRecordIndicator,
'Genelco' AS SourceSystemCode,
LogicalDel_ind AS LogicalDeleteIndicator,
'-' AS County,
current_user() AS LastUpdateUserID,
current_timestamp AS LastUpdateDateTime,
current_timestamp AS hivelastupdatetimestamp,
"0" as hashcode
FROM
( --Transform Query
  --Group query
  Select
  SourceGNLGroupNumber, ---NK
  SourceGNLParticipantID, -----NK
  SourceGNLAccountNumber, ----NK
  AddressLine1,
  AddressLine2,
  AddressLine3,
  AddressCityName,
  StateCode,
  AddressPostalCode,
  PartyAddressCategoryCode,---NK
  LogicalDel_ind,
  CurrentRecordInd,
  MaxDate,
  MaxSeq
  FROM
  (
    select
    GCGRP AS SourceGNLGroupNumber,
    AR.A1SSN AS SourceGNLParticipantID,
    A1ACCT AS SourceGNLAccountNumber,
    AM.A8ADD1 AS AddressLine1, -------GroupBillingData
    AM.A8ADD2 AS AddressLine2,
    AM.A8ADD3 AS AddressLine3,
    AM.A8CTY AS AddressCityName,
    AM.A8STCD AS StateCode,
    AM.A8ZIP AS AddressPostalCode,
    AR.A1RRTY AS PartyAddressCategoryCode,
    AM.LogicalDel_ind AS LogicalDel_ind, 
    case when AM.LogicalDel_ind = 'N' then 'Y' end AS CurrentRecordInd,
    --max(CAST(CONCAT_WS(CONCAT(CAST(A1EDCY AS STRING),CAST(A1EDYR AS STRING)),CAST(A1EDMT AS STRING),CAST(A1EDDY AS STRING), '/') AS DATE)) AS MaxDate,
	  MAX(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(A1EDCY AS INT) AS STRING),CAST(CAST(A1EDYR AS INT) AS STRING)),CAST(CAST(A1EDMT AS INT) AS STRING),CAST(CAST(A1EDDY AS INT) AS STRING)) AS DATE)) AS MaxDate,
    max(A1SEQ3) AS MaxSeq,
    RANK() OVER (PARTITION BY GRP.GCGRP, AR.A1SSN, AR.A1ACCT ORDER BY AM.A8ADTM) AS TimeRank
    FROM
    ${WORK_DATABASE}.dim_work_grpctrl GRP
    inner join ${WORK_DATABASE}.dim_work_addrrel AR
    on GRP.GCGRP = AR.A1GRP AND GRP.scd_flag = true AND AR.scd_flag = true
    and A1ACCT = 0 -----groupaccount level addresses - party for groups
    AND GRP.scd_flag = true AND AR.scd_flag = true
    AND GRP.LogicalDel_ind = 'N' AND AR.LogicalDel_ind = 'N'
    inner join ${WORK_DATABASE}.dim_work_addrmstr AM
    on AR.A1ADJD = AM.A8ADJD
    and AR.A1AEYR = AM.A8AEYR
    and AR.A1ADTM = AM.A8ADTM
    AND AM.scd_flag = true
    AND A8ADD1 not like '%@%'
    and A1EDCY <>0
    and A1EDYR <>0
    and A1EDMT <> 0
    and  A1EDDY <> 0
    AND AM.scd_flag = true
    AND AM.LogicalDel_ind = 'N'
    group by GCGRP,A1SSN ,A8ADD1, A8ADD2, A8ADD3,A8CTY, A8STCD, A8ZIP, A1RRTY, A1ACCT,AM.LogicalDel_ind, AM.A8ADTM
    union All
    select
    AMGRP AS SourceGNLGroupNumber,
    AR.A1SSN AS SourceGNLParticipantID,
    A1ACCT AS SourceGNLAccountNumber,
    AM.A8ADD1 AS AddressLine1, -------GroupContactData
    AM.A8ADD2 AS AddressLine2,
    AM.A8ADD3 AS AddressLine3,
    AM.A8CTY AS AddressCityName,
    AM.A8STCD AS StateCode,
    AM.A8ZIP AS AddressPostalCode,
    AR.A1RRTY AS PartyAddressCategoryCode,
    AM.LogicalDel_ind AS LogicalDel_ind,
    case when AM.LogicalDel_ind = 'N' then 'Y' end AS CurrentRecordInd,
    --max(CAST(CONCAT_WS(CONCAT(CAST(A1EDCY AS STRING),CAST(A1EDYR AS STRING)),CAST(A1EDMT AS STRING),CAST(A1EDDY AS STRING), '/') AS date)) MaxDate,
	MAX(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(A1EDCY AS INT) AS STRING),CAST(CAST(A1EDYR AS INT) AS STRING)),CAST(CAST(A1EDMT AS INT) AS STRING),CAST(CAST(A1EDDY AS INT) AS STRING)) AS DATE)) MaxDate,
    max(A1SEQ3) AS MaxSeq,
    RANK() OVER (PARTITION BY ACT.AMGRP, AR.A1SSN, AR.A1ACCT ORDER BY AM.A8ADTM desc) AS TimeRank
    from
    ${WORK_DATABASE}.dim_work_actmstr ACT
    inner join ${WORK_DATABASE}.dim_work_addrrel AR
    on ACT.AMGRP = AR.A1GRP
    and ACT.AMACCT = AR.A1ACCT  ------subaccount level addresses
    AND ACT.scd_flag = true AND AR.scd_flag = true
    AND AR.LogicalDel_ind = 'N' AND ACT.LogicalDel_ind = 'N'
    inner join ${WORK_DATABASE}.dim_work_addrmstr AM
    on AR.A1ADJD = AM.A8ADJD
    and AR.A1AEYR = AM.A8AEYR
    and AR.A1ADTM = AM.A8ADTM
    AND AM.scd_flag = true
    AND A8ADD1 not like '%@%'
    and A1EDCY <>0
    and A1EDYR <>0
    and A1EDMT <> 0
    and A1EDDY <> 0
    and AMACCT>=100
    AND AM.LogicalDel_ind = 'N' 
    group by AMGRP,A1SSN ,A8ADD1, A8ADD2, A8ADD3,A8CTY, A8STCD, A8ZIP, A1RRTY, A1ACCT, AM.LogicalDel_ind,AM.A8ADTM
  ) a
  where TimeRank=1

  UNION ALL
  ----------------------INDIVIDUAL---------------- 
  Select 
  GCGRP SourceGNLGroupNumber, 
  EESSN SourceGNLParticipantID, -----participantid
  0 AS SourceGNLAccountNumber,
  EEADD1 AS AddressLine1, ----IndividualData 
  EEADD2 AS AddressLine2, 
  EEADD3 AS AddressLine3, 
  EECTY AS AddressCityName, 
  EESTCD AS StateCode, 
  EEZIP AS AddressPostalCode, 
  'Home' AS PartyAddressCategoryCode, 
  EMP.LogicalDel_ind AS LogicalDel_ind , 
  case when EMP.LogicalDel_ind = 'N' then 'Y' end AS CurrentRecordInd,
  CAST('1900-01-01' AS DATE) AS MaxDate,
  0 AS MaxSeq 
  from 
  ${WORK_DATABASE}.dim_work_grpctrl GRP 
  inner join ${WORK_DATABASE}.dim_work_empmstr EMP 
  on GRP.GCGRP = EMP.EEGRP
  AND GRP.scd_flag = true AND EMP.scd_flag = true
  AND GRP.LogicalDel_ind = 'N' AND EMP.LogicalDel_ind = 'N'
) PartyAddress;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PartyAddress WHERE 1=0 LIMIT 1;




