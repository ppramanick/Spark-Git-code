INSERT OVERWRITE TABLE ${WORK_DATABASE}.SubAccountBusinessAccount
SELECT
SubAccountBusinessAccount.InsuranceAgreementNumber as GroupInsuranceAgreementNumber,
SubAccountBusinessAccount.BussinessAccountNumber as BussinessAccountNumber,
SubAccountBusinessAccount.SubAccountNumber as SubAccountNumber,
SubAccountBusinessAccount.InternalCompanyCode as InternalCompanyCode,
SubAccountBusinessAccount.BusinessAccountType as BusinessAccountType,
CURRENT_TIMESTAMP as LastUpdateDateTime,
SubAccountBusinessAccount.CurrentRecordInd as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
SubAccountBusinessAccount.LogicalDelIndicator as LogicalDeleteIndicator,
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetime,
"0" as hashcode
FROM
(
  select
  TRIM(GCGRP) AS InsuranceAgreementNumber,---NK
  COALESCE(concat(TRIM(BUGRP),'-',CAST(BUACCT AS INT),'-',TRIM(BUSSN)), '--') AS BussinessAccountNumber, ---NK
  AMACCT AS SubAccountNumber,
  COALESCE(TRIM(GRP.GCCMPC), '-') AS InternalCompanyCode,---NK
  'Invoice Account' AS BusinessAccountType,
  ACT.LogicalDel_ind AS LogicalDelIndicator,
  'Y' AS CurrentRecordInd
  FROM ${WORK_DATABASE}.dim_work_GRPCTRL GRP
  Inner Join ${WORK_DATABASE}.dim_work_ACTMSTR ACT
  on GRP.GCGRP = ACT.AMGRP AND GRP.scd_flag = true AND ACT.scd_flag = true
  AND GRP.LogicalDel_ind = 'N' AND ACT.LogicalDel_ind = 'N'
  left JOIN ${WORK_DATABASE}.dim_work_BUMSTR BU
  ON ACT.AMGRP = BU.BUGRP
  AND ACT.AMACCT = BU.BUACCT AND BU.scd_flag = true AND BU.LogicalDel_ind = 'N'
  where AMACCT >= 100
) SubAccountBusinessAccount;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.SubAccountBusinessAccount WHERE 1=0 LIMIT 1;