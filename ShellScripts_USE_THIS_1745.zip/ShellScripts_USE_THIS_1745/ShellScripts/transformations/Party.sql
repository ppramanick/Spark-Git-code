set hive.support.quoted.identifiers=none;
-- 4x YARN min container size
set hive.tez.container.size=24576;
-- 1/3 of TEZ container
set hive.auto.convert.join.noconditionaltask.size=8192;
-- 40% of TEZ container
set tez.runtime.io.sort.mb=9830;
-- 10% of TEZ container
set tez.runtime.unordered.output.buffer.size-mb=2457;
-- 75% of the container size
set hive.tez.java.opts=-Xmx18432m -XX:NewRatio=8;
-- equal to container size
set tez.am.resource.memory.mb=6144;

INSERT OVERWRITE TABLE ${WORK_DATABASE}.Party
SELECT
--PartyID BIGINT NOT NULL, -- Will not be Not Part of datalake
CASE WHEN LENGTH(TRIM(PartyName)) < 1 THEN '-' ELSE COALESCE(TRIM(PartyName), '-') END AS PartyName,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS PartyCreateDate,
COALESCE(TRIM(PartyType), '-') AS PartyType, -- PartyType is Hardcoded to Individual / Organization RDM Lookup required, NOT NULL,
COALESCE(TRIM(PartyRole), '-') AS PartyRole, -- Hardcoded to Insured or Dependent should go through the RDM Lookup, NOT NULL,
'-' AS PreferredLanguageCode, --Not Coming from source, Default to - , NOT NULL,
'-' AS PreferredContactTypeCode, --Not Coming from source, Default to - , NOT NULL,
'-' AS GeographicAreaCode, -- Not Coming from source, Default to - , NOT NULL,
CASE WHEN LENGTH(TRIM(FirstName)) < 1 THEN '-' ELSE COALESCE(TRIM(FirstName), '-') END AS FirstName, --Mapping found Coming from source, NOT NULL,
CASE WHEN LENGTH(TRIM(LastName)) < 1 THEN '-' ELSE COALESCE(TRIM(LastName), '-') END AS LastName, --Mapping found Coming from source, NOT NULL,
CASE WHEN LENGTH(TRIM(MiddleName)) < 1 THEN '-' ELSE COALESCE(TRIM(MiddleName), '-') END AS MiddleName, --Mapping found Coming from source, NOT NULL,
'-' AS NameSuffix, --Not Coming from source, Default to - , NOT NULL,
COALESCE(TRIM(GenderCode), '-') AS GenderCode, --Mapping found Coming from source, NOT NULL,
COALESCE(CAST(TRIM(BirthDate) AS DATE), CAST('1900-01-01' AS DATE)) AS BirthDate, --Mapping found Coming from source, FORMAT 'yyyy/mm/dd' NOT NULL,
'-' AS EthnicityCode, --Not Coming from source, Default to - , NOT NULL,
'-' AS NAICSCode, --Not Coming from source, Default to - , NOT NULL,
'-' AS SICCode, --Not Coming from source, Default to - , NOT NULL,
CAST(0 AS INT) AS TotalEmployeeCount, --Not Coming from source, Default to 0 ,NOT NULL DEFAULT 0 ,
'-' AS SitusStateCode, --Not Coming from source, Default to - , NOT NULL,
'-' AS MaritalStatusCode, --Not Coming from source, Default to - , NOT NULL,
COALESCE(TRIM(SourceGNLGroupNumber), '-') AS SourceGNLGroupNumber, --Mapping found Coming from source, NOT NULL,
'-' AS SourceCIFNumber, --Not Coming from source, Default to - , NOT NULL,
COALESCE(TRIM(SourceGNLParticipantID), '0000000000') AS SourceGNLParticipantID, --Mapping found Coming from source, NOT NULL,
'-' AS SourceACFWritingNumber, --Not Coming from source, Default to - , NOT NULL,
CAST(0 AS INT) AS SourceMDMPartyObjectID, --Not Coming from source, Default to 0, NOT NULL,
CAST(0 AS BIGINT) AS SourceWYNID, --Not Coming from source, Default to 0, NOT NULL,
CAST(0 AS BIGINT) AS SourceWYNNameSpaceID, -- Not Coming from source, Default to 0 ,NOT NULL,
'-' AS SourceWYNClientID, -- Not Coming from source, Default to - , NOT NULL,
COALESCE(TRIM(InternalCompanyCode), '-') AS InternalCompanyCode, -- Mapping found Coming from source, NOT NULL,
'-' AS SourceGMGroupNumber, -- Not Coming from source, Default to - , NOT NULL,
COALESCE(SourceGNLAccountNumber, 0), --Mapping found Coming from source, NOT NULL,
'-' AS SmokerIndicator, -- Not Coming from source, Default to - , NOT NULL,
CurrentRecordIndicator, --Mapping found Coming from source, NOT NULL,
'Genelco' AS SourceSystemCode, --Not coming from source, Default GNL For Genelco, WYN for Wynsure, NOT NULL,
LogicalDeleteIndicator, -- Mapping found Coming from source, NOT NULL,
CAST(0 AS BIGINT) AS MasterPartyID, -- Mapping found Coming from source, NOT NULL,
'-' AS SourceGNLWritingNumber, --Not Coming from source, Default to - , NOT NULL,
'-' AS PartyTitle, -- Not Coming from source, Default to - , NOT NULL DEFAULT ' ',
CAST('1900-01-01' AS DATE) AS DeathDate, -- FORMAT 'YYYY/MM/DD' NOT NULL Not Coming from source, Default to '1900/01/01',
'-' AS ChildSupportLienOnFileIndicator, -- Not Coming from source, NOT NULL DEFAULT '-',
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS ChildSupportLienOnFileTimestamp, --Not Coming from source, NOT NULL DEFAULT TIMESTAMP '1900-01-01 00:00:00.000000',
'-' AS OnChildSupportLienNetworkIndicator, -- Not Coming from source, Default to - ,NOT NULL DEFAULT '-',
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS OnChildSupportLienNetworkTimestamp, --Not Coming from source, NOT NULL DEFAULT TIMESTAMP '1900-01-01 00:00:00.000000',
'-' AS IRSDefaultIndicator, -- Not Coming from source, Default to - ,NOT NULL DEFAULT '-',
CAST(COALESCE(SourceGNLDependentSequenceNumber, 0) AS INT) AS SourceGNLDependentSequenceNumber, --Mapping found Coming from source, NOT NULL DEFAULT 0
current_user() AS LastUpdateUserID, --Datalake Batch UserID / VID, NOT NULL,
current_timestamp AS LastUpdateDateTime, --Datalake time stamp or LastUpdated_ts from source, NOT NULL,
current_timestamp AS hivelastupdatetimestamp,
"0" as hashcode
FROM
( -- STTM Transformation Query
  Select 
  SourceGNLGroupNumber,
  SourceGNLAccountNumber, 
  SourceGNLParticipantID, 
  SourceGNLDependantSeq AS SourceGNLDependentSequenceNumber,
  PartyName, 
  FirstName, 
  MiddleName, 
  LastName, 
  BirthDate,
  Gendercode,
  InternalCompanyCode,
  LogicalDel_ind AS LogicalDeleteIndicator,
  CurrentRecordInd AS CurrentRecordIndicator,
  PartyRole, 
  PartyType 
  FROM 
  (
    Select GCGRP AS SourceGNLGroupNumber,
    0 AS SourceGNLAccountNumber,
    EESSN AS SourceGNLParticipantID, 
    0 AS SourceGNLDependantSeq,
    TRIM(CONCAT_WS(' ', TRIM(EENAMF), TRIM(EENAMM), TRIM(EENAML))) AS PartyName,
    --RTRIM(EENAMF)+RTRIM(' '+EENAMM)+RTRIM(' '+EENAML) PartyName, ---EMPLOYEE ELIGIBILITY MASTER 
    EENAMF AS FirstName,
    EENAMM AS MiddleName, 
    EENAML AS LastName, 
    --CONCAT_WS('-', CONCAT(CAST(CAST(EEBDCY AS INT) AS STRING), CAST(CAST(EEBDYR AS INT) AS STRING)), CAST(CAST(EEBDMT AS INT) AS STRING), CAST(CAST(EEBDDY AS INT) AS STRING)) AS BirthDate,
    CONCAT_WS('-',CONCAT(CAST(CAST(EEBDCY AS INT) AS STRING),lpad(CAST(CAST(EEBDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(EEBDMT AS INT) AS STRING),2,"0"), lpad(CAST(CAST(EEBDDY AS INT) AS STRING),2,"0")) AS BirthDate,
    --concat(EEBDCY,RIGHT(CONCAT('0',EEBDYR),2),'/',EEBDMT,'/',EEBDDY) BirthDate,
    EMP.EESEXC as Gendercode,
    GRP.GCCMPC as InternalCompanyCode,
    EMP.LogicalDel_ind LogicalDel_ind,
    case when EMP.LogicalDel_ind = 'N' then 'Y' else 'N' end AS CurrentRecordInd,
    'Insured' AS PartyRole,
    'Individual' AS PartyType
    FROM ${WORK_DATABASE}.dim_work_GRPCTRL GRP
    INNER JOIN ${WORK_DATABASE}.dim_work_EMPMSTR EMP
    ON GRP.GCGRP = EMP.EEGRP AND GRP.LogicalDel_ind = 'N'
    AND EMP.LogicalDel_ind = 'N' AND GRP.LogicalDel_ind = 'N'
    AND GRP.scd_flag = true AND EMP.scd_flag = true
    UNION ALL
    Select GCGRP AS SourceGNLGroupNumber,
    0 AS SourceGNLAccountNumber,
    DESSN AS SourceGNLParticipantID,
    DEP.DEDSEQ AS SourceGNLDependantSeq,
    TRIM(CONCAT_WS(' ', TRIM(DEDENF),TRIM(DEDENM),TRIM(DEDENL))) AS PartyName,
    --RTRIM(DEDENF)+RTRIM(' '+DEDENM)+RTRIM(' '+DEDENL) PartyName, ---DEPENDENT
    DEDENF AS FirstName,
    DEDENM AS MiddleName,
    DEDENL AS LastName,
    --CONCAT_WS('-', CONCAT(CAST(DEBDCY AS STRING), CAST(DEBDYR AS STRING)), CAST(DEBDMT AS STRING), CAST(DEBDDY AS STRING)) AS BirthDate,
	 --CONCAT_WS('-',CONCAT(CAST(CAST(DEBDCY AS INT) AS STRING),CAST(CAST(DEBDYR AS INT) AS STRING)),CAST(CAST(DEBDMT AS INT) AS STRING),CAST(CAST(DEBDDY AS INT) AS STRING)) AS BirthDate,
	 CONCAT_WS('-',CONCAT(CAST(CAST(DEBDCY AS INT) AS STRING),lpad(CAST(CAST(DEBDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(DEBDMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(DEBDDY AS INT) AS STRING),2,"0")) AS BirthDate,
    --concat(DEBDCY,RIGHT(CONCAT('0',DEBDYR),2),'/',DEBDMT,'/',DEBDDY) BirthDate,
    DEP.DESEXC as Gendercode,
    GRP.GCCMPC as InternalCompanyCode,
    DEP.LogicalDel_ind LogicalDel_ind,
    case when DEP.LogicalDel_ind = 'N' then 'Y' else 'N' end AS CurrentRecordInd, 
    'Dependent' as PartyRole, 
    'Individual' as PartyType 
    FROM ${WORK_DATABASE}.dim_work_GRPCTRL GRP 
    INNER JOIN ${WORK_DATABASE}.dim_work_DEPMSTR DEP
    ON GRP.GCGRP = DEP.DEGRP
    AND GRP.scd_flag = true AND DEP.scd_flag = true
    AND GRP.LogicalDel_ind = 'N' AND DEP.LogicalDel_ind = 'N'
  ) Party

  UNION ALL
  ------------------------Group-------------------------
  Select
  SourceGNLGroupNumber,
  SourceGNLAccountNumber,
  '0000000000' AS SourceGNLParticipantID,
  0 AS SourceGNLDependantSeq,
  GroupName AS PartyName,
  '-' AS FirstName,
  '-' AS MiddleName, 
  '-' AS LastName, 
  CAST('9999-12-31' AS DATE) AS BirthDate,
  '-' AS Gendercode,
  InternalCompanyCode,
  LogicalDel_ind,
  CurrentRecordInd,
  '-' AS PartyRole,
  PartyType
  from
  (
    Select GCGRP AS SourceGNLGroupNumber,---natural keys
    0 as SourceGNLAccountNumber,
    GCGRPN AS GroupName,
    GRP.GCCMPC as InternalCompanyCode,
    GRP.LogicalDel_ind AS LogicalDel_ind,
    case when GRP.LogicalDel_ind = 'N' then 'Y' else 'N' end AS CurrentRecordInd,
    'Organization' AS PartyType
    FROM ${WORK_DATABASE}.dim_work_GRPCTRL GRP
    WHERE GRP.scd_flag = true AND GRP.LogicalDel_ind = 'N'
    UNION ALL
    Select AMGRP AS SourceGNLGroupNumber,---natural keys---30663
    AMACCT AS SourceGNLAccountNumber,
    AMPLAC AS GroupName,
    GRP.GCCMPC AS InternalCompanyCode,
    ACT.LogicalDel_ind AS LogicalDel_ind, 
    case when ACT.LogicalDel_ind = 'N' then 'Y' else 'N' end AS CurrentRecordInd,
    'Organization' AS PartyType
    FROM ${WORK_DATABASE}.dim_work_ACTMSTR ACT
    left join ${WORK_DATABASE}.dim_work_GRPCTRL GRP
    on GRP.GCGRP = ACT.AMGRP AND ACT.LogicalDel_ind = 'N' AND GRP.LogicalDel_ind = 'N'
    AND AMACCT >= 100 AND GRP.scd_flag = true AND ACT.scd_flag = true
  ) Grp
  CLUSTER BY SourceGNLGroupNumber, SourceGNLAccountNumber, SourceGNLParticipantID, SourceGNLDependentSequenceNumber
) TransformQuery;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.Party WHERE 1=0 LIMIT 1;



