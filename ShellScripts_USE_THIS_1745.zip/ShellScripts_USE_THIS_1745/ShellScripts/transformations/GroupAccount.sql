INSERT OVERWRITE TABLE ${WORK_DATABASE}.GroupAccount 
SELECT
-- AccountID No Mapping, Not coming from source Seq Generated in BDM
CASE WHEN LENGTH(TRIM(AccountNumber)) < 1 THEN '-' ELSE COALESCE(TRIM(AccountNumber), '-') END AS SourceGNLGroupAccountNumber, --Mapping found, coming from source
CASE WHEN LENGTH(TRIM(InternalCompanyCode)) < 1 THEN '-' ELSE COALESCE(TRIM(InternalCompanyCode), '-') END AS InternalCompanyCode, --Mapping found, coming from source
'-' AS AccountStatusCode,
CAST('9999-12-31' AS DATE) AS AccountEstablishedDate,
'-' AS AccountTerminationReasonCode,
'-' AS AccountTypeCode,
CAST('9999-12-31' AS DATE) AS AccountTerminationDate,
ActN AS SourceGNLAccountNumber,
'Y' AS OperatesinAllStatesIndicator,
CurrentRecordInd AS CurrentRecordIndicator,
'Genelco' AS SourceSystemCode,
LogicalDelIndicator AS LogicalDeleteIndicator,
current_user() AS LastUpdateUserID,
current_timestamp AS LastUpdateDateTime,
current_timestamp,
"0" as hashcode
FROM
( --Transformation Query
  Select GCGRP AS AccountNumber,---natural keys
  0 as ActN, ---natural keys
  GRP.GCCMPC as InternalCompanyCode,
  GRP.LogicalDel_ind AS LogicalDelIndicator,
  'Y' AS CurrentRecordInd
  FROM ${WORK_DATABASE}.dim_work_grpctrl GRP
  WHERE GRP.scd_flag = true AND GRP.LogicalDel_ind = 'N'
) GroupAccount;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.GroupAccount WHERE 1=0 LIMIT 1;