INSERT OVERWRITE TABLE ${WORK_DATABASE}.BusinessAccount
SELECT
BusinessAccountOwningPartyIDGrp AS BusinessAccountOwningPartyIDGrp, -- Natural Key OWNING PARTY
BusinessAccountOwningPartyIDAcct AS BusinessAccountOwningPartyIDAcct,-- Natural Key OWNING PARTY
BusinessAccountOwningPartyIDSSN AS BusinessAccountOwningPartyIDSSN,-- Natural Key OWNING PARTY
COALESCE(TRIM(InternalCompanycode), '-') AS InternalCompanyCode,
COALESCE(AccountNumber, '-') AS BusinessAccountNumber,
CAST('1900-01-01' AS DATE) AS BusinessAccountCreateDate,
BusinessAccountType AS BusinessAccountTypecode,
0.00 AS BusinessAccountBalanceAmount,
0.00 AS BusinessAccountSuspendedBalanceAmount,
TranformQuery.CurrentRecordInd AS CurrentRecordIndicator,
'Genelco' AS SourceSystemCode,
TranformQuery.LogicalDelIndicator AS LogicalDeleteIndicator,
current_user() AS LastUpdateUserID,
current_timestamp AS LastUpdateDateTime,
current_timestamp AS hivelastupdatetimestamp,
"0" as hashcode
FROM
( --Transform Query
select 
COALESCE(CONCAT_WS('-', TRIM(BUGRP),CAST(CAST(BUACCT AS INT) AS STRING), CASE WHEN CAST(BUACCT AS INT) < 1000 THEN '' ELSE TRIM(BUSSN) END), '-') AS AccountNumber,
COALESCE(TRIM(GCCMPC), '-') AS InternalCompanycode,
'Invoice Account' AS BusinessAccountType,
COALESCE(TRIM(BUGRP), '-') AS BusinessAccountOwningPartyIDGrp, ---OWNING PARTY
COALESCE(CAST(BUACCT AS INT), 0) AS BusinessAccountOwningPartyIDAcct,---OWNING PARTY
COALESCE(TRIM(BUSSN), '-') AS BusinessAccountOwningPartyIDSSN,---OWNING PARTY
BM.LogicalDel_ind AS LogicalDelIndicator,
'Y' AS CurrentRecordInd
from ${WORK_DATABASE}.dim_work_BUMSTR BM
inner join ${WORK_DATABASE}.dim_work_GRPCTRL GRP
ON BM.BUGRP = GRP.GCGRP AND BM.scd_flag = true AND GRP.scd_flag = true
AND BM.LogicalDel_ind = 'N' AND GRP.LogicalDel_ind = 'N'
union ALL
SELECT
COALESCE(CONCAT_WS('-', TRIM(EEGRP),TRIM(EESSN)), '-') AS AccountNumber,
COALESCE(TRIM(GCCMPC), '-') as InternalCompanycode,
'Claim Account' as BusinessAccountType,
COALESCE(TRIM(EEGRP), '-') as BusinessAccountOwningPartyIDGrp, ---OWNING PARTY
0 as BusinessAccountOwningPartyIDAcct,---OWNING PARTY
COALESCE(TRIM(EESSN), '-') as BusinessAccountOwningPartyIDSSN,---OWNING PARTY
EMP.LogicalDel_ind as LogicalDelIndicator,
'Y' AS CurrentRecordInd
from ${WORK_DATABASE}.dim_work_EMPMSTR EMP
INNER JOIN ${WORK_DATABASE}.dim_work_GRPCTRL GRP
ON EMP.EEGRP = GCGRP and EMP.scd_flag=true and GRP.scd_flag=true 
and EMP.LogicalDel_ind='N' and GRP.LogicalDel_ind='N'
) TranformQuery;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.BusinessAccount WHERE 1=0 LIMIT 1;


