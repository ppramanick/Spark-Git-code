INSERT OVERWRITE TABLE ${WORK_DATABASE}.AccountTransaction
SELECT
AccountTransaction.InternalCompanyCode as InternalCompanyCode,
AccountTransaction.TransactionNumber as TransactionNumber,
AccountTransaction.AccountTransactionTypeCode as AccountTransactionTypeCode,
COALESCE(CAST(AccountTransaction.TransactionPostingTimestamp AS TIMESTAMP), CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP)) as TransactionPostingTimestamp,
AccountTransaction.TransactionAmount as TransactionAmount,
'-' as AccountTransactionCreationUserID,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
'N' as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetime,
"0" as hashcode
FROM
(
SELECT
COALESCE(concat_ws('-',trim(EBGRP),cast(cast(EBACCT as int) as varchar(4)),cast(cast(EBSDCY * 1000000 + EBSDYR * 10000 + EBSDMT * 100 + EBSDDY as int) as varchar(8)),cast(cast(EBSTIM as int) as varchar(10)),cast(cast(EBTRLN as int) as varchar(10)),trim(EBUSER)),'-') AS TransactionNumber,
'Bill' AS AccountTransactionTypeCode,
trim(coalesce(EBCURC,'-')) AS InternalCompanyCode,
coalesce(EBTTPC + EBTTPD,0.00) AS TransactionAMount,
CAST(concat_ws('-',concat(cast(EBSDCY as int),SUBSTR(CONCAT('0',cast(cast(EBSDYR as int) as varchar(2))),-2)),SUBSTR(CONCAT('0',cast(cast(EBSDMT as int) as STRING)),-2),SUBSTR(CONCAT('0',TRIM(cast(cast(EBSDDY as int) as STRING))),-2)) AS date) AS TransactionPostingTimestamp
FROM ${WORK_DATABASE}.dim_work_BILLHIST
WHERE EBACCT >= 100 and scd_flag=true and LogicalDel_ind='N'
UNION ALL
select
trim(coalesce(B2BATI,'-')) AS TransactionNumber,
'Payment' AS AccountTransactionTypeCode,
trim(coalesce(B2CURC,'-')) AS InternalCompanyCode,
coalesce(B2BCHT,0.00) AS TransactionAMount,
CAST(concat_ws('-',concat(cast(B2APCY as int),SUBSTR(CONCAT('0',cast(cast(B2APYR as int) as varchar(2))),-2)),SUBSTR(CONCAT('0',cast(cast(B2APMT as int) as varchar(4))),-2),SUBSTR(CONCAT('0',cast(cast(B2APDY as int) as varchar(4))),-2)) AS date) AS TransactionPostingTimestamp
FROM ${WORK_DATABASE}.dim_work_BTCTL
WHERE B2ACCT >= 100 and scd_flag=true and LogicalDel_ind='N'
UNION ALL
SELECT
COALESCE(concat_ws('-',cast(cast(BLJYR as int) as varchar(10)),cast(cast(BLJDAY as int) as varchar(10)),cast(cast(BLSEQ as int) as varchar(10)),trim(BLSUFX),cast(cast(BLPPNO as int) as varchar(10)),cast(cast(BLADJN as int) as varchar(10)),cast(cast(BLBNLN as int) as varchar(10)))) AS TransactionNumber,
'Claim Regularization' as AccountTransactionTypeCode,
trim(coalesce(BLCURC,'-')) as InternalCompanyCode,
coalesce(BLBFA1+BLBFA2+BLBFA3,0.00) as TransactionAmount,
CAST(concat_ws('-',concat(cast(BLSFCY as int),SUBSTR(CONCAT('0',cast(cast(BLSFYR as int) as varchar(2))),-2)),SUBSTR(CONCAT('0',cast(cast(BLSFMT as int) as varchar(4))),-2),SUBSTR(CONCAT('0',cast(cast(BLSFDY as int) as varchar(4))),-2)) AS date) AS TransactionPostingTimestamp
FROM ${WORK_DATABASE}.dim_work_BLHIST
WHERE scd_flag=true and LogicalDel_ind='N'
UNION ALL
SELECT
COALESCE(concat_ws('-',cast(cast(PPJYR as int) as varchar(10)),cast(cast(PPJDAY as int) as varchar(10)),cast(cast(PPSEQ as int) as varchar(10)),trim(PPSUFX),cast(cast(PPPPNO as int) as varchar(10)),cast(cast(PPADJN as int) as varchar(10)))) AS TransactionNumber,
'Disbursement' as AccountTransactionTypeCode,
trim(coalesce(CSCURC,'-')) as InternalCompanyCode,
coalesce(sum(PPAMTP),0.00) as TransactionAmount,
CAST(concat_ws('-',concat(cast(PPCICY as int),SUBSTR(CONCAT('0',cast(cast(PPCIYR as int) as varchar(2))),-2)),SUBSTR(CONCAT('0',cast(cast(PPCIMT as int) as varchar(4))),-2),SUBSTR(CONCAT('0',cast(cast(PPCIDY as int) as varchar(4))),-2)) AS date) AS TransactionPostingTimestamp
FROM ${WORK_DATABASE}.dim_work_PPHIST PPH
INNER JOIN ${WORK_DATABASE}.dim_work_CSRMSTR CSR
ON PPH.PPJYR = CSR.CSJYR
AND PPH.PPJDAY = CSR.CSJDAY
AND PPH.PPSEQ = CSR.CSSEQ
AND PPH.PPSUFX = CSR.CSSUFX
AND PPH.scd_flag=true and PPH.LogicalDel_ind='N' AND CSR.scd_flag=true and CSR.LogicalDel_ind='N'
group by PPJYR,PPJDAY,PPSEQ,PPSUFX,PPPPNO,PPADJN,CSCURC,PPCICY,PPCIYR,PPCIMT,PPCIDY
) AccountTransaction;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.AccountTransaction WHERE 1=0 LIMIT 1;