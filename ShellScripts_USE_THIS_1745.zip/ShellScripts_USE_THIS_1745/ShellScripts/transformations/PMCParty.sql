INSERT OVERWRITE TABLE ${WORK_DATABASE}.PMCParty
SELECT
Party.NPN AS NPN, 
'-' AS PartyName  ,
CAST('1900-01-01' AS DATE) AS PartyCreateDate ,
'-' AS PartyTypeCode   ,
'-' AS PartyRoleTypeCode  ,
'-' AS PreferredLanguageCode  ,
Party.PreferredContactTypeCode AS  PreferredContactTypeCode,
'-' AS GeographicAreaCode ,
'-' AS FirstName ,
'-' AS LastName ,
'-' AS MiddleName ,
'-' AS NameSuffix ,
'-' AS GenderCode  ,
CAST('1900-01-01' AS DATE) AS BirthDate,
'-' AS EthnicityCode  ,
'-' AS NAICSCode  ,
'-' AS SICCode  ,
-1 AS TotalEmployeeCount ,
'-' AS SitusStateCode  ,
'-' AS MaritalStatusCode  ,
'-' AS SourceGNLGroupNumber ,
'-' AS SourceCIFNumber ,
'-' AS SourceGNLParticipantID,
'-' AS SourceACFWritingNumber,
-1 AS SourceMDMPartyObjectID,
-1 AS SourceWYNID,
-1 AS SourceWYNNameSpaceID,
'-' AS SourceWYNClientID,
'-' AS InternalCompanyCode,
'-' AS SourceGMGroupNumber,
0 AS SourceGNLAccountNumber,
'-' AS SmokerIndicator,
CURRENT_USER() AS LastUpdateUserID,
CURRENT_TIMESTAMP AS LastUpdateDateTime,
'Y' AS CurrentRecordIndicator,
'VUE' AS SourceSystemCode,
'N' AS LogicalDeleteIndicator,
-1 AS MasterPartyID, 
0 AS SourceGNLWritingNumber,
'-' AS PartyTitle,
Party.DeathDate AS DeathDate ,
'-' AS ChildSupportLienOnFileIndicator ,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS ChildSupportLienOnFileTimestamp ,
'-' AS OnChildSupportLienNetworkIndicator ,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS OnChildSupportLienNetworkTimestamp ,
'-' AS IRSDefaultIndicator ,
0 AS SourceGNLDependentSequenceNumber,
CURRENT_TIMESTAMP AS hivelastupdatetimestamp,
'0' AS hashcode
FROM
(
  SELECT
  CASE WHEN TRIM(DS.NPN) = ''  OR TRIM(DS.NPN) IS NULL
    THEN '-'
    ELSE TRIM(DS.NPN)
  END AS NPN,
  CASE WHEN TRIM(DS.PreferredContactMode) = '' OR TRIM(DS.PreferredContactMode) IS NULL
    THEN '-'
    ELSE TRIM(DS.PreferredContactMode)
  END AS PreferredContactTypeCode,
  COALESCE
  (
    CASE
    WHEN TRIM(DS.DATEOFDEATH) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DS.DATEOFDEATH), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(DS.DATEOFDEATH) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DS.DATEOFDEATH), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(DS.DATEOFDEATH) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DS.DATEOFDEATH), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(DS.DATEOFDEATH) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(DS.DATEOFDEATH), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(DS.DATEOFDEATH) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(DS.DATEOFDEATH),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(DS.DATEOFDEATH) AS DATE)
    END, 
    CAST('1900-01-01' AS DATE)
  ) AS DeathDate
  FROM ${WORK_DATABASE}.dim_work_agentdemographics DS
  WHERE DS.scd_flag = true
) Party
WHERE NPN <> '-';



-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PMCParty WHERE 1=0 LIMIT 1;


