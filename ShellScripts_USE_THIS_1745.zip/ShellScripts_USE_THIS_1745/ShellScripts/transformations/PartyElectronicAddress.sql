INSERT OVERWRITE TABLE ${WORK_DATABASE}.PartyElectronicAddress -- Use only for Load otherwise start with SELECT Statement
SELECT 
--PartyID No Mapping, Must go through RDM Process
CASE WHEN LENGTH(TRIM(SourceGNLGroupNumber)) < 1 THEN '-' ELSE COALESCE(TRIM(SourceGNLGroupNumber), '-') END AS SourceGNLGroupNumber, --Natural Key, Used to Populate PK/FK PartyID in BDM
CASE WHEN LENGTH(TRIM(SourceGNLParticipantID)) < 1 THEN '-' ELSE COALESCE(TRIM(SourceGNLParticipantID), '-') END AS SourceGNLParticipantID, --Natural Key, Used to Populate PK/FK PartyID in BDM
COALESCE(SourceGNLAccountnumber, 0) AS SourceGNLAccountnumber, --Natural Key, Used to Populate PK/FK PartyID in BDM
TRIM(RoleType) AS RoleType, --Natural Key, Used to Populate PK/FK PartyID in BDM
COALESCE(TRIM(ElectronicAddressTypeCode), '-') AS ElectronicAddressTypeCode,
CASE WHEN LENGTH(TRIM(ElectronicAddressText)) < 1 THEN '-' ELSE COALESCE(TRIM(ElectronicAddressText), '-') END AS ElectronicAddressText,
COALESCE(TRIM(RoleType), '-') AS ElectronicAddressCategoryTypeCode,
CurrentRecordInd AS CurrentRecordIndicator,
'Genelco' AS SourceSystemCode,
LogicalDelIndicator AS LogicalDeleteIndicator,
current_user() AS LastUpdateUserID,
current_timestamp AS LastUpdateDateTime,
current_timestamp as hivelastupdatetimestamp,
"0" as hashcode
FROM
( --Transform Query
  Select SourceGNLGroupNumber,
  SourceGNLParticipantID,
  SourceGNLAccountnumber,
  RoleType,
  ElectronicAddressText,
  ElectronicAddressTypeCode,
  LogicalDelIndicator,
  CurrentRecordInd
  FROM
  (
    select GCGRP AS SourceGNLGroupNumber, ----accountlevel
    AR.A1SSN AS SourceGNLParticipantID,
    AR.A1ACCT AS SourceGNLAccountnumber,
    AR.A1RRTY AS RoleType,
    AM.A8ADD1 AS ElectronicAddressText, -------GroupBillingData
    'Email' AS ElectronicAddressTypeCode,
    AM.LogicalDel_ind AS LogicalDelIndicator,
    case when AM.LogicalDel_ind = 'N' then 'Y' else 'N' end AS CurrentRecordInd,
    max(CAST(CONCAT_WS('-', CONCAT(CAST(A1EDCY AS STRING),CAST(A1EDYR AS STRING)), CAST(A1EDMT AS STRING), CAST(A1EDDY AS STRING)) AS DATE)) AS maxeffectivedate,
    max(AR.A1SEQ3) AS MaxSeq,
    RANK() OVER (PARTITION BY GRP.GCGRP, AR.A1SSN, AR.A1ACCT ORDER BY AM.A8ADTM desc) AS TimeRank
    FROM
    ${WORK_DATABASE}.dim_work_grpctrl GRP
    INNER JOIN ${WORK_DATABASE}.dim_work_addrrel AR
    on GRP.GCGRP = AR.A1GRP
    AND A1ACCT = 0 -----groupaccount level addresses - party for groups
    AND GRP.scd_flag = true AND AR.scd_flag = true
    AND GRP.LogicalDel_ind = 'N' AND AR.LogicalDel_ind = 'N'
    INNER JOIN ${WORK_DATABASE}.dim_work_addrmstr AM
    on AR.A1ADJD = AM.A8ADJD
    and AR.A1AEYR = AM.A8AEYR
    and AR.A1ADTM = AM.A8ADTM
    AND AM.scd_flag = true
    AND A8ADD1 like '%@%'
    AND AM.LogicalDel_ind = 'N'
    group by GCGRP, AR.A1SSN, AR.A1ACCT, AR.A1RRTY, AM.A8ADD1, AM.LogicalDel_ind, AM.A8ADTM
    --and A1SSN <> '0000000000'
    union All

    select AMGRP AS SourceGNLGroupNumber, ----subaccountlevel
    AR.A1SSN AS SourceGNLParticipantID,
    ACT.AMACCT AS SourceGNLAcctnumber,
    AR.A1RRTY AS RoleType,
    AM.A8ADD1 AS ElectronicAddressText, -------GroupContactData
    'Email' AS ElectronicAddressTypeCode,
    AM.LogicalDel_ind AS LogicalDelIndicator,
    case when AM.LogicalDel_ind = 'N' then 'Y' ELSE 'N' end AS CurrentRecordInd,
    max(CAST(CONCAT_WS(CONCAT(CAST(A1EDCY AS STRING),CAST(A1EDYR AS STRING)),CAST(A1EDMT AS STRING),CAST(A1EDDY AS STRING), '/') AS DATE)) AS maxeffectivedate,
    max(AR.A1SEQ3) AS MaxSeq,
    RANK() OVER (PARTITION BY ACT.AMGRP, AR.A1SSN, ACT.AMACCT ORDER BY AM.A8ADTM desc) AS TimeRank
    FROM
    ${WORK_DATABASE}.dim_work_actmstr ACT
    INNER JOIN ${WORK_DATABASE}.dim_work_addrrel AR
    on ACT.AMGRP = AR.A1GRP
    and ACT.AMACCT = AR.A1ACCT  ------subaccount level addresses
    AND ACT.scd_flag = true AND AR.scd_flag = true
    AND ACT.LogicalDel_ind = 'N' AND AR.LogicalDel_ind = 'N'
    INNER JOIN ${WORK_DATABASE}.dim_work_addrmstr AM
    on AR.A1ADJD = AM.A8ADJD
    and AR.A1AEYR = AM.A8AEYR
    and AR.A1ADTM = AM.A8ADTM
    AND AM.scd_flag = true
    AND A8ADD1 like '%@%'
    and A1ACCT not BETWEEN 1 and 99
    AND AM.LogicalDel_ind = 'N'
    group by AMGRP, A1SSN, AMACCT, A1RRTY, A8ADD1, am.LogicalDel_ind, AM.A8ADTM
    --and A1SSN <> '0000000000'
  ) PartyElectronicAddress
  where TimeRank = 1
) TransformQuery;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PartyElectronicAddress WHERE 1=0 LIMIT 1;



