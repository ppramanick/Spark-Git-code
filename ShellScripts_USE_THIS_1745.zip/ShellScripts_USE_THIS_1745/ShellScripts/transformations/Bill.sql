INSERT OVERWRITE TABLE ${WORK_DATABASE}.Bill
SELECT
COALESCE(BillNumber, '-') AS BillNumber,
CASE WHEN InvoiceNumber IS NULL OR TRIM(InvoiceNumber) = ''
  THEN '-'
  ELSE COALESCE(TRIM(InvoiceNumber), '-') 
END AS InvoiceNumber,
COALESCE(CAST(CAST(BillDueDate AS DATE) AS TIMESTAMP), CAST(CAST('9999-12-31' AS DATE) AS TIMESTAMP)) AS BillDueDate,
BillDueAmount AS BillDueAmount,
COALESCE(CAST(CAST(BillCreationDate AS DATE) AS TIMESTAMP), CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP)) AS BillCreationDate,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS BillScheduleDate,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS BillEffectiveFromDate,
CAST(CAST('9999-12-31' AS DATE) AS TIMESTAMP) AS BillEffectiveToDate,
'-' AS BillCancelledFlag,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS BillCancellationDate,
'-' AS BillIsRebillFlag,
'-' AS BillIsFinalFlag,
BillAmount AS BillAmount,
0.00 AS BillPaidAmount,
'-' AS BillCreditAppliedFlag,
'-' AS BillWriteoffFlag,
'-' AS BillStatusCode,
SubAccountNumber AS SubAccountNumber,
CASE WHEN LENGTH(GroupInsuranceAgreementNumber) < 1
  THEN '-'
  ELSE COALESCE(TRIM(GroupInsuranceAgreementNumber), '-') 
END AS GroupInsuranceAgreementNumber,
current_timestamp AS LastUpdateDateTime,
CurrentRecordInd AS CurrentRecordIndicator,
'Genelco' AS SourceSystemCode,
LogicalDel_ind AS LogicalDeleteIndicator,
current_user() AS LastUpdateUserID,
'-' AS ContributionBillingTypeCode,
CURRENT_TIMESTAMP as hivelastupdatetime,
"0" as hashcode
FROM
(
  SELECT Bill.* 
  FROM
  (
    SELECT
    CONCAT_WS
    (
      '-',
      TRIM(EBGRP),
      CAST(CAST(EBACCT AS INT) AS STRING),
      CAST(CAST((EBSDCY * 1000000 + EBSDYR * 10000 + EBSDMT * 100 + EBSDDY) AS INT) AS STRING),
      CAST(CAST(EBTRLN AS INT) AS STRING),
      TRIM(EBINVN),
      TRIM(EBUSER)
    ) AS BillNumber,
    TRIM(EBINVN) AS InvoiceNumber,
    CAST(EBSTIM AS INT) AS TMSTMP,
    TRIM(EBGRP) AS GroupInsuranceAgreementNumber, 
    CAST(EBACCT AS INT) AS SubAccountNumber,
    EBTTPC AS BillAmount,
    SUM(EBTTPD) AS EBTTPD,
    (EBTTPC +  SUM(EBTTPD)) AS BillDueAmount,      
    CAST(CAST(CAST((EBRDCY * 1000000 + EBRDYR * 10000 + EBRDMT * 100 + EBRDDY) AS INT) AS TIMESTAMP) AS DATE) AS BillCreationDate,
    CAST(CAST(CAST((EBBGCY * 1000000 + EBBGYR * 10000 + EBBGMT * 100 + EBBGDY) AS INT) AS TIMESTAMP) AS DATE) AS BillDueDate,
    LogicalDel_ind,
    'Y' AS CurrentRecordInd
    FROM ${WORK_DATABASE}.dim_work_BILLHIST
    WHERE EBSSN = '0000000000'  
    AND EBACCT >= 100
    AND EBINVN>' '
    and EBTTPC>0
    GROUP BY EBGRP, EBACCT, EBSDCY, EBSDYR, EBSDMT, EBSDDY, EBTRLN, EBINVN, EBUSER, EBTTPC, EBRDCY, EBRDYR, EBRDMT, EBRDDY,
    EBBGCY, EBBGYR, EBBGMT, EBBGDY, LogicalDel_ind, EBSTIM
  ) Bill
  INNER JOIN
  (
    SELECT
    CONCAT_WS
    (
      '-',
      TRIM(EBGRP),
      CAST(CAST(EBACCT AS INT) AS STRING),
      CAST(CAST((EBSDCY * 1000000 + EBSDYR * 10000 + EBSDMT * 100 + EBSDDY) AS INT) AS STRING),
      CAST(CAST(EBTRLN AS INT) AS STRING),
      TRIM(EBINVN),
      TRIM(EBUSER)
    ) AS BillNumber,
    CAST(MAX(EBSTIM) AS INT) AS TMSTMP ---- taking max timestamp to eliminate duplicate bill records
    from ${WORK_DATABASE}.dim_work_BILLHIST
    WHERE EBSSN = '0000000000'  
    AND EBACCT >= 100
    AND EBINVN>' '
    and EBTTPC>0
    GROUP BY EBGRP, EBACCT, EBSDCY, EBSDYR, EBSDMT, EBSDDY, EBTRLN, EBINVN, EBUSER
  ) BillLine
  ON Bill.BillNumber = BillLine.BillNumber WHERE Bill.TMSTMP = BillLine.TMSTMP
) BillTransform;



-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.Bill WHERE 1=0 LIMIT 1;



