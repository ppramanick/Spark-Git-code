INSERT OVERWRITE TABLE ${WORK_DATABASE}.Loss
SELECT 
CASE WHEN LENGTH(TRIM(ClaimNumber)) < 1 THEN '-' ELSE COALESCE(TRIM(ClaimNumber), '-') END AS ClaimNumber,
SourceGNLGroupNumber,
SourceGNLParticipantID,
SourceGNLDependentSeqNumber,
COALESCE(LossName, '-') AS LossName,
'-' AS LossDescriptorName,
'-' AS LossEventName,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS LossCloseDate,
0.0 AS LossChargeAmount,
'-' AS LossFirstPathologyCode,
'-' AS LossFirstPathologyFamilyCode,
'-' AS LossTypeCode,
CAST('1900-01-01' AS DATE) AS LossEventDate,
CAST('1900-01-01' AS DATE) AS LossNotificationDate,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS ProofofLossDate,
'-' AS ProofofLossIndicator,
CurrentRecord AS CurrentRecordIndicator,
'Genelco' AS SourceSystemCode,
LogicalDel_ind AS LogicalDeleteIndicator,
current_timestamp AS LastUpdateDateTime,
current_user() AS LastUpdateUserID,
current_timestamp AS hivelastupdatetimestamp,
'0' AS hashcode
FROM
(
  SELECT 
  CONCAT(
    CASE WHEN LENGTH(Cast(CAST(CSJYR AS INT) AS VARCHAR(10))) = 1 
      THEN TRIM(CONCAT('0', CAST(CAST(CSJYR AS INT) AS VARCHAR(10))))
      ELSE TRIM(Cast(CAST(CSJYR AS INT) AS VARCHAR(10)))
    END, 
    CASE WHEN LENGTH(Cast(CAST(CSJDAY AS INT) AS VARCHAR(10))) = 1 
      THEN TRIM(CONCAT('00', Cast(CAST(CSJDAY AS INT) AS VARCHAR(10))))
      WHEN LENGTH(Cast(CAST(CSJDAY AS INT) AS VARCHAR(10)))  = 2
      THEN TRIM(CONCAT('0', Cast(CAST(CSJDAY AS INT) AS VARCHAR(10))))
      ELSE TRIM(Cast(CAST(CSJDAY AS INT) AS VARCHAR(10)))
    END,
    CASE WHEN LENGTH(Cast(CAST(CSSEQ AS INT) AS VARCHAR(10))) = 1 
      THEN TRIM(CONCAT('000', Cast(CAST(CSSEQ AS INT) AS VARCHAR(10))))
      WHEN LENGTH(Cast(CAST(CSSEQ AS INT) AS VARCHAR(10))) = 2
      THEN TRIM(CONCAT('00', Cast(CAST(CSSEQ AS INT) AS VARCHAR(10))))
      WHEN LENGTH(Cast(CAST(CSSEQ AS INT) AS VARCHAR(10))) = 3
      THEN TRIM(CONCAT('0', Cast(CAST(CSSEQ AS INT) AS VARCHAR(10))))
      ELSE TRIM(Cast(CAST(CSSEQ AS INT) AS VARCHAR(10)))
    END, 
    TRIM(Cast(TRIM(CSSUFX) AS VARCHAR(10)))
  ) AS ClaimNumber,
  TRIM(BLCDSC) AS LossName,
  COALESCE(TRIM(CSR.CSGRP), '-') AS SourceGNLGroupNumber,
  COALESCE(TRIM(CSR.CSSSN), '0000000000') AS SourceGNLParticipantID,
  COALESCE(CSR.CSDSEQ, 0) AS SourceGNLDependentSeqNumber,
  'Y' AS CurrentRecord,
  CSR.LogicalDel_ind AS LogicalDel_ind
  FROM ${WORK_DATABASE}.dim_work_CSRMSTR CSR
  inner join ${WORK_DATABASE}.dim_work_BLHIST BH
  ON CSR.scd_flag = true AND BH.scd_flag = true
  AND CSR.LogicalDel_ind = 'N' AND BH.LogicalDel_ind = 'N'
  AND CSR.CSJYR = BH.BLJYR
  and CSR.CSJDAY = BH.BLJDAY
  and CSR.CSSEQ = BH.BLSEQ
  and csr.cssufx = bh.BLSUFX
  group by CSJYR, CSJDAY, CSSEQ,CSSUFX, BLCDSC, CSGRP, CSSSN, CSDSEQ, CSR.LogicalDel_ind
) LossTransform;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.Loss WHERE 1=0 LIMIT 1;