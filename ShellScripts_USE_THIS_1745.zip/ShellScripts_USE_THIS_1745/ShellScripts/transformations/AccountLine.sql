INSERT OVERWRITE TABLE ${WORK_DATABASE}.AccountLine
SELECT
COALESCE(AccountLine.AccountlineNumber, '-') as AccountLineNumber,
COALESCE(TRIM(BanUMBER), '-') AS BusinessAccountNumber,
COALESCE(AccountLine.TransactionNumber, '-') as TransactionNumber,
AccountLineType AS AccountLineType,
CASE WHEN LENGTH(TRIM(InternalCompanyCode)) < 1 
  THEN '-' 
ELSE 
  COALESCE(TRIM(InternalCompanyCode), '-') 
END AS InternalCompanyCode,
'-' AS AccountLineDescription,
'1900-01-01' as AccountLineTransactionProcessingDate,
'1900-01-01' as AccountLineTransactionCreationDate,
'-' as AccountLineTransactionIsReversedIndicator,
'1900-01-01' as AccountLineTransactionReversalDate,
COALESCE(AccountLine.AccountLineAmount, 0) as AccountLineAmount,
0.00 as AccountLineUnallocatedAmount,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
'N' as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetime,
"0" as hashcode
FROM
(
  SELECT 
  CONCAT(TRIM(EBGRP) ,'-',CAST(CAST(EBACCT AS INT) AS STRING),'-', CASE WHEN CAST(EBACCT AS INT) < 1000 THEN '' ELSE CONCAT('-',TRIM(EBSSN)) END) AS BanUMBER,
  CONCAT_WS('-',
    TRIM(EBGRP),
    CAST(CAST(EBACCT AS INT) as STRING),
    CAST(CAST((EBSDCY * 1000000 + EBSDYR * 10000 + EBSDMT * 100 + EBSDDY) AS INT) AS STRING),
    CAST(CAST(EBSTIM AS INT) as STRING), TRIM(EBSSN), CAST(CAST(EBTRLN AS INT) as STRING),
    TRIM(EBUSER)
  ) AS AccountlineNumber,
COALESCE(concat_ws('-',trim(EBGRP),cast(cast(EBACCT as int) as STRING),cast(cast(EBSDCY * 1000000 + EBSDYR * 10000 + EBSDMT * 100 + EBSDDY as int) as STRING),cast(cast(EBSTIM as int) as STRING),cast(cast(EBTRLN as int) as varchar(10)),trim(EBUSER)),'-') AS TransactionNumber,
  EBTTPC as AccountLineAmount,
  'Bill Line' AccountLineType,
  EBCURC as InternalCompanyCode
  FROM ${WORK_DATABASE}.dim_work_BILLHIST
  WHERE scd_flag = true
  AND LogicalDel_ind = 'N'
  AND EBSSN > '0000000000'
  AND EBACCT >= 100

  UNION ALL

  select       
  CONCAT_WS('-', TRIM(PAGRP), CAST(CAST(PAACCT AS INT) AS STRING),CASE WHEN CAST(PAACCT AS INT) < 1000 THEN '' ELSE CONCAT('-',TRIM(PASSN)) END) AS BanUMBER,
  CONCAT_WS('-',
    TRIM(B2BATI),
    TRIM(PAGRP),
    CAST(CAST(PAACCT AS INT) as STRING),
    TRIM(PASSN),
    CAST(CAST(PADSEQ AS INT) as STRING),
    CAST(CAST(PACBMD AS INT) as STRING),
    TRIM(PAPRID),
    TRIM(PATYOC),
    CAST(CAST(PAFMSQ AS INT) AS STRING),
    CONCAT(CAST(CAST(PAWSCY AS INT) AS STRING),CAST(CAST(PAWSYR AS INT) AS STRING),CAST(CAST(PAWSMT AS INT) AS STRING),CAST(CAST(PAWSDY AS INT) AS STRING)),
    CAST(CAST(PATRLN AS INT) AS STRING)
  ) AS AccountlineNumber,
  TRIM(b.B2BATI) AS TransactionNumber,
  PAAPAM as AccountLineAmount,
  'Payment Line' AS AccountLineType,
  PACURC AS InternalCompanyCode
  FROM ${WORK_DATABASE}.dim_work_PAYHIST a 
  INNER JOIN ${WORK_DATABASE}.dim_work_BTCTL b
  ON a.scd_flag = true AND b.scd_flag = true
  AND a.LogicalDel_ind = 'N' AND b.LogicalDel_ind = 'N' 
  AND a.PAACCT = b.B2ACCT AND a.PAGRP = b.B2GRP AND a.PASSN =  b.B2SSN
  WHERE PAACCT >= 100

  UNION ALL
  -------CLAIMLINE----------------
  SELECT
  CONCAT_WS('-', TRIM(BLGRP), TRIM(BLSSN)) AS BanUMBER,
  CONCAT_WS('-',
    CAST(CAST(BLJYR AS INT) AS STRING),
    CAST(CAST(BLJDAY AS INT) AS STRING),
    CAST(CAST(BLSEQ AS INT) AS STRING),
    TRIM(BLSUFX),
    CAST(CAST(BLPPNO AS INT) AS STRING),
    CAST(CAST(BLADJN AS INT) AS STRING),
    CAST(CAST(BLBNLN AS INT) AS STRING)
  ) AS AccountlineNumber,  

  CONCAT_WS('-',
    CAST(CAST(BLJYR AS INT) AS STRING),
    CAST(CAST(BLJDAY AS INT) AS STRING),
    CAST(CAST(BLSEQ AS INT) AS STRING),
    TRIM(BLSUFX),
    CAST(CAST(BLPPNO AS INT) AS STRING),
    CAST(CAST(BLADJN AS INT) AS STRING),
    CAST(CAST(BLBNLN AS INT) AS STRING)
  ) AS TransactionNumber,
  (BLBFA1+BLBFA2+BLBFA3) AS AccountLineAmount,
  'Claim Indemnification Line' AS AccountLineType,
  BLCURC AS InternalCompanyCode
  FROM ${WORK_DATABASE}.dim_work_BLHIST
  WHERE scd_flag = true AND LogicalDel_ind = 'N'

  UNION ALL
  --------------------DISBURSEMENT LINE---------------

  SELECT
  CONCAT_WS('-',PPH.PPGRP,CSR.CSSSN) AS BanUMBER,
  CONCAT_WS('-',
    CAST(CAST(PPJYR AS INT) AS STRING),
    CAST(CAST(PPJDAY AS INT) AS STRING),
    CAST(CAST(PPSEQ AS INT) AS STRING),
    TRIM(PPSUFX),
    CAST(CAST(PPPPNO AS INT) AS STRING),
    CAST(CAST(PPADJN AS INT) AS STRING)
  ) AS AccountlineNumber,
  CONCAT_WS('-',
    CAST(CAST(PPJYR AS INT) AS STRING),
    CAST(CAST(PPJDAY AS INT) AS STRING),
    CAST(CAST(PPSEQ AS INT) AS STRING),
    TRIM(PPSUFX),
    CAST(CAST(PPPPNO AS INT) AS STRING),
    CAST(CAST(PPADJN AS INT) AS STRING)
  ) AS TransactionNumber,
  PPAMTP AS AccountLineAmount,
  'Disbursement Line' AS AccountLineType,
  CSCURC AS InternalCompanyCode
  FROM ${WORK_DATABASE}.dim_work_PPHIST PPH
  INNER JOIN ${WORK_DATABASE}.dim_work_CSRMSTR CSR
  ON PPH.scd_flag = true AND CSR.scd_flag = true
  AND PPH.LogicalDel_ind = 'N' AND CSR.LogicalDel_ind = 'N'
  AND PPH.PPJYR = CSR.CSJYR
  AND PPH.PPJDAY = CSR.CSJDAY
  AND PPH.PPSEQ = CSR.CSSEQ
  AND PPH.PPSUFX = CSR.CSSUFX
) AccountLine;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.AccountLine WHERE 1=0 LIMIT 1;
