INSERT OVERWRITE TABLE ${WORK_DATABASE}.Producer
SELECT
Producer.NPN,
Producer.BusinessTypeCode,
Producer.IsPayee as EligibleforCommissionIndicator,
Producer.PrincipalAgentCode,
Producer.SmallCheckLimitAmount,
Producer.PreferredPaymentMethodTypeCode,
Producer.FieldOfficeCode,
Producer.AliasName,
Producer.ReportingAuthorityAgentCode,
CAST(Producer.FieldOfficeFromDate AS TIMESTAMP),
CAST(Producer.FieldOfficeToDate AS TIMESTAMP),
Producer.IsPrimaryFieldOfficeIndicator,
Producer.ExcludeFromNationalProducerDatabaseIndicator,
Producer.ProducerStatusCode,
CAST(Producer.ProducerStatusDate AS TIMESTAMP),
Producer.ProducerStatusChangeReasonCode ,
CAST(Producer.ProducerStatusChangeReasonDate AS TIMESTAMP),
CAST(Producer.HireDate AS TIMESTAMP) AS HireDate,
Producer.IsPayee as IsPayeeIndicator,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'VUE' as SourceSystemCode,
'N' as LogicalDeleteIndicator,
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetimestamp,
'0' as hashcode
FROM
(
  SELECT
  CASE WHEN TRIM(NPN) = '' OR NPN IS NULL 
    THEN '-' 
    ELSE TRIM(NPN) 
  END AS NPN,
  --agent_code as PrincipalAgentCode,
  --status as ProducerStatusCode,
  CASE WHEN TRIM(AgentCode) = '' OR AgentCode IS NULL THEN '-' ELSE TRIM(AgentCode) END AS PrincipalAgentCode,
  CASE WHEN TRIM(status) = '' OR status IS NULL THEN '-' ELSE TRIM(status) END AS ProducerStatusCode,
  COALESCE
  (
    CASE
    WHEN TRIM(StatusDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(StatusDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(StatusDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(StatusDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(StatusDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(StatusDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(StatusDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(StatusDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(StatusDate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(StatusDate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(StatusDate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS ProducerStatusDate,
  CASE WHEN TRIM(reason) = '' OR reason IS NULL THEN '-' ELSE TRIM(reason) END AS ProducerStatusChangeReasonCode,
  COALESCE
  (
    CASE
    WHEN TRIM(StatusReasonDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(StatusReasonDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(StatusReasonDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(StatusReasonDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(StatusReasonDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(StatusReasonDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(StatusReasonDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(StatusReasonDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(StatusReasonDate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(StatusReasonDate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(StatusReasonDate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS ProducerStatusChangeReasonDate,
  CASE WHEN TRIM(BusinessType) = '' OR BusinessType IS NULL THEN '-' ELSE TRIM(BusinessType) END AS BusinessTypeCode,
  CAST(IsPayee AS INT) AS IsPayee,
  CASE WHEN TRIM(PaymentMethod) = '' OR PaymentMethod IS NULL THEN '-' ELSE TRIM(PaymentMethod) END AS PreferredPaymentMethodTypeCode,
  --TRIM(field_office_code) as FieldOfficeCode,
  CASE WHEN TRIM(FieldOfficeCode) = '' OR FieldOfficeCode IS NULL THEN '-' ELSE TRIM(FieldOfficeCode) END AS FieldOfficeCode,
  CASE WHEN TRIM(dba) = '' OR dba IS NULL THEN '-' ELSE TRIM(dba) END AS AliasName,
  CASE WHEN TRIM(RAAgentCode) = '' OR RAAgentCode IS NULL THEN '-' ELSE TRIM(RAAgentCode) END AS ReportingAuthorityAgentCode,
  COALESCE
  (
    CASE
    WHEN TRIM(FieldOfficeFromDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FieldOfficeFromDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(FieldOfficeFromDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FieldOfficeFromDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(FieldOfficeFromDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FieldOfficeFromDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(FieldOfficeFromDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FieldOfficeFromDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(FieldOfficeFromDate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(FieldOfficeFromDate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(FieldOfficeFromDate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS FieldOfficeFromDate,
  COALESCE
  (
    CASE
    WHEN TRIM(FieldOfficeToDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FieldOfficeToDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(FieldOfficeToDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FieldOfficeToDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(FieldOfficeToDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FieldOfficeToDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(FieldOfficeToDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FieldOfficeToDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(FieldOfficeToDate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(FieldOfficeToDate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(FieldOfficeToDate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS FieldOfficeToDate,
  CAST(IsPrimaryFieldOffice AS INT) as IsPrimaryFieldOfficeIndicator,
  COALESCE(CAST(SmallCheckLimit AS INT), 0) as SmallCheckLimitAmount,
  COALESCE
  (
    CASE
    WHEN TRIM(HireDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(HireDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(HireDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(HireDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(HireDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(HireDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(HireDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(HireDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(HireDate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(HireDate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(HireDate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS HireDate,
  CAST(excludefrompdb AS INT) as ExcludeFromNationalProducerDatabaseIndicator
  FROM ${WORK_DATABASE}.dim_work_agentdemographics where scd_flag = true
) Producer
WHERE NPN <> '-';

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.Producer WHERE 1=0 LIMIT 1;



