create temporary macro toPmcDate(s string) CASE
      WHEN TRIM(s) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(s), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(s) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(s), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(s) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(s), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(s) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(s), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(s) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(s),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(s) AS DATE)
    END;

INSERT OVERWRITE ${WORK_DATABASE}.PubCommissions
SELECT
   toPmcDate(StatementDate) as StatementDate
  ,toPmcDate(FromDate) as FromDate
  ,toPmcDate(ToDate) as ToDate
  ,CAST(CarrierGroupCode AS INT)
  ,CarrierCode
  ,GroupProductNumber
  ,PolicyNumber
  ,GroupAccountNumber
  ,toPmcDate(EffectiveDate) as EffectiveDate
  ,DepositNumber
  ,toPmcDate(DepositDate) as DepositDate
  ,toPmcDate(TransactionDate) as TransactionDate
  ,toPmcDate(PaidToDate) as PaidToDate
  ,toPmcDate(DueDate) as DueDate
  ,CAST(Premium AS DOUBLE)
  ,PremiumType
  ,PaymentFrequency
  ,CAST(Months AS INT)
  ,CAST(AdvanceMonths AS INT)
  ,CAST(CommissionablePremium AS DOUBLE)
  ,CAST(CommissionRate AS DOUBLE)
  ,CAST(Revenue AS DOUBLE)
  ,CAST(EarnedCommission AS DOUBLE)
  ,ProductItemCode
  ,CommissionType
  ,TransactionCode
  ,TransactionDesc
  ,CAST(PolicyYear AS INT)
  ,State
  ,ProductCode
  ,ProductName
  ,AgentCode
  ,AgentRole
  ,RAAgentCode
  ,CAST(SubscriberCount AS INT)
  ,CAST(MemberCount AS INT)
  ,Insured_First_Name
  ,Insured_Last_Name
  ,Insured_Middle_Name
  ,Insured_Name
  ,Insured_Number
  ,Insured_Type
  ,CAST(Is_Individual AS INT)
  ,DOB
  ,Insured_Status
  ,toPmcDate(Insured_Status_Date) AS Insured_Status_Date
  ,WritingNumber
  ,Policy_Status
  ,toPmcDate(Policy_Status_Date) AS Policy_Status_Date
  ,Policy_Status_Reason
  ,toPmcDate(Policy_Status_Reason_Date) AS Policy_Status_Reason_Date
  ,toPmcDate(Policy_App_Date) AS Policy_App_Date
  ,toPmcDate(Policy_Paid_To_Date) AS Policy_Paid_To_Date
  ,CAST(Policy_Issue_Age AS INT)
  ,Trasaction_Source
FROM ${WORK_DATABASE}.dim_work_Commissions
where scd_flag=true;

SELECT * FROM ${WORK_DATABASE}.${TABLE} WHERE 1=0;