INSERT OVERWRITE TABLE ${WORK_DATABASE}.ClaimLine
SELECT
ClaimLine.AccountLineNumber as AccountLineNumber,
ClaimLine.ClaimNumber as ClaimNumber,
ClaimLine.DeliveredServiceName as DeliveredServiceName,
0.00 as FederalTaxWithheldonLateClaimInterestAmount,
0.00 as StateTaxWithheldonLateClaimInterestAmount,
0.00 as FederalTaxWithheldonEmployerPaidBenefitsAmount,
0.00 as StateTaxWithheldonEmployerPaidBenefitsAmount,
0.00 as FederalTaxWithheldonSection125PaidBenefitsAmount,
0.00 as StateTaxWithheldonSection125PaidBenefitsAmount,
0.00 as FederalTaxWithheldonBenefitsPaidtoProviderAmount,
0.00 as StateTaxWithheldonBenefitsPaidtoProviderAmount,
0.00 as LateClaimInterestPaymentAmount,
0.00 as LateClaimPenaltyPaymentAmount,
0.00 as StateTaxWithheldAmount,
0.00 as FederalTaxWithheldAmount,
0.00 as ChildSupportLienDisbursementAmount,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
'N' as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetimestamp,
"0" as hashcode
FROM(
SELECT
trim(coalesce(concat_ws('-',cast(cast(BLPPNO as int) as varchar(10)),cast(cast(BLADJN as int) as varchar(10)),cast(cast(BLBNLN as int) as varchar(10)),CASE WHEN BZDESP > ' ' THEN BZDESP ELSE BZBDSC END),'-')) AS DeliveredServiceName,
trim(coalesce(concat(CASE WHEN LENGTH(Cast(CSJYR AS INT)) = 1 THEN concat('0',cast(Cast(CSJYR AS INT) as varchar(10))) ELSE cast(Cast(CSJYR AS INT) as varchar(10)) END,
CASE WHEN LENGTH(Cast(CSJDAY AS INT)) = 1 THEN concat('00',cast(Cast(CSJDAY AS INT) as varchar(10))) WHEN LENGTH(Cast(CSJDAY AS INT))  = 2 THEN concat('0',cast(Cast(CSJDAY AS INT) as varchar(10))) ELSE cast(Cast(CSJDAY AS INT) as varchar(10)) END, CASE WHEN LENGTH(Cast(CSSEQ AS INT)) = 1  THEN concat('000',cast(Cast(CSSEQ AS INT) as varchar(10))) WHEN LENGTH(Cast(CSSEQ AS INT)) = 2 THEN concat('00',cast(Cast(CSSEQ AS INT) as varchar(10))) WHEN LENGTH(Cast(CSSEQ AS INT)) = 3 THEN concat('0',cast(Cast(CSSEQ AS INT) as varchar(10))) ELSE Cast(CSSEQ AS INT) END, Cast(TRIM(CSSUFX) AS VARCHAR(10))),'-')) AS ClaimNumber,
trim(coalesce(concat_ws('-',cast(cast(BLJYR as int) as varchar(10)),cast(cast(BLJDAY as int) as varchar(10)),cast(cast(BLSEQ as int) as varchar(10)),trim(BLSUFX),cast(cast(BLPPNO as int) as varchar(10)),cast(cast(BLADJN as int) as varchar(10)),cast(cast(BLBNLN as int) as varchar(10))),'-')) AS AccountLineNumber,
trim(coalesce(concat_ws('-',cast(cast(BLJYR as int) as varchar(10)),cast(cast(BLJDAY as int) as varchar(10)),cast(cast(BLSEQ as int) as varchar(10)),trim(BLSUFX),cast(cast(BLPPNO as int) as varchar(10)),cast(cast(BLADJN as int) as varchar(10)),cast(cast(BLBNLN as int) as varchar(10))),'-')) as AccountTXN
FROM ${WORK_DATABASE}.dim_work_BLHIST A
INNER JOIN ${WORK_DATABASE}.dim_work_CSRMSTR B 
ON A.BLJDAY = b.CSJDAY AND A.BLJYR = B.CSJYR AND A.BLSEQ = B.CSSEQ AND A.BLSUFX = B.CSSUFX
and A.scd_flag=true and A.LogicalDel_ind='N' and B.scd_flag=true and B.LogicalDel_ind='N'
inner join ${WORK_DATABASE}.dim_work_BNFTTBL C
on A.BLCCAT = C.BZCCAT and C.scd_flag=true and C.LogicalDel_ind='N'
) ClaimLine;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.Claim WHERE 1=0 LIMIT 1;