set hive.support.quoted.identifiers=none;
-- 4x YARN min container size
set hive.tez.container.size=24576;
-- 1/3 of TEZ container
set hive.auto.convert.join.noconditionaltask.size=8192;
-- 40% of TEZ container
set tez.runtime.io.sort.mb=9830;
-- 10% of TEZ container
set tez.runtime.unordered.output.buffer.size-mb=2457;
-- 75% of the container size
set hive.tez.java.opts=-Xmx18432m -XX:NewRatio=8;
-- equal to container size
set tez.am.resource.memory.mb=6144;

INSERT OVERWRITE TABLE ${WORK_DATABASE}.CoveragePlan
SELECT
'Group Certificate' as InsuranceAgreementTypeCode,
CoveragePlan.InternalCompanyCode as InternalCompanyCode,
CoveragePlan.InsuranceAgreementNumber as InsuranceAgreementNumber,
0 as PreExistingConditionExistedMonths,
0 as PreExistingConditionDiagnosedMonths,
CoveragePlan.ProductCoverageCode as ProductCoverageCode,
CoveragePlan.CoveragePlanCode as CoveragePlanCode,
0 as CoveragePlanWynNSID,
0 as CoveragePlanWynID,
'-' as CoveragePlanDescription,
CoveragePlan.CoveragePlanEffectiveDate as CoveragePlanEffectiveDate,
coalesce(CoveragePlan.CoveragePlanEndDate,cast('9999-12-31' as date)) as CoveragePlanEndDate,
'-' as ProductSetCode,
'-' as CoveragePlanName,
'-' as GuaranteedIssueAvailableIndicator,
0 as GuaranteedIssueMinimumEmployeeCount,
0.00 as GuaranteedIssueBenefitAmount,
0.00 as EmployeeMinimumHoursWorkedRequiredCount,
0 as InsuredMinimumAgeforCoverage,
'-' as WaiveEligibilityQuestionsIndicator,
'-' as PreExistingConditionExcludedIndicator,
0.00 as BuildingBenefitRiderPercentage,
0 as BuildingBenefitRiderYearsCount,
'-' as WaiveMinimumHoursWorkedRequirement,
'-' as ClaimWaitingPeriodAppliesIndicator,
0 as ClaimWaitingPeriodPayableDaysCount,
0.00 as BenefitPayableIncrementAmount,
'-' as MandatoryForEnrollmentRiderIndicator,
'-' as EmployeeContributiontoPremiumIndicator,
0.00 as EmployeeContributiontoPremiumPercentage,
'-' as TobaccoRatingTypeCode,
'-' as PortabilityIndicator,
'-' as TaxStatusCode,
'-' as CustomBuildTypeIndicator,
'-' as CoveredPartySetTypeCode,
'9999-12-31 23:59:59.000000' as GroupInsuranceAgreementCoverageEndDate,
'1900-01-01' as GroupInsuranceAgreementCoverageEffectiveDate,
0.00 as MaximumBenefitAmount,
0.00 as MinimumBenefitAmount,
'9999-12-31' as CoveragePlanTerminationReasonDate,
'-' as CoveragePlanTerminationReasonCode,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
'N' as LogicalDeleteIndicator,
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetimestamp,
"0" as hashcode
FROM
(
  select
  trim(coalesce(PMGRP,'-')) AS InsuranceAgreementNumber,
  COALESCE(CONCAT_WS('-',TRIM(PMGRP),TRIM(PMPRID)), '-') AS ProductCoverageCode,
  trim(coalesce(PDCACD,'-')) as InternalCompanyCode,
  trim(coalesce(PHPLAN,'-')) as CoveragePlanCode,
  CAST(coalesce(CONCAT_WS('-',CONCAT(CAST(CAST(PMEDCY AS INT) AS STRING),lpad(CAST(CAST(PMEDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(PMEDMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(PMEDDY AS INT) AS STRING),2,"0")),'1900-01-01') AS date) as CoveragePlanEffectiveDate,
  max(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(PMTDCY AS INT) AS STRING),lpad(CAST(CAST(PMTDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(PMTDMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(PMTDDY AS INT) AS STRING),2,"0")) AS date)) as CoveragePlanEndDate
  from
  ${WORK_DATABASE}.dim_work_PDTMSTR PM
  inner join ${WORK_DATABASE}.dim_work_PDTDEFN PD
  ON PM.PMGRP = PD.PDGRP
  AND PM.PMPRID = PD.PDPRID and PM.scd_flag=true and PD.scd_flag=true and PM.LogicalDel_ind='N' and PD.LogicalDel_ind='N'
  INNER JOIN ${WORK_DATABASE}.dim_work_PDTHIST PH
  ON PH.PHGRP = PM.PMGRP
  AND PH.PHPRID=PM.PMPRID and PH.scd_flag=true and PH.LogicalDel_ind='N'
  group by PM.PMGRP, PM.PMPRID, PD.PDCACD, PH.PHPLAN, PM.PMEDCY, PM.PMEDYR, PM.PMEDDY, PM.PMEDMT
) CoveragePlan;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.CoveragePlan WHERE 1=0 LIMIT 1;



