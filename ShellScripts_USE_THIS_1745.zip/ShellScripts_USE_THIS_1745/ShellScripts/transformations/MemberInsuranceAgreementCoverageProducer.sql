INSERT OVERWRITE TABLE ${WORK_DATABASE}.MemberInsuranceAgreementCoverageProducer
SELECT
FieldOfficeName,
MemberInsuranceAgreementCoverageEffectiveDate,
ProducerRoleTypeCode,
ProducerWritingNumber,
InternalCompanyCode,
CommissionSplitPercentage,
CertNumber,
ProducerHierarchyTypeCode,
SalesChannelCode AS SalesChannelCode,
'Y' AS CurrentRecordIndicator,
'PMC' AS SourceSystemCode,
'N' AS LogicalDeleteIndicator,
CURRENT_TIMESTAMP AS LastUpdateDateTime,
CURRENT_USER() AS LastUpdateUserID,
CURRENT_TIMESTAMP AS hivelastupdatetimestamp,
'0' AS hashcode
FROM
(
  SELECT
  COALESCE
  (
    CASE
    WHEN TRIM(SC.EffectiveDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(SC.EffectiveDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(SC.EffectiveDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(SC.EffectiveDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(SC.EffectiveDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(SC.EffectiveDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(SC.EffectiveDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(SC.EffectiveDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(SC.EffectiveDate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(SC.EffectiveDate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(SC.EffectiveDate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS MemberInsuranceAgreementCoverageEffectiveDate,
  CASE 
    WHEN TRIM(AA.Role) = '' OR TRIM(AA.Role) = ' '
    THEN '-'
    ELSE COALESCE(TRIM(AA.Role), '-')
  END AS ProducerRoleTypeCode,
  CASE WHEN TRIM(AA.WritingNumbers) = '' OR TRIM(AA.WritingNumbers) = ' '
    THEN '-'
    ELSE COALESCE(TRIM(AA.WritingNumbers), '-')
  END AS  ProducerWritingNumber,
  CASE
    WHEN TRIM(SC.CarrierCode) = '' OR TRIM(SC.CarrierCode) = ' '
    THEN '-'
    ELSE COALESCE(TRIM(SC.CarrierCode), '-')
  END AS InternalCompanyCode,
  COALESCE(SC.SplitPercentage, 0.0) AS CommissionSplitPercentage,
  COALESCE(TRIM(SC.CertNumber), '-') AS CertNumber,
  CASE
    WHEN TRIM(SC.CommissionType) = '' OR TRIM(SC.CommissionType) = ' '
    THEN '-'
    ELSE COALESCE(TRIM(SC.CommissionType), '-')
  END AS ProducerHierarchyTypeCode,
  CASE
    WHEN TRIM(AA.FieldOfficeName) = '' OR TRIM(AA.FieldOfficeName) = ' '
    THEN '-'
    ELSE COALESCE(TRIM(AA.FieldOfficeName), '-')
  END AS FieldOfficeName,
  CASE
    WHEN TRIM(AA.Channel) = '' OR TRIM(AA.Channel) = ' '
    THEN '-'
    ELSE COALESCE(TRIM(AA.Channel), '-')
  END AS SalesChannelCode
  FROM ${WORK_DATABASE}.dim_work_SubscriberCoverage SC
  INNER JOIN ${WORK_DATABASE}.dim_Work_AgentArrangements AA
  ON TRIM(SC.ArrangmentCode) = TRIM(AA.ArrangementCode)
  AND SC.scd_flag = true AND AA.scd_flag = true

) MIACP
WHERE MemberInsuranceAgreementCoverageEffectiveDate <> CAST('1900-01-01' AS DATE) 
AND ProducerRoleTypeCode <> '-' 
AND ProducerWritingNumber <> '-'
AND InternalCompanyCode <> '-'
AND CertNumber <> '-';


-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.MemberInsuranceAgreementCoverageProducer WHERE 1=0 LIMIT 1;


