INSERT OVERWRITE TABLE ${WORK_DATABASE}.Payment
SELECT
'-' as PaymentMethodTypeCode,
'1900-01-01' as BankReceivedDate,
Payment.PaymentReceivedDate as PaymentReceivedDate,
'-' as PaymentCanceledIndicator,
'1900-01-01' as PaymentCancelDate,
'-' as PaymentCancelReasonCode,
Payment.PaymentAmount as PaymentAmount,
'-' as PaymentMethodNumber,
'-' as PaymentCleanIndicator,
Payment.PaymentNumber as PaymentNumber,
'-' as PaymentReceiptNumber,
'-' as InitialPaymentIndicator,
0 as AccountOwnerPartyID,
'-' as PaymentBatchID,
'-' as PaymentBatchGroupingID,
'-' as PaymentChannelCode,
'-' as ProcessedAsPaidandBilledIndicator,
'-' as SubmittedAsPaidandBilledIndicator,
CURRENT_TIMESTAMP as LastUpdateDateTime,
Payment.CurrentRecordInd as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
Payment.LogicalDel_ind as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetime,
"0" as hashcode
FROM(
select 
CASE WHEN cast(B2RECY as int)= 0 OR cast(B2REYR as int) = 0 OR cast(B2REMT as int) = 0 OR cast(B2REDY as int) = 0 THEN cast('1900-01-01' as date) ELSE CAST(concat_ws('-',concat(cast(cast(B2RECY as int) as varchar(10)),SUBSTR(CONCAT('0',cast(cast(B2REYR as int) as varchar(10))),-2)),SUBSTR(CONCAT('0',cast(cast(B2REMT as int) as varchar(10))),-2),SUBSTR(CONCAT('0',cast(cast(B2REDY as int) as varchar(10))),-2)) AS date) END AS PaymentReceivedDate,
coalesce(B2BCHT,0.00) AS PaymentAmount,
CASE WHEN B2BATI is null OR TRIM(B2BATI) = '' THEN '-' ELSE TRIM(B2BATI) END AS PaymentNumber,  
'N' as LogicalDel_ind,
'Y' as CurrentRecordInd
FROM ${WORK_DATABASE}.dim_work_BTCTL where B2RECY > 0 and LogicalDel_ind = 'N' and scd_flag=true
) Payment;


-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.Payment WHERE 1=0 LIMIT 1;

