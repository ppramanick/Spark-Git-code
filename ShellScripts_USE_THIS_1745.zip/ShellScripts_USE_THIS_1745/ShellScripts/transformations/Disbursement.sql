INSERT OVERWRITE TABLE ${WORK_DATABASE}.Disbursement
SELECT
'-' as DisbursementOperationCode,
Disbursement.SourceGNLGroupNumber,
Disbursement.SourceGNLParticipantID,
0 as SourceGNLDependentSequenceNumber,
Disbursement.DisbursementAmount,
'1900-01-01 00:00:00.000' as DisbursementCreationDate,
'1900-01-01' as DisbursementSentDate,
'1900-01-01' as DisbursementCashedDate,
'1900-01-01' as DisbursementCancelDate,
'-' as DisbursementMoneyChannelCode,
Disbursement.DisbursementNumber,
Disbursement.DisbursementTypeCode,
'-' as DisbursementCancelReasonCode,
'-' as DisbursementPaymentMethodCode,
0.00 as InterestPaymentAmount,
'-' as DisbursementStatusCode,
'-' as BackupWithholdingIndicator,
0.00 as TaxWithholdingAmount,
'1900-01-01' as DisbursementStatusDate,
Disbursement.DisbursementPaymentMethodNumber,
'-' as DisbursementRequestSourceSystemCode,
'1900-01-01 00:00:00.000' as BackupWIthholdingDate,
'1900-01-01 00:00:00.000' as BackupWithholdingStopDate,
0.00 as BackupWithholdingAmount,
'1900-01-01 00:00:00.000' as DisbursementCreationTime,
'-' as DisbursementPaymentTypeCode,
'-' as InternalCompanyCode,
'-' as ACHReturnCode,
'-' as BackupWithholdingRemarkCode,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
'N' as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetimestamp,
0 as hashcode
FROM (
SELECT 
trim(coalesce(CSGRP,'-')) as SourceGNLGroupNumber,
trim(coalesce(CSSSN,'0000000000')) AS SourceGNLParticipantID,
PPEMCN AS DisbursementPaymentMethodNumber,
coalesce(PPEMCA,0.00) AS Disbursementamount, 
'Claim' AS DisbursementTypeCode,   
PPCPMI AS DisbursementPaymentMethodCode,
coalesce(concat(CASE WHEN LENGTH(Cast(PPJYR AS INT)) = 1 THEN concat('0',cast(Cast(PPJYR AS INT) as varchar(10))) ELSE cast(Cast(PPJYR AS INT) as varchar(10)) END, CASE WHEN LENGTH(Cast(PPJDAY AS INT)) = 1 THEN concat('00',cast(Cast(PPJDAY AS INT) as varchar(10))) WHEN LENGTH(Cast(PPJDAY AS INT))  = 2 THEN concat('0',cast(Cast(PPJDAY AS INT) as varchar(10))) ELSE cast(Cast(PPJDAY AS INT) as varchar(10)) END, CASE WHEN LENGTH(Cast(PPSEQ AS INT)) = 1  THEN concat('000',cast(Cast(PPSEQ AS INT) as varchar(10))) WHEN LENGTH(Cast(PPSEQ AS INT)) = 2 THEN concat('00',cast(Cast(PPSEQ AS INT) as varchar(10))) WHEN LENGTH(Cast(PPSEQ AS INT)) = 3 THEN concat('0',cast(Cast(PPSEQ AS INT) as varchar(10))) ELSE Cast(PPSEQ AS INT) END, trim(coalesce(PPSUFX,'')),cast(Cast(PPPPNO AS INT) as varchar(10)),cast(Cast(PPADJN AS INT) as varchar(10))),'-') AS DisbursementNumber  
FROM ${WORK_DATABASE}.dim_work_PPHIST PP
inner join ${WORK_DATABASE}.dim_work_CSRMSTR CSR
on CSR.CSJYR = PP.PPJYR 
and CSR.CSJDAY = PP.PPJDAY
and CSR.CSSEQ = PP.PPSEQ
and CSR.CSSUFX = PP.PPSUFX and PP.scd_flag=true and PP.LogicalDel_ind='N' and CSR.scd_flag=true and CSR.LogicalDel_ind='N'
where PPEMCA > 0
) Disbursement;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.Claim WHERE 1=0 LIMIT 1;