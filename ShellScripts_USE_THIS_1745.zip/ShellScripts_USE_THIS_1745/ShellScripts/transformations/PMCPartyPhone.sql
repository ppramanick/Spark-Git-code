INSERT OVERWRITE TABLE ${WORK_DATABASE}.PMCPartyPhone
SELECT
NPN,
PhoneTypeCode,
COALESCE(IsPrimary,'-') AS PreferredPhoneTypeFlag,
COALESCE(PhoneNumber, '-') AS PhoneNumber,
'-' AS PhoneExtension,
CURRENT_TIMESTAMP AS LastUpdateDateTime,
'Y' AS CurrentRecordIndicator,
'VUE' AS SourceSystemCode,
'N' AS LogicalDeleteIndicator,
CURRENT_USER() AS LastUpdateUserID,
CURRENT_TIMESTAMP AS hivelastupdatetimestamp,
'0' AS hashcode
FROM 
(
  SELECT 
  CASE WHEN TRIM(NPN) = '' OR NPN is null
    THEN '-'
    ELSE TRIM(NPN) 
  END AS NPN,
  'BusinessPhone' as PhoneTypeCode, 
  IsPrimary,
  CASE WHEN TRIM(BusinessPhone) = '' OR BusinessPhone is null
    THEN '-'
    ELSE TRIM(BusinessPhone)
  END AS PhoneNumber
  FROM ${WORK_DATABASE}.dim_work_agentdemographics where LENGTH(BusinessPhone)>=1 AND scd_flag = true
  
  union all 
  
  SELECT 
  CASE WHEN TRIM(NPN) = '' OR NPN is null
    THEN '-' 
    ELSE TRIM(NPN)
  END AS NPN, 
  'HomePhone' as PhoneTypeCode, 
  IsPrimary,
  CASE WHEN TRIM(HomePhone) = '' OR HomePhone IS NULL
    THEN '-'
    ELSE TRIM(HomePhone) 
  END AS PhoneNumber
  FROM ${WORK_DATABASE}.dim_work_agentdemographics where LENGTH(HomePhone)>=1 AND scd_flag = true
  
  union all
  
  SELECT
  CASE WHEN TRIM(NPN) = '' OR NPN is null
    THEN '-'
    ELSE TRIM(NPN)
  END AS NPN,
  'AlternatePhone' as PhoneTypeCode,
  IsPrimary, 
  CASE WHEN TRIM(AlternatePhone) = '' OR AlternatePhone IS NULL 
  THEN '-' 
  ELSE TRIM(AlternatePhone)
  END AS PhoneNumber
  FROM ${WORK_DATABASE}.dim_work_agentdemographics where LENGTH(AlternatePhone)>=1 AND scd_flag = true
  union all
  SELECT 
  CASE WHEN TRIM(NPN) = '' OR NPN IS NULL
    THEN '-' 
    ELSE TRIM(NPN) 
  END AS NPN,
  'HomeFax' as PhoneTypeCode, 
  IsPrimary, 
  CASE WHEN TRIM(HomeFax) = '' OR HomeFax IS NULL 
    THEN '-'  
    ELSE TRIM(HomeFax)
  END AS PhoneNumber
  FROM ${WORK_DATABASE}.dim_work_agentdemographics where LENGTH(HomeFax)>=1 AND scd_flag = true
  union all
  SELECT 
  CASE WHEN TRIM(NPN) = '' OR NPN IS NULL
    THEN '-' 
    ELSE TRIM(NPN) 
  END AS NPN,
  'AlternateFax' as PhoneTypeCode, 
  IsPrimary,
  CASE WHEN TRIM(AlternateFax) = '' OR AlternateFax IS NULL 
    THEN '-' 
    ELSE TRIM(AlternateFax)
  END AS PhoneNumber
  FROM ${WORK_DATABASE}.dim_work_agentdemographics where LENGTH(AlternateFax)>=1 AND scd_flag = true
  union all
  SELECT 
  CASE WHEN TRIM(NPN) = '' OR NPN IS NULL 
    THEN '-' 
    ELSE TRIM(NPN)
  END AS NPN, 
  'BusinessMobile' as PhoneTypeCode, 
  IsPrimary, 
  CASE WHEN TRIM(BusinessMobile) = '' OR BusinessMobile IS NULL
    THEN '-'
    ELSE TRIM(BusinessMobile) 
  END AS PhoneNumber 
  FROM ${WORK_DATABASE}.dim_work_agentdemographics where LENGTH(BusinessMobile)>=1 AND scd_flag = true
  union all
  SELECT 
  CASE WHEN TRIM(NPN) = '' OR NPN IS NULL 
    THEN '-' 
    ELSE TRIM(NPN)
  END AS NPN, 
  'HomeMobile' as PhoneTypeCode, 
  IsPrimary, 
  CASE WHEN TRIM(HomeMobile) = '' OR HomeMobile IS NULL 
    THEN '-' 
    ELSE TRIM(HomeMobile)
  END AS PhoneNumber
  FROM ${WORK_DATABASE}.dim_work_agentdemographics where LENGTH(HomeMobile)>=1 AND scd_flag = true
  union all
  SELECT 
    CASE WHEN TRIM(NPN) = '' OR NPN IS NULL 
    THEN '-' 
    ELSE TRIM(NPN)
  END AS NPN, 
  'AlternateMobile' as PhoneTypeCode, 
  IsPrimary, 
  CASE WHEN TRIM(AlternateMobile) = '' OR AlternateMobile IS NULL 
    THEN '-' 
    ELSE TRIM(AlternateMobile)
  END AS PhoneNumber
  FROM ${WORK_DATABASE}.dim_work_agentdemographics where LENGTH(AlternateMobile)>=1 AND scd_flag = true
  union all
  SELECT 
  CASE WHEN TRIM(NPN) = '' OR NPN is null
    THEN '-' 
    ELSE TRIM(NPN) 
  END AS NPN, 
  'BusinessFax' as PhoneTypeCode,
  IsPrimary, 
  CASE WHEN TRIM(BusinessFax) = '' OR BusinessFax is null
    THEN '-'
    ELSE TRIM(BusinessFax)
  END AS PhoneNumber
  FROM ${WORK_DATABASE}.dim_work_agentdemographics where LENGTH(BusinessFax)>=1 AND scd_flag = true
) pmcpPhone
WHERE NPN <> '-';




-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PMCPartyPhone WHERE 1=0 LIMIT 1;






