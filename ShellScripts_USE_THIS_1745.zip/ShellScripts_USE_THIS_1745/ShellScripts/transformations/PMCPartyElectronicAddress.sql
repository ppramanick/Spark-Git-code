INSERT OVERWRITE TABLE ${WORK_DATABASE}.PMCPartyElectronicAddress
SELECT
PEA.NPN AS NPN,
PEA.ElectronicAddressCategoryTypeCode AS ElectronicAddressCategoryTypeCode,
PEA.ElectronicAddressTypeCode AS ElectronicAddressTypeCode,
PEA.ElectronicAddressText AS ElectronicAddressText,
CURRENT_TIMESTAMP AS LastUpdateDateTime,
'Y' AS CurrentRecordIndicator,
'VUE' AS SourceSystemCode,
'N' AS LogicalDeleteIndicator ,
CURRENT_USER() AS LastUpdateUserID,
current_timestamp AS hivelastupdatetimestamp,
"0" as hashcode
FROM 
(
  select 
  CASE WHEN TRIM(NPN) = '' OR NPN IS NULL
    THEN '-'
    ELSE TRIM(NPN) 
  END AS NPN,
  'Email' as ElectronicAddressCategoryTypeCode, 
  'Business' AS ElectronicAddressTypeCode,
  CASE WHEN TRIM(BusinessEmail) = '' OR BusinessEmail is NULL
    THEN '-' 
    ELSE TRIM(BusinessEmail) 
  END AS ElectronicAddressText
  FROM ${WORK_DATABASE}.dim_work_agentdemographics WHERE scd_flag = true
  
  union all 
  
  select 
  CASE WHEN TRIM(NPN) = '' OR NPN IS NULL
    THEN '-'
    ELSE TRIM(NPN) 
  END AS NPN, 
  'URL' as ElectronicAddressCategoryTypeCode,
  'Business' AS ElectronicAddressTypeCode,
  CASE WHEN TRIM(BusinessWebsite) = '' OR BusinessWebsite IS NULL
    THEN '-' 
    ELSE TRIM(BusinessWebsite) 
  END AS ElectronicAddressText
  FROM ${WORK_DATABASE}.dim_work_agentdemographics WHERE scd_flag = true
  
  union all
  
  select 
  CASE WHEN TRIM(NPN) = '' OR NPN IS NULL
    THEN '-'
    ELSE TRIM(NPN)
  END AS NPN, 
  'URL' as ElectronicAddressCategoryTypeCode,
  'Alternate' AS ElectronicAddressTypeCode,
  CASE WHEN TRIM(AlternateWebsite) = '' OR AlternateWebsite IS NULL
    THEN '-'
    ELSE TRIM(AlternateWebsite) 
  END AS ElectronicAddressText
  FROM ${WORK_DATABASE}.dim_work_agentdemographics WHERE scd_flag = true

  union all
  
  select 
  CASE WHEN TRIM(NPN) = '' OR NPN IS NULL
    THEN '-'
    ELSE TRIM(NPN)
  END AS NPN, 
  'Email' as ElectronicAddressCategoryTypeCode,
  'Alternate' AS ElectronicAddressTypeCode,
  CASE WHEN TRIM(AlternateEmail) = '' OR AlternateEmail IS NULL
    THEN '-'
    ELSE TRIM(AlternateEmail) 
  END AS ElectronicAddressText
  FROM ${WORK_DATABASE}.dim_work_agentdemographics WHERE scd_flag = true
  
  union all
  
  select 
  CASE WHEN TRIM(NPN) = '' OR NPN IS NULL
    THEN '-'
    ELSE TRIM(NPN)
  END AS NPN, 
  'Email' as ElectronicAddressCategoryTypeCode,
  'Home' AS ElectronicAddressTypeCode,
  CASE WHEN TRIM(HomeEmail) = '' OR HomeEmail IS NULL
    THEN '-' 
    ELSE TRIM(HomeEmail)
  END AS ElectronicAddressText
  from ${WORK_DATABASE}.dim_work_agentdemographics WHERE scd_flag = true
) PEA
WHERE NPN <> '-';



-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PMCPartyElectronicAddress WHERE 1=0 LIMIT 1;




