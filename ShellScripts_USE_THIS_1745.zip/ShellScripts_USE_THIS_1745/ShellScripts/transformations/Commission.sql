set hive.support.quoted.identifiers=none;
-- 4x YARN min container size
set hive.tez.container.size=24576;
-- 1/3 of TEZ container
set hive.auto.convert.join.noconditionaltask.size=8192;
-- 40% of TEZ container
set tez.runtime.io.sort.mb=9830;
-- 10% of TEZ container
set tez.runtime.unordered.output.buffer.size-mb=2457;
-- 75% of the container size
set hive.tez.java.opts=-Xmx18432m -XX:NewRatio=8;
-- equal to container size
set tez.am.resource.memory.mb=6144;


INSERT OVERWRITE TABLE ${WORK_DATABASE}.Commission
SELECT
Commission.NPN as NPN,
Commission.DepositNumber as DepositNumber,
Commission.StatementDate as StatementDate,
Commission.StatementStartDate as StatementStartDate,
Commission.StatementEndDate as StatementEndDate,
Commission.InternalCompanyCode as InternalCompanyCode,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'VUE' as SourceSystemCode,
'N' as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetimestamp,
'0' as hashcode
FROM 
(
  SELECT 
  CASE
    WHEN TRIM(b.NPN)='' OR TRIM(b.NPN)=' ' OR TRIM(b.NPN) IS NULL
    THEN '-'
    ELSE TRIM(b.npn)
  END AS NPN,
  CASE
    WHEN TRIM(CAST(a.depositNumber AS STRING))='' OR TRIM(CAST(a.depositNumber AS STRING)) IS NULL THEN '-'
  ELSE TRIM(CAST(a.depositNumber AS STRING))
  END AS DepositNumber,
  COALESCE
  (
    CASE
    WHEN TRIM(a.fromdate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.fromdate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(a.fromdate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.fromdate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(a.fromdate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.fromdate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(a.fromdate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.fromdate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(a.fromdate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(a.fromdate),'MMddyyyy'), 'yyyy-MM-dd') AS DATE)
      ELSE CAST(TRIM(a.fromdate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS StatementStartDate,
  COALESCE
  (
    CASE
    WHEN TRIM(a.todate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.todate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(a.todate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.todate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(a.todate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.todate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(a.todate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.todate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(a.todate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(a.todate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(a.todate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS StatementEndDate,

  COALESCE
  (
    CASE
    WHEN TRIM(a.statementdate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.statementdate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(a.statementdate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.statementdate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(a.statementdate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.statementdate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(a.statementdate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(a.statementdate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(a.statementdate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(a.statementdate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(a.statementdate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS StatementDate,
  CASE
    WHEN TRIM(a.carriercode)=''
    THEN '-'
    WHEN TRIM(a.carriercode)=' '
    THEN '-'
    WHEN TRIM(a.carriercode) IS NULL
    THEN '-'
    ELSE TRIM(a.carriercode)
  END AS InternalCompanyCode
  FROM ${WORK_DATABASE}.dim_work_commissions a
  inner join ${WORK_DATABASE}.dim_work_agentdemographics b
  on TRIM(a.agentcode)=TRIM(b.agentcode)
  and a.scd_flag=true  and b.scd_flag=true
) Commission

WHERE NPN <> '-' AND StatementDate <> CAST('1900-01-01' AS DATE)  AND DepositNumber <> '-';
;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.Commission WHERE 1=0 LIMIT 1;



