INSERT OVERWRITE TABLE ${WORK_DATABASE}.MemberInsuranceAgreement
SELECT
MemberInsuranceAgreement.InsuranceAgreementNumber as InsuranceAgreementNumber,
MemberInsuranceAgreement.InternalCompanyCode as InternalCompanyCode,
MemberInsuranceAgreement.InsuranceAgreementTypeCode as InsuranceAgreementTypeCode,
MemberInsuranceAgreement.GroupInsuranceAgreementNumber as GroupInsuranceAgreementNumber,
MemberInsuranceAgreement.AccountNumber as AccountNumber,
MemberInsuranceAgreement.SourceGNLParticipantID as SourceGNLParticipantID,
MemberInsuranceAgreement.SourceGNLAccountNumber as SourceGNLAccountNumber,
'-' as MemberInsuranceAgreementTerminationReasonCode,
'-' as MemberInsuranceAgreementModificationReasonCode,
'-' as MemberClassificationName,
CURRENT_TIMESTAMP as LastUpdateDateTime,
MemberInsuranceAgreement.CurrentRecordInd as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
MemberInsuranceAgreement.LogicalDelIndicator as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetime,
"0" as hashcode
FROM(
select 
trim(COALESCE(concat_ws('-',COV.CVGRP,EMP.EECERT,SUBSTR(EESSN,-4)),'-')) as InsuranceAgreementNumber,
trim(coalesce(GRP.GCCMPC,'-')) as InternalCompanyCode,
trim(COALESCE(GRP.GCGRP,'-')) as AccountNumber,
max(coalesce(EMP.EESSN,'0000000000')) as SourceGNLParticipantID,
trim(COALESCE(GRP.GCGRP,'-')) as GroupInsuranceAgreementNumber,
max(COV.CVACCT) as SourceGNLAccountNumber,
-- new
MIN(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(CVIHCY AS INT) AS STRING),CAST(CAST(CVIHYR AS INT) AS STRING)),CAST(CAST(CVIHMT AS INT) AS STRING),CAST(CAST(CVIHDY AS INT) AS STRING)) AS DATE)) AS IssueDate,
MIN(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(CVEDCY AS INT) AS STRING),CAST(CAST(CVEDYR AS INT) AS STRING)),CAST(CAST(CVEDMT AS INT) AS STRING),CAST(CAST(CVEDDY AS INT) AS STRING)) AS DATE)) AS InsuranceAgreementEffectiveDate,
MAX(case when CVTDCY = 0 then CAST('9999-12-31' AS DATE) else CAST(CONCAT_WS('-',CONCAT(CAST(CAST(CVTDCY AS INT) AS STRING),CAST(CAST(CVTDYR AS INT) AS STRING)),CAST(CAST(CVTDMT AS INT) AS STRING),CAST(CAST(CVTDDY AS INT) AS STRING)) AS DATE) end) InsuranceAgreementEndDate,----- if 0/0/000 then 12-31-9999
MIN(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(CVIHCY AS INT) AS STRING),CAST(CAST(CVIHYR AS INT) AS STRING)),CAST(CAST(CVIHMT AS INT) AS STRING),CAST(CAST(CVIHDY AS INT) AS STRING)) AS DATE)) AS OriginalIssueDate,


'N' as LogicalDelIndicator,
'Y' as CurrentRecordInd,
'Individual Certificate' InsuranceAgreementTypeCode
from ${WORK_DATABASE}.dim_work_GRPCTRL GRP
inner join ${WORK_DATABASE}.dim_work_COVMSTR COV
on GRP.GCGRP = COV.CVGRP and GRP.scd_flag=true and COV.scd_flag=true and GRP.LogicalDel_ind='N' and COV.LogicalDel_ind='N'
INNER join ${WORK_DATABASE}.dim_work_EMPMSTR EMP
ON COV.CVGRP = EMP.EEGRP
AND COV.CVSSN = EMP.EESSN AND EMP.scd_flag=true and EMP.LogicalDel_ind='N'
where  EMP.EECERT<>'0000000000'
and COV.CVTDCY = 0
group by CVGRP, EECERT, GCCMPC, EMP.LogicalDel_ind, GCGRP, SUBSTR(EESSN,-4)
) MemberInsuranceAgreement;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.MemberInsuranceAgreement WHERE 1=0 LIMIT 1;