INSERT OVERWRITE TABLE ${WORK_DATABASE}.ProductCoverage
SELECT
'-' as EmployerPaidIndicator,
ProductCoverage.LineofBusiness as LineofBusinessCode,
'-' as ProductSeriesCode,
ProductCoverage.ProductCode as ProductCoverageCode,
ProductCoverage.ProductDescription as ProductCoverageDescription,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) as CreationTimestamp,
CAST(CAST('9999-12-31' AS DATE) AS TIMESTAMP) as EffectiveDate,
CAST(CAST('9999-12-31' AS DATE) AS TIMESTAMP) as EndDate,
'-' as DraftIndicator,
'-' as AuthorizedforAllStatesIndicator,
CASE WHEN LENGTH(ProductCoverage.InternalCompanyCode) < 1 THEN '-' ELSE ProductCoverage.InternalCompanyCode END AS InternalCompanyCode,
'-' as CoverageTypeCode,
0 as ProductSeriesVersionNumber,
0 as ProductSeriesID,
CURRENT_TIMESTAMP as LastUpdateDateTime,
ProductCoverage.CurrentRecordInd as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
ProductCoverage.LogicalDelIndicator as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetime,
"0" as hashcode
FROM
(
  SELECT trim(coalesce(CONCAT_WS('-', TRIM(PDGRP), TRIM(PDPRID)), '-')) as ProductCode,
  trim(coalesce(PDPDSC,'-')) as ProductDescription,
  trim(coalesce(PDLOBC,'-')) as LineofBusiness,
  trim(coalesce(PDCACD,'-')) as InternalCompanyCode,
  'N' as LogicalDelIndicator,
  'Y' CurrentRecordInd
  FROM ${WORK_DATABASE}.dim_work_PDTDEFN PDT
  WHERE PDT.scd_flag=true and PDT.LogicalDel_ind='N'
) ProductCoverage;

select * from ${WORK_DATABASE}.ProductCoverage where 1=0;



