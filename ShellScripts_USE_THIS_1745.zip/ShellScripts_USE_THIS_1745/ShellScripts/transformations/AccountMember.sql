INSERT OVERWRITE TABLE ${WORK_DATABASE}.AccountMember
SELECT
InternalCompanyCode,
AccountNumber AS MemberNumber,
0 AS EmployeeTotalWorkHoursPerWeek,
'-' AS EmployeeJobTitle,
0 AS EmployeeSalaryAmount,
COALESCE(GroupNumber, '-') AS GroupNumber, --Natural Key for DivisionalPArtyID
0 AS EmployeeTotalWorkDaysPerWeek,
'-' AS EmployeeStatusCode,
'-' AS MemberWorkTypeCode,
CAST(CAST('9999-12-31' AS DATE) AS TIMESTAMP) AS MemberEstablishedDate,
CAST('9999-12-31' AS DATE) AS MemberTerminationDate,
'-' AS MemberTerminationReasonCode,
'-' AS EmployeeDepartmentNumber,
'-' AS SmokerIndicator,
CAST(CAST('1900-01-01' AS DATE) AS TIMESTAMP) AS HireDate,
'-' AS EmployeeDepartmentName,
CurrentRecordInd AS CurrentRecordIndicator,
'Genelco' AS SourceSystemCode,
LogicalDelIndicator AS LogicalDeleteIndicator,
current_user() AS LastUpdateUserID,
current_timestamp AS LastUpdateDateTime,
current_timestamp AS hivelastupdatedatetime,
"0" as hashcode
FROM
(
  SELECT 
  TRIM(GCGRP) AS GroupNumber, ---AccountNumber
  TRIM(EESSN) AS AccountNumber, -----MemberNumber
  COALESCE(TRIM(GRP.GCCMPC), '-') AS InternalCompanyCode,
  GRP.LogicalDel_ind AS LogicalDelIndicator,
  'Y' AS CurrentRecordInd
  from ${WORK_DATABASE}.dim_work_GRPCTRL GRP
  inner join ${WORK_DATABASE}.dim_work_EMPMSTR EMP
  on GRP.GCGRP = EMP.EEGRP 
  AND GRP.scd_flag = true AND EMP.scd_flag = true
  AND GRP.LogicalDel_ind = 'N' AND EMP.LogicalDel_ind = 'N'
) TransformQuery;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.AccountMember WHERE 1=0 LIMIT 1;


