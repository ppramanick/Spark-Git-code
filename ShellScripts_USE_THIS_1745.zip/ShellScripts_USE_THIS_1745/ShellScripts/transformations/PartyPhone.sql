INSERT OVERWRITE TABLE ${WORK_DATABASE}.PartyPhone
SELECT 
CASE WHEN LENGTH(TRIM(PartyPhone.SourceGNLGROUPNUMBER)) < 1 THEN '-' ELSE COALESCE(PartyPhone.SourceGNLGROUPNUMBER, '-') END AS SourceGNLGROUPNUMBER, --Natural Keys
CASE WHEN LENGTH(TRIM(PartyPhone.SourceGNLAccountNumber)) < 1 THEN '-' ELSE COALESCE(PartyPhone.SourceGNLAccountNumber, 0) END AS SourceGNLAccountNumber,
PartyPhone.PhoneType,
'-' as PreferredPhoneTypeFlag,
CASE WHEN LENGTH(TRIM(PartyPhone.PhoneNumber)) < 1 THEN '-' ELSE COALESCE(TRIM(PartyPhone.PhoneNumber),'-') END as PhoneNumber,
'-' as PhoneExtension,
PartyPhone.CurrentRecordInd as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
PartyPhone.LogicalDelIndicator as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as LastUpdateDateTime,
current_timestamp as hivelastupdatetimestamp,
"0" as hashcode
FROM
(
  Select trim(SourceGNLGROUPNUMBER) as SourceGNLGROUPNUMBER,
  SourceGNLAccountNumber,
  trim(regexp_replace(PhoneNumber,"-","")) as PhoneNumber,
  trim(PhoneType) as PhoneType,
  LogicalDelIndicator,
  CurrentRecordInd
  From
  (
  select GCGRP as SourceGNLGROUPNUMBER,
  0 as SourceGNLAccountNumber,
  AM.A8TPTL as PhoneNumber,
  'Business' as PhoneType,
  AM.LogicalDel_ind as LogicalDelIndicator,
  case when AM.LogicalDel_ind = 'N' then 'Y' end as CurrentRecordInd,
--  max(CAST(concat_ws('-',concat(A1EDCY,SUBSTR(CONCAT('0',cast(A1EDYR as string)),-2)),SUBSTR(CONCAT('0',cast(A1EDMT as string)),-2),SUBSTR(CONCAT('0',cast(A1EDDY as string)),-2)) AS date)) as maxeffectivedate,
    MAX(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(A1EDCY AS INT) AS STRING),lpad(CAST(CAST(A1EDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(A1EDMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(A1EDDY AS INT) AS STRING),2,"0")) AS DATE)) AS maxeffectivedate,
  max(AR.A1SEQ3) as MaxSeq,
  RANK() OVER (PARTITION BY GRP.GCGRP ORDER BY AM.A8ADTM desc) as TimeRank 
  from ${WORK_DATABASE}.dim_work_GRPCTRL GRP
  inner join ${WORK_DATABASE}.dim_work_ADDRREL AR
  on GRP.GCGRP = AR.A1GRP
  and A1ACCT = 0 AND AR.LogicalDel_ind = 'N' AND GRP.LogicalDel_ind = 'N'
  inner join ${WORK_DATABASE}.dim_work_ADDRMSTR AM
  on AR.A1ADJD = AM.A8ADJD
  and AR.A1AEYR = AM.A8AEYR
  and AR.A1ADTM = AM.A8ADTM
  AND AR.LogicalDel_ind = 'N'
  AND A8ADD1 not like '%@%'
  and A8TPTL is not null
  and A8TPTL <> ' '
  and GRP.scd_flag=true and AR.scd_flag=true and AM.scd_flag=true
  AND AM.LogicalDel_ind = 'N'
  group by GRP.GCGRP, AM.A8TPTL, AM.LogicalDel_ind, AM.A8ADTM
  UNION ALL
  select GCGRP as SourceGNLGroupNumber,
  0 AS SourceGNLAccountNumber,
  AM.A8FXTL as PhoneNumber,
  'Fax' as PhoneType,
  AM.LogicalDel_ind as LogicalDelIndicator,
  case when AM.LogicalDel_ind = 'N' then 'Y' end as CurrentRecordInd,
  --max(CAST(concat_ws('-',concat(A1EDCY,SUBSTR(CONCAT('0',cast(A1EDYR as string)),-2)),SUBSTR(CONCAT('0',cast(A1EDMT as string)),-2),SUBSTR(CONCAT('0',cast(A1EDDY as string)),-2)) AS date)) as maxeffectivedate,
  MAX(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(A1EDCY AS INT) AS STRING),lpad(CAST(CAST(A1EDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(A1EDMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(A1EDDY AS INT) AS STRING),2,"0")) AS DATE)) AS maxeffectivedate,

  max(AR.A1SEQ3) as MaxSeq,
  RANK() OVER (PARTITION BY GRP.GCGRP ORDER BY AM.A8ADTM desc) as TimeRank
  From ${WORK_DATABASE}.dim_work_GRPCTRL GRP
  inner join ${WORK_DATABASE}.dim_work_ADDRREL AR
  on GRP.GCGRP = AR.A1GRP
  and A1ACCT = 0 AND GRP.LogicalDel_ind = 'N' AND AR.LogicalDel_ind = 'N'
  AND GRP.LogicalDel_ind = 'N' AND AR.LogicalDel_ind = 'N'
  inner join ${WORK_DATABASE}.dim_work_ADDRMSTR AM
  on AR.A1ADJD = AM.A8ADJD
  and AR.A1AEYR = AM.A8AEYR
  and AR.A1ADTM = AM.A8ADTM
  AND AM.LogicalDel_ind = 'N'
  AND A8ADD1 not like '%@%'
  and A8FXTL is not null
  and A8FXTL <> ' '
  and GRP.scd_flag=true and AR.scd_flag=true and AM.scd_flag=true
  group by GRP.GCGRP, AM.A8FXTL, AM.LogicalDel_ind, AM.A8ADTM
  union all
  select AMGRP as SourceGNLGroupNumber,
  AMACCT as SourceGNLAccountNumber,
  AM.A8TPTL as PhoneNumber,
  'Business' as PhoneType,
  AM.LogicalDel_ind as LogicalDelIndicator,
  case when AM.LogicalDel_ind = 'N' then 'Y' end as CurrentRecordInd,
  --max(CAST(concat_ws('-',concat(A1EDCY,SUBSTR(CONCAT('0',cast(A1EDYR as string)),-2)),SUBSTR(CONCAT('0',cast(A1EDMT as string)),-2),SUBSTR(CONCAT('0',cast(A1EDDY as string)),-2)) AS date)) as maxeffectivedate,
  MAX(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(A1EDCY AS INT) AS STRING),lpad(CAST(CAST(A1EDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(A1EDMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(A1EDDY AS INT) AS STRING),2,"0")) AS DATE)) AS maxeffectivedate,
  max(AR.A1SEQ3) as MaxSeq,
  RANK() OVER (PARTITION BY ACT.AMGRP,ACT.AMACCT  ORDER BY AM.A8ADTM desc) as TimeRank
  from ${WORK_DATABASE}.dim_work_ACTMSTR ACT
  inner join ${WORK_DATABASE}.dim_work_ADDRREL AR
  on ACT.AMGRP = AR.A1GRP
  and ACT.AMACCT = AR.A1ACCT
  and ACT.scd_flag=true and AR.scd_flag=true 
  AND ACT.LogicalDel_ind = 'N' AND AR.LogicalDel_ind = 'N'
  AND AMACCT <999
  inner join ${WORK_DATABASE}.dim_work_ADDRMSTR AM
  on AR.A1ADJD = AM.A8ADJD
  and AR.A1AEYR = AM.A8AEYR
  and AR.A1ADTM = AM.A8ADTM
  AND A8ADD1 like '%@%'
  and A8TPTL is not null
  and A8TPTL <> ' '
  AND AMACCT>=100
  and AM.scd_flag=true
  AND AM.LogicalDel_ind = 'N'
  group by ACT.AMGRP, ACT.AMACCT, AM.A8TPTL, AM.LogicalDel_ind, AM.A8ADTM
  UNION ALL
  select AMGRP as SourceGNLGroupNumber,
  AR.A1ACCT as SourceGNLAccountNumber,
  AM.A8FXTL as PhoneNumber,
  'Fax' as PhoneType,
  AM.LogicalDel_ind as LogicalDelIndicator,
  case when AM.LogicalDel_ind = 'N' then 'Y' end as CurrentRecordInd,
  --max(CAST(concat_ws('-',concat(A1EDCY,SUBSTR(CONCAT('0',cast(A1EDYR as string)),-2)),SUBSTR(CONCAT('0',cast(A1EDMT as string)),-2),SUBSTR(CONCAT('0',cast(A1EDDY as string)),-2)) AS date)) as maxeffectivedate,
  MAX(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(A1EDCY AS INT) AS STRING),lpad(CAST(CAST(A1EDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(A1EDMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(A1EDDY AS INT) AS STRING),2,"0")) AS DATE)) AS maxeffectivedate,
  max(AR.A1SEQ3) as MaxSeq,
  RANK() OVER (PARTITION BY ACT.AMGRP,AR.A1ACCT  ORDER BY AM.A8ADTM desc) as TimeRank
  from ${WORK_DATABASE}.dim_work_ACTMSTR ACT
  inner join ${WORK_DATABASE}.dim_work_ADDRREL AR
  on ACT.AMGRP = AR.A1GRP
  and ACT.AMACCT = AR.A1ACCT
  AND AMACCT <999
  AND ACT.LogicalDel_ind = 'N' AND AR.LogicalDel_ind = 'N'
  inner join ${WORK_DATABASE}.dim_work_ADDRMSTR AM
  on AR.A1ADJD = AM.A8ADJD
  and AR.A1AEYR = AM.A8AEYR
  and AR.A1ADTM = AM.A8ADTM
  AND A8ADD1 like '%@%'
  and trim(A8TPTL) is not null
  and A8TPTL <> ' '
  and ACT.scd_flag=true and AR.scd_flag=true and AM.scd_flag=true
  AND AM.LogicalDel_ind = 'N'
  group by ACT.AMGRP, AR.A1ACCT, AM.A8FXTL, AM.LogicalDel_ind, AM.A8ADTM
  ) Phone
  WHERE TimeRank = 1
) PartyPhone;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PartyPhone WHERE 1=0 LIMIT 1;