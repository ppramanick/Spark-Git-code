INSERT OVERWRITE TABLE ${WORK_DATABASE}.PMCPartyBankAccount
SELECT
PBC.NPN AS NPN,
COALESCE(PBC.BankRoutingNumber, 0) AS BankRoutingNumber,
COALESCE(PBC.BankAccountNumber, 0) AS BankAccountNumber,
COALESCE(PBC.BankName, '-') AS BankName,                                
COALESCE(PBC.BankAccountTypeCode, '-') AS BankAccountTypeCode,     
0 AS BankAccountSequenceNumber,    
'Y' AS CurrentRecordIndicator,   
'VUE' AS SourceSystemCode,         
'N' AS LogicalDeleteIndicator ,    
PBC.EFTFromDate AS EFTFromDate,          
PBC.EFTToDate AS EFTToDate,              
COALESCE(PBC.EFTAddressLine1,'-') AS  AddressLine1,          
COALESCE(PBC.EFTAddressLine2, '-') AS AddressLine2,          
'-' AS AddressLine3,             
COALESCE(PBC.AddressCityName, '-') AS AddressCityName,         
COALESCE(PBC.AddressPostalCode, '-') AS AddressPostalCode,      
COALESCE(PBC.StateCode,'-') AS StateCode,               
COALESCE(PBC.CountryCode, '-') AS CountryCode,
CURRENT_TIMESTAMP AS LastUpdateDateTime,     
CURRENT_USER() AS LastUpdateUserID,
CURRENT_TIMESTAMP AS hivelastupdatetimestamp,
'0' AS hashcode
FROM
(
  SELECT
  CASE WHEN TRIM(NPN) = '' OR TRIM(NPN) IS NULL
    THEN '-'
    ELSE TRIM(NPN)
  END AS NPN,
  CASE WHEN TRIM(RoutingNumber) = ''  OR TRIM(RoutingNumber) IS NULL
    THEN -1
    ELSE CAST(TRIM(RoutingNumber) AS INT)
  END AS BankRoutingNumber,
  CASE WHEN TRIM(AccountNumber) = ''  OR TRIM(AccountNumber) IS NULL
    THEN -1
    ELSE CAST(TRIM(AccountNumber) AS INT)
  END AS BankAccountNumber,
  CASE WHEN TRIM(BankName) = ''  OR TRIM(BankName) IS NULL
  THEN '-'
  ELSE TRIM(BankName)
  END AS BankName,
  CASE WHEN TRIM(AccountType) = ''  OR TRIM(AccountType) IS NULL
  THEN '-'
  ELSE TRIM(AccountType)
  END AS BankAccountTypeCode,
  COALESCE
  (
    CASE
    WHEN TRIM(FromDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FromDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(FromDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FromDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(FromDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FromDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(FromDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(FromDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(FromDate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(FromDate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(FromDate) AS DATE)
    END, 
    CAST('1900-01-01' AS DATE)
  ) AS EFTFromDate,
  COALESCE
  (
    CASE
    WHEN TRIM(ToDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(ToDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(ToDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(ToDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(ToDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(ToDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(ToDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(ToDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(ToDate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(ToDate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(ToDate) AS DATE)
    END, 
    CAST('1900-01-01' AS DATE)
  ) AS EFTToDate,
  CASE WHEN TRIM(AddressLine1) = ''  OR TRIM(AddressLine1) IS NULL
  THEN '-'
  ELSE TRIM(AddressLine1)
  END AS EFTAddressLine1,
  CASE WHEN TRIM(AddressLine2) = ''  OR TRIM(AddressLine2) IS NULL
  THEN '-'
  ELSE TRIM(AddressLine2)
  END AS EFTAddressLine2,
  CASE WHEN TRIM(City) = ''  OR TRIM(City) IS NULL
  THEN '-'
  ELSE TRIM(City)
  END AS AddressCityName,
  CASE WHEN TRIM(ZipCode) = ''  OR TRIM(ZipCode) IS NULL
  THEN '-'
  ELSE TRIM(ZipCode)
  END AS AddressPostalCode,
  CASE WHEN TRIM(State) = ''  OR TRIM(State) IS NULL
  THEN '-'
  ELSE TRIM(State)
  END AS StateCode,
  CASE WHEN TRIM(Country) = ''  OR TRIM(Country) IS NULL
  THEN '-'
  ELSE TRIM(Country)
  END AS CountryCode
  FROM ${WORK_DATABASE}.dim_work_agentdemographics
  WHERE scd_flag = true
) PBC
WHERE BankRoutingNumber <> -1
AND BankAccountNumber <> -1;


-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PMCPartyBankAccount WHERE 1=0 LIMIT 1;


