set hive.support.quoted.identifiers=none;
set hive.tez.container.size=16384;
set hive.tez.java.opts=-Xmx12288m -XX:NewRatio=8;
set tez.am.resource.memory.mb=6144;

INSERT OVERWRITE TABLE ${WORK_DATABASE}.DisbursementLine
SELECT
DisbursementLine.AccountLineNumber as AccountLineNumber,
DisbursementLine.DisbursementNumber as DisbursementNumber,
'-' as DisbursementLineDistributionTargetCode,
'-' as DisbursementReasonCode,
0 as DisbursementPartNumber, --Defaulted to 0, Checked with DAs
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
'N' as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
'-' as LastUpdateProcessID,
CURRENT_TIMESTAMP as RowInsertDateTime,
CURRENT_TIMESTAMP as RowUpdateDateTime,
CURRENT_TIMESTAMP as hivelastupdatetimestamp,
0 as hashcode
FROM (
select
trim(coalesce(concat_ws('-',cast(cast(PPJYR as int) as varchar(10)),cast(cast(PPJDAY as int) as varchar(10)),cast(cast(PPSEQ as int) as varchar(10)),trim(PPSUFX),cast(cast(PPPPNO as int) as varchar(10)),cast(cast(PPADJN as int) as varchar(10))),'-')) AS AccountLineNumber,
coalesce(concat(CASE WHEN LENGTH(Cast(PPJYR AS INT)) = 1 THEN concat('0',cast(Cast(PPJYR AS INT) as varchar(10))) ELSE cast(Cast(PPJYR AS INT) as varchar(10)) END, CASE WHEN LENGTH(Cast(PPJDAY AS INT)) = 1 THEN concat('00',cast(Cast(PPJDAY AS INT) as varchar(10))) WHEN LENGTH(Cast(PPJDAY AS INT))  = 2 THEN concat('0',cast(Cast(PPJDAY AS INT) as varchar(10))) ELSE cast(Cast(PPJDAY AS INT) as varchar(10)) END, CASE WHEN LENGTH(Cast(PPSEQ AS INT)) = 1  THEN concat('000',cast(Cast(PPSEQ AS INT) as varchar(10))) WHEN LENGTH(Cast(PPSEQ AS INT)) = 2 THEN concat('00',cast(Cast(PPSEQ AS INT) as varchar(10))) WHEN LENGTH(Cast(PPSEQ AS INT)) = 3 THEN concat('0',cast(Cast(PPSEQ AS INT) as varchar(10))) ELSE Cast(PPSEQ AS INT) END, trim(coalesce(PPSUFX,'')),cast(Cast(PPPPNO AS INT) as varchar(10)),cast(Cast(PPADJN AS INT) as varchar(10))),'-') AS DisbursementNumber
FROM ${WORK_DATABASE}.dim_work_PPHIST
WHERE scd_flag=true and LogicalDel_ind='N'
GROUP BY PPJYR,PPJDAY,PPSEQ,PPSUFX,PPPPNO,PPADJN -- Why do we need a group by ? DAs - It is done for removing duplicates
) DisbursementLine;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.Claim WHERE 1=0 LIMIT 1;