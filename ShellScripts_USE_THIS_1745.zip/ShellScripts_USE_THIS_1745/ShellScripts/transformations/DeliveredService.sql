INSERT OVERWRITE TABLE ${WORK_DATABASE}.DeliveredService
SELECT 
-1 as BeneficiaryPartyID,
-1 as ProductCoverageID,
DeliveredService.DeliveredServiceName as DeliveredServiceName,
DeliveredService.ClaimNumber as ClaimNumber,
DeliveredService.LossName as LossName,
DeliveredService.SourceGNLGroupNumber as SourceGNLGroupNumber,
DeliveredService.SourceGNLParticipantID as SourceGNLParticipantID,
DeliveredService.SourceGNLDependentSequenceNumber as SourceGNLDependentSequenceNumber,
DeliveredService.Internalcompanycode as Internalcompanycode,
'Individual Certificate' as InsuranceAgreementTypeCode,
DeliveredService.InsuranceAgreementNumber as InsuranceAgreementNumber,
'-' as LossProcedureCode,
'-' as DeliveredServiceCanceledFlag,
'-' as DeliveredServiceReasonCode,
'-' as DeliveredServiceTypeCode,
'1900-01-01' as MemberInsuranceAgreementCoverageEffectiveDate,
'1900-01-01' as DeliveredServiceDate,
'-' as DeliveredServiceDecisionReasonCode,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
'N' as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetimestamp,
0 as hashcode
FROM (
SELECT
trim(coalesce(concat_ws('-',cast(cast(BLPPNO as int) as varchar(10)),cast(cast(BLADJN as int) as varchar(10)),cast(cast(BLBNLN as int) as varchar(10)),CASE WHEN BZDESP > ' ' THEN BZDESP ELSE BZBDSC END),'-')) AS DeliveredServiceName,
trim(coalesce(BLCDSC,'-')) as LOSSNAME,
trim(coalesce(concat(CASE WHEN LENGTH(Cast(CSJYR AS INT)) = 1 THEN concat('0',cast(Cast(CSJYR AS INT) as varchar(10))) ELSE cast(Cast(CSJYR AS INT) as varchar(10)) END, CASE WHEN LENGTH(Cast(CSJDAY AS INT)) = 1 THEN concat('00',cast(Cast(CSJDAY AS INT) as varchar(10))) WHEN LENGTH(Cast(CSJDAY AS INT))  = 2 THEN concat('0',cast(Cast(CSJDAY AS INT) as varchar(10))) ELSE cast(Cast(CSJDAY AS INT) as varchar(10)) END, CASE WHEN LENGTH(Cast(CSSEQ AS INT)) = 1  THEN concat('000',cast(Cast(CSSEQ AS INT) as varchar(10))) WHEN LENGTH(Cast(CSSEQ AS INT)) = 2 THEN concat('00',cast(Cast(CSSEQ AS INT) as varchar(10))) WHEN LENGTH(Cast(CSSEQ AS INT)) = 3 THEN concat('0',cast(Cast(CSSEQ AS INT) as varchar(10))) ELSE Cast(CSSEQ AS INT) END, Cast(TRIM(CSSUFX) AS VARCHAR(10))),'-')) AS ClaimNumber,
trim(coalesce(GCGRP,'-')) AS SourceGNLGroupNumber,
trim(coalesce(E.EESSN,'0000000000')) AS SourceGNLParticipantID,
coalesce(cast(BLDSEQ as int),0) AS SourceGNLDependentSequenceNumber,
trim(coalesce(GCCMPC,'-')) as InternalCompanyCode,
concat_ws('-',GCGRP,E.EECERT,SUBSTR(E.EESSN,-4)) as InsuranceAgreementNumber
FROM ${WORK_DATABASE}.dim_work_BLHIST A
INNER JOIN ${WORK_DATABASE}.dim_work_CSRMSTR B 
ON A.BLJDAY = b.CSJDAY AND A.BLJYR = B.CSJYR AND A.BLSEQ = B.CSSEQ AND A.BLSUFX = B.CSSUFX AND A.scd_flag=true and A.LogicalDel_ind='N' AND B.scd_flag=true and B.LogicalDel_ind='N'
INNER JOIN ${WORK_DATABASE}.dim_work_GRPCTRL C ON A.BLGRP = C.GCGRP AND C.scd_flag=true and C.LogicalDel_ind='N'
INNER JOIN ${WORK_DATABASE}.dim_work_EMPMSTR E ON A.BLGRP = E.EEGRP AND A.BLSSN = E.EESSN AND E.scd_flag=true and E.LogicalDel_ind='N'
INNER JOIN ${WORK_DATABASE}.dim_work_BNFTTBL D ON A.BLCCAT = D.BZCCAT AND D.scd_flag=true and D.LogicalDel_ind='N'
) DeliveredService;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.CoveragePlan WHERE 1=0 LIMIT 1;