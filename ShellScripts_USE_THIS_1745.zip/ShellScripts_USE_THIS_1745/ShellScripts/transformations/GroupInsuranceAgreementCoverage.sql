INSERT OVERWRITE TABLE ${WORK_DATABASE}.GroupInsuranceAgreementCoverage
SELECT
GroupInsuranceAgreementCoverage.InsuranceAgreementTypeCode as InsuranceAgreementTypeCode,
GroupInsuranceAgreementCoverage.InternalCompanyCode as InternalCompanyCode,
GroupInsuranceAgreementCoverage.AccountNumber as AccountNumber,
GroupInsuranceAgreementCoverage.InsuranceAgreementNumber as InsuranceAgreementNumber,
GroupInsuranceAgreementCoverage.ProductCode as ProductCode,
CAST(GroupInsuranceAgreementCoverage.GroupInsuranceAgreementCoverageEffectiveDate AS TIMESTAMP) as GroupInsuranceAgreementCoverageEffectiveDate,
CAST(CAST('9999-12-31' AS DATE) AS TIMESTAMP) as GroupInsuranceAgreementCoverageEndDate,
'-' as GroupInsuranceAgreementCoverageStatusCode,
'-' as GroupInsuranceAgreementCoverageTerminationReasonCode,
0.00 as MinimumParticipationRequiredPercentage,
0 as ActualParticipationCount, 
0 as CurrentParticipationCount, 
'-' as ParticipationStatusCode,
'-' as CoveredPartySetTypeCode,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
'N' as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetimestamp,
'0' as hashcode
FROM (
select trim(coalesce(PDGRP,'-')) as InsuranceAgreementNumber,
trim(coalesce(PDGRP,'-')) as AccountNumber,
trim(coalesce(GRP.GCCMPC,'-')) as InternalCompanyCode,
trim(coalesce(CONCAT_WS('-', TRIM(PDGRP), TRIM(PDPRID)), '-')) as ProductCode,
PM.PMCEDT as ComplimentaryEffectiveDate,
CASE WHEN PMEDCY = 0 OR PMEDYR = 0 OR PMEDMT = 0 OR PMEDDY= 0 THEN cast('1900-01-01' as DATE) ELSE CAST(CONCAT_WS('-',CONCAT(CAST(CAST(PMEDCY AS INT) AS STRING),lpad(CAST(CAST(PMEDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(PMEDMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(PMEDDY AS INT) AS STRING),2,"0")) AS DATE) END AS GroupInsuranceAgreementCoverageEffectiveDate,
'Group Certificate' as InsuranceAgreementTypeCode
from ${WORK_DATABASE}.dim_work_GRPCTRL GRP
inner join ${WORK_DATABASE}.dim_work_PDTDEFN PDT
on GRP.GCGRP = PDT.PDGRP and GRP.scd_flag=true and PDT.scd_flag=true and PDT.LogicalDel_ind='N' and GRP.LogicalDel_ind='N'
inner join ${WORK_DATABASE}.dim_work_PDTMSTR PM
ON PM.PMGRP = PDT.PDGRP
AND PM.PMPRID = PDT.PDPRID
AND PM.PMCEDT = PDT.PDCEDT and PM.scd_flag=true and PM.LogicalDel_ind='N'
) GroupInsuranceAgreementCoverage;


-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.GroupInsuranceAgreementCoverage WHERE 1=0 LIMIT 1;