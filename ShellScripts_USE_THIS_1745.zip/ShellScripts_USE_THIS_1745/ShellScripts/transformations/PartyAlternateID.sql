INSERT OVERWRITE TABLE ${WORK_DATABASE}.PartyAlternateID
SELECT --Mapping --PartyID Not Part of Datalake but we've columns to produce this field from Party
COALESCE(PartyAlternateID.SourceGNLAccountNumber, 0) AS SourceGNLAccountNumber,
CASE WHEN LENGTH(TRIM(PartyAlternateID.SourceGNLParticipantID)) < 1 THEN '-' ELSE COALESCE(PartyAlternateID.SourceGNLParticipantID, '-') END AS SourceGNLParticipantID,
CASE WHEN LENGTH(TRIM(PartyAlternateID.SourceGNLDependentSequenceNumber)) < 1 THEN '-' ELSE COALESCE(PartyAlternateID.SourceGNLDependentSequenceNumber, '-') END AS SourceGNLDependentSequenceNumber,
CASE WHEN LENGTH(TRIM(PartyAlternateID.GroupNumber)) < 1 THEN '-' ELSE COALESCE(PartyAlternateID.GroupNumber, '-') END AS SourceGNLGroupNumber,
CASE WHEN LENGTH(TRIM(PartyAlternateIDType)) < 1 THEN '-' ELSE COALESCE(TRIM(PartyAlternateIDType), '-') END AS PartyAlternateIDTypeCode,
CASE WHEN LENGTH(TRIM(PartyAlternateIDValue)) < 1 THEN '-' ELSE COALESCE(TRIM(PartyAlternateIDValue), '-') END AS PartyAlternateIDValue,
PartyAlternateID.CurrentRecordIndicator,
'Genelco' AS SourceSystemCode,
PartyAlternateID.LogicalDeleteIndicator,
current_user() AS LastUpdateUserID,
current_timestamp AS LastUpdateDateTime,
current_timestamp AS hivelastupdatetimestamp,
"0" as hashcode
FROM
(--Transformation Query
  SELECT
  GroupNumber,
  SourceGNLParticipantID,
  0 AS SourceGNLAccountnumber,
  PartyALternateIDValue,
  SourceGNLDependentSeq AS SourceGNLDependentSequenceNumber,
  PartyAlternateIDType,
  LogicalDelIndicator AS LogicalDeleteIndicator,
  CurrentRecordInd AS CurrentRecordIndicator
  FROM
  (
    SELECT GCGRP AS GroupNumber,
    EESSN AS SourceGNLParticipantID,
    EESSN AS PartyALternateIDValue,
    'SSN' AS PartyAlternateIDType,
    0 AS SourceGNLDependentSeq,
    EMP.LogicalDel_ind AS LogicalDelIndicator,
    case when EMP.LogicalDel_ind = 'N' then 'Y' end AS CurrentRecordInd
    FROM ${WORK_DATABASE}.dim_work_grpctrl GRP
    INNER JOIN ${WORK_DATABASE}.dim_work_empmstr EMP
    ON GRP.GCGRP = EMP.EEGRP
    AND GRP.scd_flag = true AND EMP.scd_flag=true
    AND GRP.LogicalDel_ind = 'N' AND EMP.LogicalDel_ind = 'N'
    UNION ALL
    SELECT GCGRP AS GroupNumber,
    DESSN AS SourceGNLParticipantID,
    DEDSSN AS PartyALternateIDValue,
    'SSN' AS PartyAlternateIDType,
    DEP.DEDSEQ AS SourceGNLDependentSeq,
    DEP.LogicalDel_ind AS LogicalDelIndicator,
    case when DEP.LogicalDel_ind = 'N' then 'Y' end AS CurrentRecordInd
    FROM ${WORK_DATABASE}.dim_work_grpctrl GRP
    INNER JOIN ${WORK_DATABASE}.dim_work_depmstr DEP
    ON GRP.GCGRP = DEP.DEGRP
    AND GRP.scd_flag = true AND DEP.scd_flag=true
    AND DEDSSN > '001000000'
    and DESSN<>DEDSSN -----dedssn >0010000000
    AND DEP.LogicalDel_ind = 'N' AND GRP.LogicalDel_ind = 'N'
  ) SSNQuery

  UNION ALL
  --------------TAXID--------------
  Select SourceGNLGroupNumber,
  SourceGNLParticipantID,
  SourceGNLAccountnumber,
  0 AS SourceGNLDependentSeq,
  ParytAlternateIDValue,
  PartyAlternateIDType,
  LogicalDelIndicator,
  CurrentRecordInd
  FROM
  (
    SELECT GCGRP AS SourceGNLGroupNumber, ----accountlevel
    AR.A1SSN AS SourceGNLParticipantID,
    AR.A1ACCT AS SourceGNLAccountnumber,
    AR.A1SSN AS ParytAlternateIDValue,
    'TaxID' AS PartyAlternateIDType,
    AM.LogicalDel_ind AS LogicalDelIndicator,
    case when AM.LogicalDel_ind = 'N' then 'Y' else 'N' end AS CurrentRecordInd,
    --MAX(CAST(CONCAT_WS(CONCAT(TRIM(CAST(A1EDCY AS STRING)),TRIM(CAST(A1EDYR AS STRING))),TRIM(CAST(A1EDMT AS STRING)),TRIM(CAST(A1EDDY AS STRING)), '/') AS DATE)) AS maxeffectivedate,
    MAX(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(A1EDCY AS INT) AS STRING),lpad(CAST(CAST(A1EDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(A1EDMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(A1EDDY AS INT) AS STRING),2,"0")) AS DATE)) AS maxeffectivedate,
    max(AR.A1SEQ3) AS MaxSeq,
    RANK() OVER (PARTITION BY GRP.GCGRP, AR.A1SSN, AR.A1ACCT ORDER BY AM.A8ADTM desc) AS TimeRank
    FROM
    ${WORK_DATABASE}.dim_work_grpctrl GRP
    inner join ${WORK_DATABASE}.dim_work_addrrel AR
    on GRP.GCGRP = AR.A1GRP AND AR.scd_flag = true AND GRP.scd_flag = true
    and A1ACCT = 0 -----groupaccount level addresses - party for groups
    AND AR.LogicalDel_ind = 'N' AND GRP.LogicalDel_ind = 'N'
    AND GRP.LogicalDel_ind = 'N' AND AR.LogicalDel_ind = 'N'
    inner join ${WORK_DATABASE}.dim_work_addrmstr AM
    on AR.A1ADJD = AM.A8ADJD
    and AR.A1AEYR = AM.A8AEYR
    and AR.A1ADTM = AM.A8ADTM
    AND AM.scd_flag = true
    AND A8ADD1 like '%@%'
    AND AM.LogicalDel_ind = 'N'
    group by GCGRP, AR.A1SSN, AR.A1ACCT, AM.LogicalDel_ind, AM.A8ADTM
    --and A1SSN <> '0000000000'
    union All
    select AMGRP AS SourceGNLGroupNumber, ----subaccountlevel
    AR.A1SSN AS SourceGNLParticipantID,
    ACT.AMACCT AS SourceGNLAcctnumber,
    AR.A1SSN AS ParytAlternateIDValue,
    'TaxID' AS PartyAlternateIDType,
    AM.LogicalDel_ind AS LogicalDelIndicator,
    case when AM.LogicalDel_ind = 'N' then 'Y' ELSE 'N' end AS CurrentRecordInd,
    --MAX(CAST(CONCAT_WS(CONCAT(TRIM(CAST(A1EDCY AS STRING)),TRIM(CAST(A1EDYR AS STRING))),TRIM(CAST(A1EDMT AS STRING)),TRIM(CAST(A1EDDY AS STRING)), '/') AS DATE)) AS maxeffectivedate,
    MAX(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(A1EDCY AS INT) AS STRING),lpad(CAST(CAST(A1EDYR AS INT) AS STRING),2,"0")),lpad(CAST(CAST(A1EDMT AS INT) AS STRING),2,"0"),lpad(CAST(CAST(A1EDDY AS INT) AS STRING),2,"0")) AS DATE)) AS maxeffectivedate,

    MAX(AR.A1SEQ3) AS MaxSeq,
    RANK() OVER (PARTITION BY ACT.AMGRP, AR.A1SSN, ACT.AMACCT ORDER BY AM.A8ADTM desc) AS TimeRank
    FROM
    ${WORK_DATABASE}.dim_work_actmstr ACT
    inner join ${WORK_DATABASE}.dim_work_addrrel AR
    on ACT.AMGRP = AR.A1GRP
    and ACT.AMACCT = AR.A1ACCT  ------subaccount level addresses
    AND ACT.scd_flag = true AND AR.scd_flag = true
    AND ACT.LogicalDel_ind = 'N' AND AR.LogicalDel_ind = 'N'
    inner join ${WORK_DATABASE}.dim_work_addrmstr AM
    on AR.A1ADJD = AM.A8ADJD
    and AR.A1AEYR = AM.A8AEYR
    and AR.A1ADTM = AM.A8ADTM
    AND AM.scd_flag = true
    AND A8ADD1 like '%@%'
    and A1ACCT not BETWEEN 1 and 99
    AND AM.LogicalDel_ind = 'N'
    group by AMGRP, A1SSN, AMACCT, AM.LogicalDel_ind, AM.A8ADTM
    --and A1SSN <> '0000000000'
  ) PartyElectronicAddress
  where TimeRank = 1
) PartyAlternateID;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PartyAlternateID WHERE 1=0 LIMIT 1;

