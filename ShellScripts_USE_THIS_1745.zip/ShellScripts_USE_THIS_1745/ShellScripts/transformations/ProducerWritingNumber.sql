INSERT OVERWRITE TABLE ${WORK_DATABASE}.ProducerWritingNumber
SELECT
PWN.ProducerWritingNumber,
PWN.InternalCompanyCode,
PWN.NPN,
PWN.ProducerWritingNumberEffectiveDate,
PWN.EndDate,
'-' as AssociateStatusCode,
cast('9999-12-31 23:59:59.000000' as timestamp) as LastProductionDate,
'-' as BrokerExceptionFlag,
0 as ProducerMaximumLevelNumber,
PWN.VestedFlag,
'-' as PartnerIndicator,
'-' as ProducerTenureCode,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'VUE' as SourceSystemCode,
'N' as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetimestamp,
'0' as hashcode
FROM
(
  SELECT 
  CASE WHEN TRIM(a.writingnumber)='' THEN '-'
    WHEN TRIM(a.writingnumber) IS NULL THEN '-'
    ELSE TRIM(a.writingnumber)
  END AS ProducerWritingNumber,
  CASE WHEN TRIM(a.carriercode)='' 
    THEN '-'
    WHEN TRIM(a.carriercode) IS NULL THEN '-'
    ELSE TRIM(a.carriercode)
  END AS InternalCompanyCode,
  CASE WHEN TRIM(b.NPN)='' 
    THEN '-'
    WHEN TRIM(b.NPN)=' '
    THEN '-'
    WHEN TRIM(b.NPN) IS NULL 
    THEN '-'
    ELSE TRIM(b.npn)
  END AS NPN,
  COALESCE
  (
    CASE
    WHEN TRIM(c.ContractStartDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.ContractStartDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(c.ContractStartDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.ContractStartDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(c.ContractStartDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.ContractStartDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(c.ContractStartDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.ContractStartDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)   
      WHEN TRIM(c.ContractStartDate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(c.ContractStartDate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(c.ContractStartDate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS ProducerWritingNumberEffectiveDate,
  COALESCE
  (
    CASE
    WHEN TRIM(c.ContractEndDate) rlike '[0-9]{1}/[0-9]{1}/[0-9]{4}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.ContractEndDate), 'd/M/yyyy'), 'yyyy-MM-dd') AS DATE) 
      WHEN TRIM(c.ContractEndDate) rlike '[0-9]{2}/[0-9]{2}/[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.ContractEndDate), 'yy/MM/dd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(c.ContractEndDate) rlike '[0-9]{2}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.ContractEndDate), 'yyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(c.ContractEndDate) rlike '[0-9]{4}[0-9]{2}[0-9]{2}'
      THEN CAST(from_unixtime(unix_timestamp(TRIM(c.ContractEndDate), 'yyyyMMdd'), 'yyyy-MM-dd') AS DATE)
      WHEN TRIM(c.ContractEndDate) rlike '[0-9]{2}[0-9]{2}[0-9]{4}'
      THEN cast(from_unixtime(unix_timestamp(TRIM(c.ContractEndDate),'MMddyyyy'), 'yyyy-MM-dd') as DATE)
      ELSE CAST(TRIM(c.ContractEndDate) AS DATE)
    END, CAST('1900-01-01' AS DATE)
  ) AS EndDate,
  trim(coalesce(b.IsVested,'-')) as VestedFlag
  FROM ${WORK_DATABASE}.dim_work_commissions a
  inner join ${WORK_DATABASE}.dim_work_agentdemographics b
  on TRIM(a.AgentCode) = TRIM(b.AgentCode) 
  and a.scd_flag=true and b.scd_flag=true
  inner join ${WORK_DATABASE}.dim_work_agentarrangements c
  on TRIM(a.agentcode) = CONCAT('AA',TRIM(c.AgentCode)) and c.scd_flag=true
) PWN
WHERE PWN.ProducerWritingNumber <> '-';



-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.ProducerWritingNumber WHERE 1=0 LIMIT 1;

