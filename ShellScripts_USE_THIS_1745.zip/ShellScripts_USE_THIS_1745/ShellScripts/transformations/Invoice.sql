INSERT OVERWRITE TABLE ${WORK_DATABASE}.Invoice
SELECT
Invoice.InvoiceNumber as InvoiceNumber,
'1900-01-01 00:00:00' as InvoiceEffectiveDate,
Invoice.InvoiceDueDate as InvoiceDueDate,
Invoice.InvoiceDueAmount as InvoiceDueAmount,
Invoice.InvoiceCreationDate as InvoiceCreationDate,
'1900-01-01 00:00:00' as InvoiceScheduleDate,
'-' as InvoiceCancelledFlag,
'1900-01-01 00:00:00' as InvoiceCancellationDate, -- confirmed with Pooja, 10/16
'-' as InvoiceCurrencyCode,
Invoice.InvoiceAmount as InvoiceAmount,
'-' as InvoiceCreditAppliedFlag,
'-' as InvoiceStatusCode,
CURRENT_TIMESTAMP as LastUpdateDateTime,
'Y' as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
'N' as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetime,
"0" as hashcode
FROM(
SELECT 
trim(coalesce(trim(P7INVN),'-')) AS InvoiceNumber,
cast(coalesce(concat_ws('-',concat(cast(P7BGCY as int),SUBSTR(CONCAT('0',cast(cast(P7BGYR as int) as varchar(2))),-2)),SUBSTR(CONCAT('0',cast(cast(P7BGMT as int) as varchar(4))),-2),SUBSTR(CONCAT('0',cast(cast(P7BGDY as int) as varchar(4))),-2)),'1900-01-01') as date) AS InvoiceDueDate,
cast(coalesce(concat_ws('-',concat(cast(P7RDCY as int),SUBSTR(CONCAT('0',cast(cast(P7RDYR as int) as varchar(2))),-2)),SUBSTR(CONCAT('0',cast(cast(P7RDMT as int) as varchar(4))),-2),SUBSTR(CONCAT('0',cast(cast(P7RDDY as int) as varchar(4))),-2)),'1900-01-01') as date) AS InvoiceCreationDate,
coalesce(P7TTPC,0.00) AS InvoiceAmount,
coalesce(P7TTPD,0.00) AS InvoiceDueAmount
FROM ${WORK_DATABASE}.dim_work_PBSUMM
WHERE P7ACCT >= 100 AND P7INVN > ' '
and P7SSN = '0000000000' and scd_flag=true and LogicalDel_ind='N' and P7INVN IS NOT NULL and trim(P7INVN) <> ''
) Invoice;

-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.Invoice WHERE 1=0 LIMIT 1;


