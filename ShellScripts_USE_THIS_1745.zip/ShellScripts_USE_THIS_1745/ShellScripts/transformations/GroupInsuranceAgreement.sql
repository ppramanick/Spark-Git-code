INSERT OVERWRITE TABLE ${WORK_DATABASE}.GroupInsuranceAgreement
SELECT
GroupInsuranceAgreement.AccountNumber as AccountNumber,
GroupInsuranceAgreement.InsuranceAgreementNumber as InsuranceAgreementNumber,
GroupInsuranceAgreement.InternalCompanyCode as InternalCompanyCode,
GroupInsuranceAgreement.InsuranceAgreementTypeCode as GroupInsuranceAgreementInsuranceAgreementTypeCode,
0 as EligibleEmployeeCount,
0 as TotalEmployeeCount,
0 as IssuedParticipantCount,
0 as RequiredEmployeeParticipationPercentage,
'-' as GroupInsuranceAgreementTerminationReasonCode,
'-' as GroupInsuranceAgreementModificationReasonCode,
0 as MaximumMonthsInvestigateandDenyClaimCount,
CURRENT_TIMESTAMP as LastUpdateDateTime,
GroupInsuranceAgreement.CurrentRecordInd as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
GroupInsuranceAgreement.LogicalDel_ind as LogicalDeleteIndicator, 
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetime,
"0" as hashcode
FROM
(select 
trim(coalesce(GRP.GCGRP,'-')) as AccountNumber,
trim(coalesce(GRP.GCGRP,'-')) as InsuranceAgreementNumber, 
trim(coalesce(GRP.GCCMPC,'-')) as InternalCompanyCode,
--min(CAST(concat_ws('-',concat(PDEFCY,SUBSTR(CONCAT('0',cast(PDEFYR as string)),-2)),SUBSTR(CONCAT('0',cast(PDEFMT as string)),-2),SUBSTR(CONCAT('0',cast(PDEFDY as string)),-2)) AS date)) as IssueDate,
--min(CAST(concat_ws('-',concat(PDEDCY,SUBSTR(CONCAT('0',cast(PDEDYR as string)),-2)),SUBSTR(CONCAT('0',cast(PDEDMT as string)),-2),SUBSTR(CONCAT('0',cast(PDEDDY as string)),-2)) AS date)) as InsuranceAgreementEffectiveDate,
--max(
--case when PDEDCY = 0
--then cast('9999-12-31' as date)
--else CAST(concat_ws('-',concat(PDEDCY,SUBSTR(CONCAT('0',cast(PDEDYR as string)),-2)),SUBSTR(CONCAT('0',cast(PDEDMT as string)),-2),SUBSTR(CONCAT('0',cast(PDEDDY as string)),-2)) AS date) end) as InsuranceAgreementEndDate,
--min(case when PDEDCY = 0 then cast('9999-12-31' as date) else CAST(concat_ws('-',concat(PDEFCY,SUBSTR(CONCAT('0',cast(PDEFYR as string)),-2)),SUBSTR(CONCAT('0',cast(PDEFMT as string)),-2),SUBSTR(CONCAT('0',cast(PDEFDY as string)),-2)) AS date) end) as OriginalIssueDate,
--
MIN(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(PDEFCY AS INT) AS STRING),CAST(CAST(PDEFYR AS INT) AS STRING)),CAST(CAST(PDEFMT AS INT) AS STRING),CAST(CAST(PDEFDY AS INT) AS STRING)) AS DATE)) AS IssueDate,
MIN(CAST(CONCAT_WS('-',CONCAT(CAST(CAST(PDEDCY AS INT) AS STRING),CAST(CAST(PDEDYR AS INT) AS STRING)),CAST(CAST(PDEDMT AS INT) AS STRING),CAST(CAST(PDEDDY AS INT) AS STRING)) AS DATE)) AS InsuranceAgreementEffectiveDate,
max(
case when PDEDCY = 0
then CAST('9999-12-31' as DATE)
else CAST(CONCAT_WS('-',CONCAT(CAST(CAST(PDEDCY AS INT) AS STRING),CAST(CAST(PDEDYR AS INT) AS STRING)),CAST(CAST(PDEDMT AS INT) AS STRING),CAST(CAST(PDEDDY AS INT) AS STRING)) AS DATE) end) as InsuranceAgreementEndDate,
min(
case when PDEDCY = 0
then CAST('9999-12-31' as DATE)
else CAST(CONCAT_WS('-',CONCAT(CAST(CAST(PDEFCY AS INT) AS STRING),CAST(CAST(PDEFYR AS INT) AS STRING)),CAST(CAST(PDEFMT AS INT) AS STRING),CAST(CAST(PDEDDY AS INT) AS STRING)) AS DATE) end) as OriginalIssueDate,--
'N' as LogicalDel_ind,
'Y' as CurrentRecordInd,
'Group Certificate' as InsuranceAgreementTypeCode
from ${WORK_DATABASE}.dim_work_GRPCTRL GRP
inner join ${WORK_DATABASE}.dim_work_PDTDEFN PDT
on GRP.GCGRP = PDT.PDGRP and GRP.scd_flag=true and PDT.scd_flag=true and GRP.LogicalDel_ind='N' and PDT.LogicalDel_ind='N'
group by GRP.GCGRP, GRP.GCCMPC
) GroupInsuranceAgreement;



-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.GroupInsuranceAgreement WHERE 1=0 LIMIT 1;

