INSERT OVERWRITE TABLE ${WORK_DATABASE}.PaymentLine
SELECT
PaymentLine.AccountLineNumber as AccountLineNumber,
PaymentLine.PaymentNumber as PaymentNumber,
PaymentLine.AccountLineType as AccountLineType,
PaymentLine.AccountLineAmount as AccountLineAmount,
CURRENT_TIMESTAMP as LastUpdateDateTime,
PaymentLine.CurrentRecordInd as CurrentRecordIndicator,
'Genelco' as SourceSystemCode,
PaymentLine.LogicalDel_ind as LogicalDeleteIndicator,
CURRENT_USER() as LastUpdateUserID,
CURRENT_TIMESTAMP as hivelastupdatetime,
"0" as hashcode
FROM
(
  SELECT
  TRIM(CONCAT_WS('-',
    TRIM(B2BATI),
    TRIM(PAGRP),
    CAST(CAST(PAACCT AS INT) as STRING),
    TRIM(PASSN),
    CAST(CAST(PADSEQ AS INT) as STRING),
    CAST(CAST(PACBMD AS INT) as STRING),
    TRIM(PAPRID),
    TRIM(PATYOC),
    CAST(CAST(PAFMSQ AS INT) AS STRING),
    CONCAT(CAST(CAST(PAWSCY AS INT) AS STRING),CAST(CAST(PAWSYR AS INT) AS STRING),CAST(CAST(PAWSMT AS INT) AS STRING),CAST(CAST(PAWSDY AS INT) AS STRING)),
    CAST(CAST(PATRLN AS INT) AS STRING)
  )) AS AccountlineNumber,
  'Payment' as AccountLineType,
  PAAPAM as AccountLineAmount,
  CASE WHEN B2BATI is null OR TRIM(B2BATI) = '' THEN '-' ELSE TRIM(PABATI) END AS PaymentNumber,
  'N' as LogicalDel_ind,
  'Y' as CurrentRecordInd
  FROM ${WORK_DATABASE}.dim_work_PAYHIST a 
  INNER JOIN ${WORK_DATABASE}.dim_work_BTCTL b 
  on a.PAACCT = b.B2ACCT AND a.PAGRP = b.B2GRP AND a.PASSN =  b.B2SSN
  AND PAACCT >= 100 and a.LogicalDel_ind = 'N' and a.scd_flag=true
  AND b.LogicalDel_ind = 'N' and b.scd_flag=true
) PaymentLine;


-- Mitigates Beeline Bug
SELECT * FROM ${WORK_DATABASE}.PaymentLine WHERE 1=0 LIMIT 1;

