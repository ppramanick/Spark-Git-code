#!/bin/bash

auditSetIncrementalLoadCdcRow(){
  col=$1
  val=$2
  prepareRow "GENELCO" ${col} ${val} ${HIVE_TABLE} ${AUDIT_TABLE}
}

LIB="../lib/SharedFunctions.sh"
AUDIT_LIB="../lib/auditErrorLib.sh"
HIVE_TABLE="hivetestable"
AUDIT_TABLE="audit"

echo "Reading ${LIB}"
dos2unix ${LIB}
. ${LIB}

echo "Reading ${AUDIT_LIB}"
dos2unix ${AUDIT_LIB}
. ${AUDIT_LIB}


auditSetIncrementalLoadCdcRow ${debug_testRow} "debug"
batchRows