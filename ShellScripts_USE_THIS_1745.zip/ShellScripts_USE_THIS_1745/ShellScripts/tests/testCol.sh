#!/bin/bash

#set -x
#trap read debug

#--------------------------------------------------------------------
# Reads column names from a table, formats as CSV w/o data types, filters out ${EXCLUDE_COLUMNS}
# Parameter: ${DATABASE} ${TABLE}
# Returns: 0 if execution was successful, != 0 otherwise; pipes out ${COLUMNS}
#---------------------------------------------------------------------
readColNames(){

  var=`beeline --showHeader=false --outputformat=csv2 -u ${BEELINE_CONN_HIVE} -n ${USER_NAME} -w ${BEELINE_PW} -e "DESCRIBE $1.$2"`

  # Extract columns as list
  cols=$(echo "$var" | cut --delimiter=, --fields=1 --output-delimiter=, )
  cols=$(echo "$cols" | sed 's/, /,/g ')
  #cols=$(echo "$cols" | sed 's/${EXCLUDE_COLUMNS}//g ')

  COLLIST=$(echo ${cols} | tr "," "\n")

  EXCLUDE_LIST=$(echo ${EXCLUDE_COLUMNS} | tr "," "\n")
  INC=1
  for COL in ${COLLIST}
  do
    #echo -e "Checking ${COL}\n"
    contains=$( echo -e "${EXCLUDE_LIST}" | grep -i "${COL}" )
    if [ -z ${contains} ]; then
      COLUMNS=${COLUMNS}","${COL}
    else
     continue
    fi

    INC=$[$INC + 1]
  done

  COLUMNS=$(echo "${COLUMNS}" | sed '$!s/$/,/' )
  COLUMNS=$(echo "${COLUMNS}" | sed 's/,//1' )

  echo -e "${COLUMNS}"

  return $?
}

BEELINE_CONN_HIVE="jdbc:hive2://dcntdh01.nt.lab.com:10001/;principal=hive/dcntdh01.nt.lab.com@NT.LAB.COM;transportMode=http;httpPath=cliservice;"
USER_NAME=`whoami`
HIVE_DATABASE="dev_stage_genelco"
HCAT_TABLE="GRPCTRL"
BEELINE_PW=../security/${USER_NAME}.bin
#EXCLUDE_COLUMNS="LastUpdateDateTime,CurrentRecordIndicator,LogicalDeleteIndicator,LastUpdateUserID,LastUpdateProcessID"
EXCLUDE_COLUMNS="HiveLastUpdateTimestamp,hashcode"

readColNames $HIVE_DATABASE $HCAT_TABLE
echo "----------"
echo $COLUMNS