#!/bin/bash
addScdColumns(){
  # Add columns
  echo "DB: $1"
  echo "Table: $2"
  beeline -u "jdbc:hive2://dcntdh01.nt.lab.com:10001/;principal=hive/dcntdh01.nt.lab.com@NT.LAB.COM;transportMode=http;httpPath=cliservice;" -n v20634  \
  --hivevar DATABASE=$1 \
  --hivevar TABLE=$2 \
  --force=false \
  --verbose=true \
  -f "/home/v20634/import/SQL/addScdCols.sql" 
}

addScdColumns "dev_work_group_plus" "cds"