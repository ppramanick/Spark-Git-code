# sets minimum memory to 2GB, max to 16GB, max direct memory to 256MB
# also uses the parallel new and concurrent garbage collectors to reduce the likelihood of long stop-the-world GC pauses
JAVA_OPTS="-Xms2000m -Xmx16000m -Xss128k -XX:MaxDirectMemorySize=256m -XX:+UseParNewGC -XX:+UseConcMarkSweepGC"
export JAVA_OPTS=${JAVA_OPTS}