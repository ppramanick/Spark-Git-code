DROP TABLE IF EXISTS dev_publish_db_pmc.HierarchyReporting;
CREATE EXTERNAL TABLE dev_publish_db_pmc.HierarchyReporting
(
  ArrangementCode STRING,
  AgentCode STRING,
  StartDate String COMMENT 'Parse to Date',
  EndDate String COMMENT 'Parse to Date',
  IsPrimary INT,
  ContractName STRING,
  ContractStartDate String COMMENT 'Parse to Date',
  ContractEndDate String COMMENT 'Parse to Date',
  CarrierShortName STRING,
  Channel STRING,
  Role STRING,
  ApplyAdvance INT,
  RAAgentCode STRING,
  RAArrangementCode STRING,
  FieldOfficeName STRING,
  WritingNumbers STRING
)
CLUSTERED BY (ArrangementCode,AgentCode) INTO 16 BUCKETS
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY ','
--STORED AS TEXTFILE
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES (
   "separatorChar" = ",",
   "quoteChar"     = "\""
  )
STORED AS TEXTFILE
LOCATION 'hdfs://AFLACHADDEV/data/DEV/publish/PMC/HierarchyReporting';
