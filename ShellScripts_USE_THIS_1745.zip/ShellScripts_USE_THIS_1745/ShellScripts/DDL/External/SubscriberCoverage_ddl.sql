-- SubscriberCoverage
DROP TABLE IF EXISTS dev_publish_db_pmc.SubscriberCoverage;
CREATE EXTERNAL TABLE dev_publish_db_pmc.SubscriberCoverage
(
   Title STRING			--Title such as Mr, Mrs, Miss of the subscriber (insured)
  ,First_Name STRING		--First name of the subscriber
  ,Last_Name STRING		--Last name of the subscriber
  ,Suffix STRING			--Suffix such as Jr, Sr
  ,EmployeeNumber STRING -- PK		--Unique code to identify the subscriber
  ,CustomerNumber STRING -- PK		--This is the Customer Number
  ,CustomerName STRING				--Customer/Account number
  ,CustomerBillGroup STRING			--Customer's Location where employee works
  ,Gender STRING						--Gender of the subscriber (F-Female,M-Male)
  ,Subscriber_Status STRING			--Status of the subscriber(Active/Inactive/Terminated/Pending)
  ,Subscriber_Status_Date STRING		--Date from when the status is in effect
  ,CarrierCode STRING					--2500 for CAIC, 2200 for AFNY
  ,GroupPolicyNumber STRING			--Policy Number for the Group
  ,ProductCode STRING					--Product Code (VUE Product)
  ,ProductItemCode STRING				--Aflac Plan Code (VUE Product Item, dynamically created and stored in VUE)
  ,CertNumber STRING 				-- PK--Cert Number
  ,EffectiveDate STRING				--Effective Date
  ,OriginalEffectiveDate STRING		--Original Effective Date
  ,Cert_Status STRING					--Status of the Coverage(Active/Terminated/Pending)
  ,Cert_Status_Date STRING			--Date from when the status is in effect
  ,AppDate STRING						--Application Signed Date of the Cert
  ,IssuedDate STRING					--Date when the App/Cert is issued
  ,State STRING						--Situs State of the Subscriber
  ,Certificate_Solicitation_State STRING		--Certificate Solicitation State
  ,Location_of_Enrollment STRING		--Location of enrollment
  ,Source_of_Application STRING		--Source of new business (Paper, eFile)
  ,Enrollment_Method STRING			--Type of enrollment used for the given certificate (Producer Assisted, HR Enrolled)(Producer Assisted,HR Enrolled,Call Center,Internet or Self-Service)
  ,Arrangment_Code STRING				--Arrangement code tied to the cert. All the levels of Hierarchy can be obtained from the Arrangement feed listed above.
  ,Commission_Type STRING				--Commission Type is to determine whether the agent/agency arrangement is applicable for commissions or for reporting hierarchy.
  ,Agent_Start_Date STRING			--Agent Start Date
  ,Agent_End_Date STRING				--Agent End Date
  ,Split_Percentage DOUBLE			--
  ,Agent_Type STRING					--(Broker/Spit Agent/Variable Agent/Writing Agent )
  ,SigningAgentCode STRING			--(Signing Agent Writing Number)
  ,Annual_Premium DOUBLE
)
CLUSTERED BY (EmployeeNumber,CustomerNumber,CertNumber) INTO 16 BUCKETS
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY ','
--STORED AS TEXTFILE
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES (
   "separatorChar" = ",",
   "quoteChar"     = "\""
  )
STORED AS TEXTFILE
LOCATION 'hdfs://AFLACHADDEV/data/DEV/publish/PMC/SubscriberCoverage';
