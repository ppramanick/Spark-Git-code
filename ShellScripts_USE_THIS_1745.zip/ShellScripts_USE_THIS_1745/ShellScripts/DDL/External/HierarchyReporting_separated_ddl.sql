DROP TABLE IF EXISTS dev_publish_db_pmc.HierarchyReporting;
CREATE EXTERNAL TABLE dev_publish_db_pmc.HierarchyReporting
(
ArrangementCode String
,AgentCode String
,StartDate String
,EndDate String
,IsPrimary String
,ContractName String
,ContractStartDate String
,ContractEndDate String
,CarrierShortName String
,Channel String
,Role String
,ApplyAdvance String
,RAAgentCode String
,RAArrangementCode String
,FieldOfficeName String
,WritingNumber String
)
--CLUSTERED BY (ArrangementCode,AgentCode) INTO 16 BUCKETS
ROW FORMAT SERDE 'org.apache.hadoop.hive.contrib.serde2.RegexSerDe'
WITH SERDEPROPERTIES ("input.regex" = "(.{50})(.{50})(.{8})(.{8})(.{1})(.{50})(.{8})(.{8})(.{5})(.{100})(.{100})(.{1})(.{50})(.{50})(.{150})(.*)" )
LOCATION 'hdfs://AFLACHADDEV/data/DEV/publish/PMC/HierarchyReporting';

