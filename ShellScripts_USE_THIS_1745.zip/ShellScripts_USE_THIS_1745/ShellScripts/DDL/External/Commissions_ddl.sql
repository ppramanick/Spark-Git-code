-- Commissions
DROP TABLE IF EXISTS dev_publish_db_pmc.Commissions;
CREATE EXTERNAL TABLE dev_publish_db_pmc.Commissions
(
  StatementDate STRING				--The date on which the statement is generated for the calculated commission in the carrier system 
  ,FromDate STRING					--The date from which the premiums are considered for commission calculation
  ,ToDate STRING						--The date to which the premiums are considered for commission calculation
  ,CarrierGroupCode INT				--Carrier Group Code is the code defined for the group of carriers. This is not required for Aflac and used only for MGA implementations
  ,CarrierCode STRING					--Carriers for which the commission is calculated. 2400 (Aflac)/2500 (CAIC)/2200 (AFNY)
  ,GroupProductNumber STRING			--Policy Number - this is the Group Product Number
  ,PolicyNumber STRING				--Cert Number
  ,GroupAccountNumber STRING			--GroupAccountNumber
  ,EffectiveDate STRING				--Effective date of the policy
  ,DepositNumber STRING		--(Previously it was BIGINT)--This is for MGA implementations and not required for Aflac
  ,DepositDate STRING					--This is for MGA implementations and not required for Aflac
  ,TransactionDate STRING				--Date on when the customer pays the premium
  ,PaidToDate STRING					--Date till the premium is paid.
  ,DueDate STRING						--Premium due date.
  ,Premium DOUBLE						--Premium Amount
  ,PremiumType STRING					--Types of premium such as "Excess Premium", "Target Premium". Not required for Aflac
  ,PaymentFrequency STRING			--Codes for Payment Frequency : A-Anually,Q-Quarterly,SA-Semi Annually,M-Monthly
  ,Months INT							--Premium amount months
  ,AdvanceMonths INT					--Advance months paid
  ,CommissionablePremium DOUBLE --(Previously it was String)		--Premium amount on which the commission need to be calculated after deduction of fee amounts
  ,CommissionRate DOUBLE --(Previously it was String)				--Rate on which the commission is paid
  ,Revenue DOUBLE						--Commission Amount
  ,EarnedCommission DOUBLE			--Earnoff commission amount if paid advance
  ,ProductItemCode STRING				--Product item code to identify the product item for the product
  ,CommissionType STRING				--To determine the commission type such as BASE or OVER
  ,TransactionCode STRING				--Transaction codes to determine the transaction such as AD','ADC','AM','BASE','BONUS','CB','CBR','CBT','FEE','FY','OVER'
  ,TransactionDesc STRING				--Description of the transaction
  ,PolicyYear INT						--which year policy
  ,State STRING						--Policy state
  ,ProductCode STRING					--Product code configured while defining the product
  ,ProductName STRING					--Name of the product
  ,AgentCode BIGINT					--Agent Code to uniquely identify the agent in the system
  ,AgentRole STRING					--Agent Role
  ,RAAgentCode STRING					--RA Agent Code
  ,SubscriberCount INT				--Count of subscribers under a group/account
  ,MemberCount INT					--Count of memebrs for all the subscribers of the account 
  ,Insured_First_Name STRING			--First Name of the subscriber
  ,Insured_Last_Name STRING			--Last Name of the subscriber
  ,Insured_Middle_Name STRING			--Middle Name of the subscriber
  ,Insured_Name STRING				--Full Name of the subscriber
  ,Insured_Number STRING				--Subscriber number used to uniquely identify the record
  ,Insured_Type STRING				--Individual/Group
  ,Is_Individual INT					--If the insured is individual or Group
  ,DOB STRING							--Date of birth of the subscriber
  ,Insured_Status STRING				--status of the insured
  ,Insured_Status_Date STRING			--Date on when the insured status is set/modified
  ,WritingNumber STRING				--Agent writing number or cross reference # used to identify the agent record in other systems
  ,Policy_Status STRING				--Status of the policy
  ,Policy_Status_Date STRING			--Date on when the policy status is set/modified
  ,Policy_Status_Reason STRING		--Status reason of the policy
  ,Policy_Status_Reason_Date STRING	--Date on when the policy status reason is set/modified
  ,Policy_App_Date STRING				--The date on which the policy is applied for
  ,Policy_Paid_To_Date STRING			--Till when the premium is paid on the policy
  ,Policy_Issue_Age INT				--Insured Age
  ,Trasaction_Source STRING
)
CLUSTERED BY (StatementDate,AgentCode,Insured_Number) INTO 16 BUCKETS
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY ','
--STORED AS TEXTFILE
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES (
   "separatorChar" = ",",
   "quoteChar"     = "\""
  )
STORED AS TEXTFILE
LOCATION 'hdfs://AFLACHADDEV/data/DEV/publish/PMC/Commissions'
tblproperties("skip.header.line.count"="1");
