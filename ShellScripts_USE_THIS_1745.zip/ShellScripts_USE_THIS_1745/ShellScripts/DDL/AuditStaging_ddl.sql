-- Meta
DROP TABLE IF EXISTS dev_meta.auditStaging;
CREATE EXTERNAL TABLE dev_meta.auditStaging(
  key String
  ,StagingTotalNumberOfRows BigInt COMMENT 'Total Number of Rows Copied into the Staging Zone Table'
  ,StagingValidatedRows BigInt COMMENT 'Total Number of Validated Rows in the Staging Zone Table'
  ,StagingFailureRows BigInt COMMENT 'Total Number of Rows with Errors in the Staging Zone Table'
  ,WorkTotalNumberOfRows BigInt COMMENT 'Total Number of Rows Copied into the Work Zone Publish Formatted Table'
  ,WorkValidatedRows BigInt COMMENT 'Total Number of Validated Rows in the Work Zone Table'
  ,WorkFailureRows BigInt COMMENT 'Total Number of Rows with Errors in the Work Zone Table'
  ,StagingProcessStartDateTime Timestamp COMMENT 'Date and Time that the Staging Process Started'
  ,StagingProcessEndDateTime Timestamp COMMENT 'Date and Time that the Staging Process Ended'
  ,StagingProcessRunTimeMs BigInt COMMENT 'Executing userid for staging process'
  ,StagingProcessUserId String COMMENT 'Total staging runtime in ms'
  ,StagingValidationStartDateTime Timestamp COMMENT 'Date and Time that the Staging Validation Process Started'
  ,StagingValidationEndDateTime Timestamp COMMENT 'Date and Time that the Staging Validation Process Ended'
  ,StagingToArchiveStartDateTime Timestamp COMMENT 'Date and Time that the Process that copies the Staging Data to the Archive Zone Started'
  ,StagingToArchiveEndDateTime Timestamp COMMENT 'Date and Time that the Process that copies the Staging Data to the Archive Zone Ended'
  ,StagingToArchiveRunTimeMs BigInt COMMENT 'Runtime for staging to archive in ms'
  ,StagingToWorkStartDateTime Timestamp COMMENT 'Date and Time that the Process that copies the Source Data to the Work Zone Table Started'
  ,StagingToWorkEndDateTime Timestamp COMMENT 'Date and Time that the Process that copies the Source Data to the Work Zone Table Ended'
  ,WorkDatabaseName String COMMENT 'Database Name in the Work Zone where Staging Data and Landing Zone Data is copied to'
  ,WorkTableName Varchar(256) COMMENT 'Table Name in the Work Zone where Staging Data and Landing Zone Data is copied to'
  ,StagingtoWorkRunTimeMs BigInt COMMENT 'Runtime for staging to work in ms'
  ,StagingDatabaseName String COMMENT 'Database Name in the Staging Zone where data from the Source System is copied into'
  ,StagingTableName Varchar(256) COMMENT 'Table Name in the Staging Zone where data from the Source System is copied into'
  ,SourceDatabaseName String COMMENT 'Database Name in the Source System from which Data is copied into the Staging Zone'
  ,SourceTableName Varchar(256) COMMENT 'Table Name in the Source System from which Data is copied into the Staging Zone'
  ,SourceSystemName Varchar(256) COMMENT 'Name of the System that produed the Source File (obtained from the Source System)'
  ,SourceLocationName Varchar(256) COMMENT 'Name of File Directory where the Source File was obtained from the Source System'
  ,SourceFileName Varchar(256) COMMENT 'File Name of the Source File (obtained from the Source System)'
  ,StagingProcessName Varchar(256) COMMENT 'Name of the Process that copies the Source Data into the Staging Zone'
  ,StagingValidationProcessName Varchar(256) COMMENT 'Name of the Process that Validates the Data in the Staging Zone'
  ,StagingToArchiveProcessName Varchar(256) COMMENT 'Name of the Process that copies the Source Data into the Archive  Zone Table'
  ,StagingToWorkProcessName Varchar(256) COMMENT 'Name of the Process that copies the Source Data to the Work Zone Table'
  ,WorkProcessName Varchar(256) COMMENT 'Name of the Process that copies the Source Data into the Work Zone'
  ,StagingToWorkLastImport Timestamp COMMENT 'Last import timestamp used for Sqoop (incremental)'
  ,StagingtoWorkValidationRunTimeInMs Bigint COMMENT 'Total time for verification in ms'

)
STORED BY 'org.apache.hadoop.hive.hbase.HBaseStorageHandler'
WITH SERDEPROPERTIES ("hbase.columns.mapping" = "
  :key
,cf:stgTot
,cf:stgVal
,cf:stgFail
,cf:wrkTot
,cf:wrkVal
,cf:wrkFail
,cf:stgSDt
,cf:stgEDt
,cf:stgRt
,cf:stgId
,cf:stgValSDt
,cf:stgValEDt
,cf:stgArcSDt
,cf:stgArcEDt
,cf:stgArcRt
,cf:stgWrkSDt
,cf:stgWrkEDt
,cf:wrkDb
,cf:wrkTbl
,cf:stgWrkRt
,cf:stgDb
,cf:stgTbl
,cf:srcDb
,cf:srcTbl
,cf:srcSys
,cf:srcLoc
,cf:srcFile
,cf:stgProc
,cf:stgValProc
,cf:stgArcProc
,cf:stgWrkProc
,cf:wrkProc
,cf:stgWrkThrs
,cf:stgWrkValRt

")
TBLPROPERTIES ('hbase.table.name' = 'audit');
