CREATE TABLE ${WORK_DATABASE}.AccountLine(
  --AccountLineID BIGINT NOT NULL,
  --AccountTransactionID BIGINT NOT NULL,
  AccountLineNumber VARCHAR(100) COMMENT 'Mapping found coming from source, NOT NULL',
  BusinessAccountNumber VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  TransactionNumber VARCHAR(100) COMMENT 'Mapping found coming from source, NOT NULL',
  AccountLineType VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  InternalCompanyCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  AccountLineDescription VARCHAR(255) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  AccountLineTransactionProcessingDate DATE COMMENT 'No Mapping, Hardcoded to 1900-01-01 NOT NULL',
  AccountLineTransactionCreationDate DATE COMMENT 'No Mapping, Hardcoded to 1900-01-01 NOT NULL',
  AccountLineTransactionIsReversedIndicator CHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  AccountLineTransactionReversalDate DATE COMMENT 'No Mapping, Hardcoded to 1900-01-01 NOT NULL',
  AccountLineAmount DECIMAL(11,2) COMMENT 'Mapping found coming from source, NOT NULL',
  AccountLineUnallocatedAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to GNL NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (AccountLineNumber) INTO 128 BUCKETS
STORED AS ORC;