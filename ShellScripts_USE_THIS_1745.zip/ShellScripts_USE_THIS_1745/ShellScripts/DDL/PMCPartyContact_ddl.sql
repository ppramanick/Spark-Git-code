CREATE TABLE ${WORK_DATABASE}.PMCPartyContact
(
  NPN STRING COMMENT 'Natural Key, NOT NULL',
  PartyContactRoleCode VARCHAR(50) COMMENT 'Natural Key, Mapping found coming from source,NOT NULL',
  PreferredContactTypeCode VARCHAR(50) COMMENT 'Mapping found coming from source,NOT NULL',
  FullName VARCHAR(100) COMMENT 'Mapping found coming from source,NOT NULL',
  AddressLine1 VARCHAR(250) COMMENT 'Mapping found coming from source,NOT NULL',
  AddressLine2 VARCHAR(250) COMMENT 'Mapping found coming from source,NOT NULL',
  AddressLine3 VARCHAR(250) COMMENT 'Mapping found coming from source,NOT NULL',
  AddressCityName VARCHAR(250) COMMENT 'Mapping found coming from source,NOT NULL',
  AddressPostalCode VARCHAR(20) COMMENT 'Mapping found coming from source,NOT NULL',
  StateCode VARCHAR(50) COMMENT 'Mapping found coming from source,NOT NULL',
  CountryCode VARCHAR(50) COMMENT 'Mapping found coming from source,NOT NULL',
  EmailAddressName VARCHAR(100) COMMENT 'Mapping found coming from source,NOT NULL',
  ContactTitle VARCHAR(50) COMMENT 'Mapping found coming from source,NOT NULL',
  FirstName VARCHAR(100) COMMENT 'Mapping found coming from source,NOT NULL',
  LastName VARCHAR(100) COMMENT 'Mapping found coming from source,NOT NULL',
  MiddleName VARCHAR(100) COMMENT 'Mapping found coming from source,NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Mapping found not coming from source,NOT NULL',
  CurrentRecordIndicator CHAR(1) COMMENT 'Mapping found coming from source,NOT NULL',
  SourceSystemCode VARCHAR(20) COMMENT 'Mapping found notcoming from source,NOT NULL',
  LogicalDeleteIndicator CHAR(1) COMMENT 'Mapping found coming from source,NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping found coming from source,NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No Mapping Hive Updated time Not null',
  hashcode STRING COMMENT 'No Mapping Hash Code of all valid columns NOT NULL'
)
CLUSTERED BY (NPN,PartyContactRoleCode) INTO 16 BUCKETS
STORED AS ORC;