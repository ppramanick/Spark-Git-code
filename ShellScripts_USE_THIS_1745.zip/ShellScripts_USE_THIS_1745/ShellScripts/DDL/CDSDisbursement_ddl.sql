CREATE TABLE ${WORK_DATABASE}.CDSDisbursement
( 
  DisbursementRecipientPartyID BIGINT COMMENT 'NOT NULL',
  DisbursementOperationCode VARCHAR(255) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  DisbursementAmount DECIMAL(18,2) COMMENT 'Mapping found coming from source, NOT NULL',
  DisbursementCreationDate TIMESTAMP COMMENT 'Not coming from source, Hardcoded to 1900-01-01 00:00:00 NOT NULL',
  DisbursementSentDate DATE COMMENT 'Not coming from source, Hardcoded to 1900-01-01 NOT NULL',
  DisbursementCashedDate DATE COMMENT 'Not coming from source, Hardcoded to 1900-01-01 NOT NULL',
  DisbursementCancelDate DATE COMMENT 'Not coming from source, Hardcoded to 1900-01-01 NOT NULL',
  DisbursementMoneyChannelCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  DisbursementNumber VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL', -- confirmed with DA team
  DisbursementTypeCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  DisbursementCancelReasonCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  DisbursementPaymentMethodCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  InterestPaymentAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
  DisbursementStatusCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  BackupWithholdingIndicator CHAR(1) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  TaxWithholdingAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
  DisbursementStatusDate DATE COMMENT 'Not coming from source, Hardcoded to 1900-01-01 NOT NULL',
  DisbursementPaymentMethodNumber VARCHAR(20) COMMENT 'Mapping found coming from source, NOT NULL',
  DisbursementRequestSourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  BackupWIthholdingDate TIMESTAMP COMMENT 'Not coming from source, Hardcoded to 1900-01-01 00:00:00 NOT NULL',
  BackupWithholdingStopDate TIMESTAMP COMMENT 'Not coming from source, Hardcoded to 1900-01-01 00:00:00 NOT NULL',
  BackupWithholdingAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
  DisbursementCreationTime TIMESTAMP COMMENT 'Not coming from source, Hardcoded to 1900-01-01 00:00:00 NOT NULL', -- Defaulted to 1900-01-01 00:00:00, Checked with DAs
  DisbursementPaymentTypeCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  InternalCompanyCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  ACHReturnCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL', -- Not present in STTM, default to -, checked with DAs
  BackupWithholdingRemarkCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL', -- Not present in STTM, default to -, checked with DAs
  DisbursementCheckStatusCode VARCHAR(50) COMMENT 'Coming from source, Not Null',
  DisbursementIssueTypeCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to Genelco NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (DisbursementNumber, DisbursementRequestSourceSystemCode) INTO 128 BUCKETS
STORED AS ORC;