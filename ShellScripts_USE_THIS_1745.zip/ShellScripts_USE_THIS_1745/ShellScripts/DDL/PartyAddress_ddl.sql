CREATE TABLE ${WORK_DATABASE}.PartyAddress
(
  --PartyID BIGINT NOT NULL,
  SourceGNLGroupNumber VARCHAR(20)  COMMENT 'Mapping found Coming from source, Natural Key NOT NULL',
  SourceGNLParticipantID VARCHAR(20) COMMENT 'Mapping found Coming from source, Natural Key NOT NULL',
  SourceGNLAccountNumber INT COMMENT 'Mapping found Coming from source, Natural Key NOT NULL',
  PartyAddressCategoryCode VARCHAR(50) COMMENT 'NOT NULL',
  AddressLine1 VARCHAR(250) COMMENT 'NOT NULL',
  AddressLine2 VARCHAR(250) COMMENT 'NOT NULL',
  AddressLine3 VARCHAR(250) COMMENT 'NOT NULL',
  AddressCityName VARCHAR(250) COMMENT 'NOT NULL',
  AddressPostalCode VARCHAR(20) COMMENT 'NOT NULL',
  StateCode VARCHAR(50) COMMENT 'NOT NULL',
  PreferredAddressCategoryIndicator VARCHAR(1) COMMENT 'NOT NULL',
  CountryCode VARCHAR(50) COMMENT 'NOT NULL',
  AddressValidationIndicator VARCHAR(1) COMMENT 'NOT NULL',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'NOT NULL',
  SourceSystemCode VARCHAR(20) COMMENT 'NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'NOT NULL',
  County VARCHAR(50) COMMENT 'NOT NULL', 
  LastUpdateUserID VARCHAR(20) COMMENT 'NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, Time stamp NOT NULL',
  hashcode STRING COMMENT 'No mapping, Time stamp NOT NULL'
)
CLUSTERED BY (SourceGNLGroupNumber, SourceGNLParticipantID, SourceGNLAccountNumber) INTO 128 BUCKETS
STORED AS ORC;


