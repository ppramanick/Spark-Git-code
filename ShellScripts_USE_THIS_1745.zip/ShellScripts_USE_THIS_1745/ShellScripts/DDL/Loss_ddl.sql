CREATE TABLE ${WORK_DATABASE}.Loss
(
  ClaimNumber VARCHAR(100) COMMENT 'Natural Key, Mapped from source Not null',
  SourceGNLGroupNumber VARCHAR(30) COMMENT 'Natural Key, Mapped from source Not null',
  SourceGNLParticipantID VARCHAR(30) COMMENT 'Natural Key, Mapped from source Not null',
  SourceGNLDependentSequenceNumber INT COMMENT 'Natural Key, Mapped from source Not null',
  LossName VARCHAR(250) COMMENT 'Mapped from source, current_timestamp',
  LossDescriptorName VARCHAR(100) COMMENT 'No mapping, Defaul to ',
  LossEventName VARCHAR(100) COMMENT 'No mapping, Default to',
  LossCloseDate TIMESTAMP COMMENT 'No mapping, Default to',
  LossChargeAmount DECIMAL(18,2) COMMENT 'No mapping, Default to',
  LossFirstPathologyCode VARCHAR(50) COMMENT 'No mapping, Default to',
  LossFirstPathologyFamilyCode VARCHAR(50) COMMENT 'No mapping, Defaul to',
  LossTypeCode VARCHAR(50) COMMENT 'No mapping, Default to',
  LossEventDate DATE COMMENT 'No mapping, Default to ',
  LossNotificationDate DATE COMMENT 'No mapping, Default to ',
  ProofofLossDate TIMESTAMP COMMENT 'No mapping, current_timestamp',
  ProofofLossIndicator CHAR(1) COMMENT 'No mapping, current_timestamp',
  CurrentRecordIndicator CHAR(1) COMMENT 'No mapping, current_timestamp',
  SourceSystemCode VARCHAR(20) COMMENT 'No mapping, Default to Genelco for RDM',
  LogicalDeleteIndicator CHAR(1) COMMENT 'Mapped from source Not null',
  LastUpdateDateTime TIMESTAMP COMMENT 'No mapping, current_timestamp',
  LastUpdateUserID VARCHAR(20) COMMENT 'No mapping, Default UserID',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'Full row hash for CDC Computation'
)
CLUSTERED BY (ClaimNumber,SourceGNLGroupNumber,
  SourceGNLParticipantID,SourceGNLDependentSequenceNumber) INTO 128 BUCKETS
STORED AS ORC;


