CREATE EXTERNAL TABLE audit(
key String 
,CoreToPublishStartTimestamp Timestamp 
,CoreToPublishEndTimestamp Timestamp 
,CoreProcessName Varchar(256) 
,CoreProcessStartTimestamp Timestamp 
,CoreProcessEndTimestamp Timestamp 
,PublishTotalNumberOfRows BigInt 
,CoreTotalNumberOfRows BigInt 
,CoreFailureRows BigInt 
,SourceFileSize BigInt 
,LandingFileSize BigInt 
,LandingFileHashTotal BigInt 
,LandingProcessUserId String 
,LandingProcessRunTimeMs BigInt 
,StagingTotalNumberOfRows BigInt 
,StagingValidatedRows BigInt 
,StagingFailureRows BigInt 
,WorkTotalNumberOfRows BigInt 
,WorkValidatedRows BigInt 
,WorkFailureRows BigInt 
,SourceFileTimestamp Timestamp 
,LandingProcessStartTimestamp Timestamp 
,LandingProcessEndTimestamp Timestamp 
,LandingToArchiveStartTimestamp Timestamp 
,LandingToArchiveEndTimestamp Timestamp 
,LandingToWorkStartTimestamp Timestamp 
,LandingToWorkEndTimestamp Timestamp 
,LandingToWorkRunTimeMs BigInt 
,StagingProcessStartTimestamp Timestamp 
,StagingProcessEndTimestamp Timestamp 
,StagingProcessRunTimeMs BigInt 
,StagingProcessUserId String 
,StagingValidationStartTimestamp Timestamp 
,StagingValidationEndTimestamp Timestamp 
,StagingToArchiveStartTimestamp Timestamp 
,StagingToArchiveEndTimestamp Timestamp 
,StagingToArchiveRunTimeMs BigInt 
,StagingToWorkStartTimestamp Timestamp 
,StagingToWorkEndTimestamp Timestamp 
,WorkProcessStartTimestamp Timestamp 
,WorkProcessEndTimestamp Timestamp 
,WorkProcessRunTimeMs BigInt 
,WorkValidationStartTimestamp Timestamp 
,WorkValidationEndTimestamp Timestamp 
,WorkMappingStartTimestamp Timestamp 
,WorkMappingEndTimestamp Timestamp 
,WorkMappingRunTimeMs Bigint 
,WorkCDCStartTimestamp Timestamp 
,WorkCDCStartEndTimestamp Timestamp 
,WorkCDCRunTimeMs Bigint 
,WorkToCoreStartTimestamp Timestamp 
,WorkToCoreEndTimestamp Timestamp 
,PublishTableName Varchar(256) 
,CoreTableName Varchar(256) 
,WorkTableName Varchar(256) 
,StagingtoWorkRunTimeMs BigInt 
,StagingTableName Varchar(256) 
,SourceTableName Varchar(256) 
,SourceSystemName Varchar(256) 
,SourceLocationName Varchar(256) 
,SourceFileName Varchar(256) 
,LandingFileName Varchar(256) 
,LandingFileLocation Varchar(256) 
,LandingProcessName Varchar(256) 
,LandingToArchiveProcessName Varchar(256) 
,LandingToWorkProcessName Varchar(256) 
,StagingProcessName Varchar(256) 
,StagingValidationProcessName Varchar(256) 
,StagingToArchiveProcessName Varchar(256) 
,StagingToWorkProcessName Varchar(256) 
,WorkProcessName Varchar(256) 
,WorkValidationProcessName Varchar(256) 
,WorkMappingProcessName Varchar(256) 
,WorkCDCProcessName Varchar(256) 
,WorkToCoreProcessName Varchar(256) 
,CoreToPublishProcessName Varchar(256) 
,StagingToWorkLastImport Timestamp 
,WorkProcessUserId String 
)
STORED BY 'org.apache.hadoop.hive.hbase.HBaseStorageHandler'
WITH SERDEPROPERTIES ("hbase.columns.mapping" = "
:key
,cf:corePubSDt
,cf:corePubEDt
,cf:coreProc
,cf:coreSDt
,cf:coreEDt
,cf:pubTot
,cf:coreTot
,cf:coreFailTot
,cf:srcSize
,cf:lanSize
,cf:lanHash
,cf:lanId
,cf:lanRt
,cf:stgTot
,cf:stgVal
,cf:stgFail
,cf:wrkTot
,cf:wrkVal
,cf:wrkFail
,cf:srcFDt
,cf:lanSDt
,cf:lanEDt
,cf:lanArcSDt
,cf:lanArcSEt
,cf:lanWrkSDt
,cf:lanWrkEDt
,cf:lanWrkRt
,cf:stgSDt
,cf:stgEDt
,cf:stgRt
,cf:stgId
,cf:stgValSDt
,cf:stgValEDt
,cf:stgArcSDt
,cf:stgArcEDt
,cf:stgArcRt
,cf:stgWrkSDt
,cf:stgWrkEDt
,cf:wrkSDt
,cf:wrkEDt
,cf:wrkRt
,cf:wrkValSDt
,cf:wrkValEDt
,cf:wrkTranSDt
,cf:wrkTranEDt
,cf:wrkTranRt
,cf:wrkCdcSDt
,cf:wrkCdcEDt
,cf:wrkCdcRt
,cf:wrkCdcSDt
,cf:wrkCdcEDt
,cf:pubTbl
,cf:coreTbl
,cf:wrkTbl
,cf:stgWrkRt
,cf:stgTbl
,cf:srcTbl
,cf:srcSys
,cf:srcLoc
,cf:srcFile
,cf:lanFile
,cf:lanFLoc
,cf:lanProc
,cf:lanArcProc
,cf:lanWrkProc
,cf:stgProc
,cf:stgValProc
,cf:stgArcProc
,cf:stgWrkProc
,cf:wrkProc
,cf:wrkValProc
,cf:wrkTranProc
,cf:wrkCdcProc
,cf:wrkCorePrc
,cf:corePubProc
,cf:stgWrkThrs
,cf:wrkCoreId
")
TBLPROPERTIES ('hbase.table.name' = 'audit');
