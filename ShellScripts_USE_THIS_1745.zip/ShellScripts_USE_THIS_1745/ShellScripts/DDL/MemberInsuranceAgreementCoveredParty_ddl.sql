CREATE TABLE ${WORK_DATABASE}.MemberInsuranceAgreementCoveredParty
(
  MemberInsuranceAgreementNumber VARCHAR(100) COMMENT 'Mapping found Coming from source NOT NULL',
  InternalCompanyCode VARCHAR(50) COMMENT 'Mapping found coming from source NOT NULL',
  InsuranceAgreementTypeCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to Individual Certificate NOT NULL',
  ProductCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceGNLGroupNumber VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceGNLDependentSequenceNumber DECIMAL(10,2) COMMENT 'Mapping found coming from source NOT NULL',
  SourceGNLParticipantID VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  MemberInsuranceAgreementCoveredPartyEffectiveDate DATE COMMENT 'No Mapping, Hardcoded to 1900-01-01 NOT NULL',
  MemberInsuranceAgreementCoverageEndDate DATE COMMENT 'Mapping found Coming from source NOT NULL',
  MemberInsuranceAgreementCoveredPartyEndDate DATE COMMENT 'No Mapping Hardcoded to 9999-12-31 NOT NULL',
  MemberInsuranceAgreementCoverageEffectiveDate DATE COMMENT 'Mapping found Coming from source NOT NULL',
  HasPreExistingConditionIndicator VARCHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  TobaccoHabitCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  CoveredPartyStatusCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  CoveredPartyStatusDate DATE COMMENT 'No Mapping, Hardcoded to 1900-01-01 NOT NULL',
  CoveredPartyTypeCode STRING,
  LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source current timestamp LastUpdateDateTime NOT NULL',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(20) COMMENT 'Not coming from source Hardcoded to GNL NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (MemberInsuranceAgreementNumber,InternalCompanyCode,ProductCode,SourceGNLGroupNumber,SourceGNLDependentSequenceNumber,SourceGNLParticipantID,MemberInsuranceAgreementCoverageEffectiveDate) INTO 128 BUCKETS
STORED AS ORC;

