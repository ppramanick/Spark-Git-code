CREATE TABLE ${WORK_DATABASE}.PartyAlternateID
(
  --PartyID BIGINT NOT NULL,  COMMENT 'Will not be Not Part of datalake, Produced in EODS'
  SourceGNLAccountNumber INT  COMMENT 'No Mapping, Used in EODS to populate PartyID, NOT NULL',
  SourceGNLParticipantID VARCHAR(20)  COMMENT 'No Mapping, Used in EODS to populate PartyID, NOT NULL',
  SourceGNLDependentSequenceNumber INT COMMENT 'Mapping found Coming from source, NOT NULL DEFAULT 0',
  SourceGNLGroupNumber VARCHAR(20)  COMMENT 'No Mapping, Used in EODS to populate PartyID, NOT NULL',
  PartyAlternateIDTypeCode VARCHAR(50) COMMENT 'Mapping found, coming from source, NOT NULL',
  PartyAlternateIDValue VARCHAR(50) COMMENT 'Mapping found, coming from source, NOT NULL',
  CurrentRecordIndicator CHAR(1)  COMMENT 'Mapping found Coming from source, NOT NULL',
  SourceSystemCode VARCHAR(20)  COMMENT 'Not coming from source, Default GNL For Genelco, WYN for Wynsure, NOT NULL',
  LogicalDeleteIndicator CHAR(1)  COMMENT 'Mapping found Coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20)  COMMENT 'Datalake Batch UserID / VID, NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Time stamp or LastUpdated_ts from source, NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No Mapping Hive Updated time Not null',
  hashcode STRING COMMENT 'No Mapping Hash Code of all valid columns NOT NULL'
)
CLUSTERED BY (SourceGNLGroupNumber,SourceGNLParticipantID,SourceGNLAccountNumber,SourceGNLDependentSequenceNumber) INTO 128 BUCKETS
STORED AS ORC;