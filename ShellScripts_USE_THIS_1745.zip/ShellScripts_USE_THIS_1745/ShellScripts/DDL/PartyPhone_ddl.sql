CREATE TABLE ${WORK_DATABASE}.PartyPhone
(
  --PartyID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL'
  SourceGNLGroupNumber VARCHAR(20) COMMENT 'Mapping found Coming from source, NOT NULL', --Natural Key, Used to Populate PK/FK PartyID in BDM
  SourceGNLAccountNumber INT COMMENT 'Mapping found Coming from source, NOT NULL', --Natural Key, Used to Populate PK/FK PartyID in BDM
  PhoneType VARCHAR(50) COMMENT 'Hardcoded to Business/Fax, needs RDM lookup NOT NULL', --Primary key, Used to populate PhoneTypeCode in BDM
  PreferredPhoneTypeFlag VARCHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  PhoneNumber VARCHAR(50) COMMENT 'Mapping found Coming from source NOT NULL',
  PhoneExtension VARCHAR(10) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(20) COMMENT 'Not coming from source, Hardcoded to GNL NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No Mapping Hive Updated time Not null',
  hashcode STRING COMMENT 'No Mapping Hash Code of all valid columns NOT NULL'
)
CLUSTERED BY (SourceGNLGROUPNUMBER, SourceGNLAccountNumber, PhoneType) INTO 128 BUCKETS
STORED AS ORC;