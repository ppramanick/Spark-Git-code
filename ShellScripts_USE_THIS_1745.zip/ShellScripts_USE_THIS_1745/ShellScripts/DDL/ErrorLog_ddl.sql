-- Meta
DROP TABLE IF EXISTS dev_meta.errorLog;
CREATE EXTERNAL TABLE dev_meta.errorLog(
  key String
  ,DataLakeIngestionStartDateTime Timestamp COMMENT 'Date and Time the Data Lake Ingestion Process started'
  ,DataLakeIngestionFailureDateTime Timestamp COMMENT 'Date and Time the Data Lake Ingestion Process failed'
  ,FailureCode Int COMMENT 'Bash return code'
  ,FailureDescription String COMMENT 'Description of error free-form text'
  ,FailureProcessName String COMMENT 'Script name causing the failure'
  ,FailureZone String COMMENT 'Zone the error affects: STAGING, LANDING, WORK, CORE, PUBLISH, ARCHIVE'
  ,YarnApplicationId String COMMENT 'YARN ApplicationId'
  ,FailureSqlScript String COMMENT 'SQL script causing the issue'
  ,FailureDatabase String COMMENT 'Database affected'
  ,FailureTable String COMMENT 'Table affected'
  ,RowsAffected Bigint COMMENT 'No. of rows affected'
  ,ErrorLevel String COMMENT 'INFO, WARN, ERROR, FATAL everthing over WARN should have stopped the process'
  ,FailureLogFile String COMMENT 'Associated log file from exceution'
  ,FailureLogMessage String COMMENT 'Failure log message'
  ,FailureTimestampsAffectedTimestamp Timestamp COMMENT 'Timestamp effected by error'
)
STORED BY 'org.apache.hadoop.hive.hbase.HBaseStorageHandler'
WITH SERDEPROPERTIES ("hbase.columns.mapping" = "
  :key
  ,cf:inSDt
  ,cf:inEDt
  ,cf:fCd
  ,cf:fDec
  ,cf:fProc
  ,cf:fZone
  ,cf:yarn
  ,cf:fSql
  ,cf:fDb
  ,cf:fTbl
  ,cf:rws
  ,cf:lvl
  ,cf:log
  ,cf:logmsg
  ,cf:fTsAf
")
TBLPROPERTIES ('hbase.table.name' = 'errorlog');
