 CREATE TABLE ${WORK_DATABASE}.PMCPartyAddress
(
  --PartyID BIGINT NOT NULL,
  NPN STRING COMMENT 'Natural Key, NOT NULL',
  PartyAddressCategoryCode VARCHAR(50) COMMENT 'Natural Key, Mapping found coming from source,NOT NULL',
  AddressLine1 VARCHAR(250) COMMENT 'Mapping found coming from source,NOT NULL',
  AddressLine2 VARCHAR(250) COMMENT 'Mapping found coming from source,NOT NULL',
  AddressLine3 VARCHAR(250) COMMENT 'Mapping found coming from source,NOT NULL',
  AddressCityName VARCHAR(250) COMMENT 'Mapping found coming from source,NOT NULL',
  AddressPostalCode VARCHAR(20) COMMENT 'Mapping found coming from source,NOT NULL',
  StateCode VARCHAR(50) COMMENT 'Mapping found coming from source,NOT NULL',
  PreferredAddressCategoryIndicator CHAR(1) COMMENT 'Mapping found not coming from source,NOT NULL',
  CountryCode VARCHAR(50) COMMENT 'Mapping found coming from source,NOT NULL',
  AddressValidationIndicator CHAR(1) COMMENT 'Mapping found coming from source,NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Mapping found not coming from source,NOT NULL',
  CurrentRecordIndicator CHAR(1) COMMENT 'Mapping found not coming from source,NOT NULL',
  SourceSystemCode VARCHAR(20) COMMENT 'Mapping found coming from source,NOT NULL',
  LogicalDeleteIndicator CHAR(1) COMMENT 'Mapping found coming from source,NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping found not coming from source,NOT NULL',
  County VARCHAR(50) COMMENT 'Mapping found not coming from source,NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No Mapping Hive Updated time Not null',
  hashcode STRING COMMENT 'No Mapping Hash Code of all valid columns NOT NULL'
)
CLUSTERED BY (NPN,PartyAddressCategoryCode) INTO 16 BUCKETS
STORED AS ORC;