CREATE TABLE ${WORK_DATABASE}.GroupInsuranceAgreementCoverage(
--GroupInsuranceAgreementID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
--ProductCoverageID INT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
InsuranceAgreementTypeCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to Group Certificate NOT NULL', --Natural Key, BDM lookup required
InternalCompanyCode VARCHAR(10) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
AccountNumber VARCHAR(10) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
InsuranceAgreementNumber VARCHAR(10) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
ProductCode VARCHAR(30) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
GroupInsuranceAgreementCoverageEffectiveDate TIMESTAMP COMMENT 'Mapping found coming from source, NOT NULL',
GroupInsuranceAgreementCoverageEndDate TIMESTAMP COMMENT 'Mapping found coming from source, NOT NULL',
GroupInsuranceAgreementCoverageStatusCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
GroupInsuranceAgreementCoverageTerminationReasonCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
MinimumParticipationRequiredPercentage DECIMAL(5,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
ActualParticipationCount INT COMMENT 'Not coming from source, Hardcoded to 0 NOT NULL',
CurrentParticipationCount INT COMMENT 'Not coming from source, Hardcoded to 0 NOT NULL',
ParticipationStatusCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
CoveredPartySetTypeCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to Genelco NOT NULL',
LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (InternalCompanyCode,AccountNumber,ProductCode,GroupInsuranceAgreementCoverageEffectiveDate) INTO 128 BUCKETS
STORED AS ORC;