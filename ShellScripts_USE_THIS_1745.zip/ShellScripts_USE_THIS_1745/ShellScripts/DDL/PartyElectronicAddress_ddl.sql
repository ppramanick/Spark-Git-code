CREATE TABLE ${WORK_DATABASE}.PartyElectronicAddress
(
  --PartyID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
  SourceGNLGroupNumber VARCHAR(20) COMMENT 'Mapping found Coming from source, NOT NULL', --Natural Key, Used to Populate PK/FK PartyID in BDM
  SourceGNLParticipantID VARCHAR(20)  COMMENT 'Mapping found Coming from source, NOT NULL', --Natural Key, Used to Populate PK/FK PartyID in BDM
  SourceGNLAccountnumber INT COMMENT 'Mapping found Coming from source, NOT NULL', --Natural Key, Used to Populate PK/FK PartyID in BDM
  RoleType CHAR(7) COMMENT 'Mapping found Coming from source, NOT NULL', --Natural key 
  ElectronicAddressTypeCode VARCHAR(50) COMMENT 'Not coming from Mapping, Default - ElectronicAddressTypeCode NOT NULL',
  ElectronicAddressText VARCHAR(150) COMMENT 'No Mapping, Hardcoded to Email- needs to go through RDM, NOT NULL',
  ElectronicAddressCategoryTypeCode VARCHAR(50) COMMENT 'Mapping found Coming from source NOT NULL',
  CurrentRecordIndicator CHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(20) COMMENT 'Not coming from source, Hardcoded to GNL NOT NULL',
  LogicalDeleteIndicator CHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No Mapping Hive Updated time Not null',
  hashcode STRING COMMENT 'No Mapping Hash Code of all valid columns NOT NULL'
)
CLUSTERED BY (SourceGNLGroupNumber, SourceGNLParticipantID, SourceGNLAccountnumber, RoleType) INTO 128 BUCKETS
STORED AS ORC;