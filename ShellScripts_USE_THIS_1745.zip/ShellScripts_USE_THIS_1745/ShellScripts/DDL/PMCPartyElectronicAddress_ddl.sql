CREATE TABLE ${WORK_DATABASE}.PMCPartyElectronicAddress(
NPN STRING COMMENT 'Mapping Found coming from source, NOT NULL',
ElectronicAddressTypeCode VARCHAR(50) COMMENT 'Mapping Found coming from source, NOT NULL',
ElectronicAddressText VARCHAR(150) COMMENT 'Mapping Found not coming from source, NOT NULL',
ElectronicAddressCategoryTypeCode VARCHAR(50) COMMENT 'Mapping Found coming from source, NOT NULL',
LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, hard-coded to currentimestamp NOT NULL',
CurrentRecordIndicator CHAR(1) COMMENT 'Not coming from source, hard-coded to Y NOT NULL',
SourceSystemCode VARCHAR(50) COMMENT 'Not coming not from source, hard-coded to PMC NOT NULL',
LogicalDeleteIndicator CHAR(1) COMMENT 'Not coming from source, hard-coded to N NOT NULL',
LastUpdateUserID VARCHAR(20) COMMENT 'Not coming from source, hard-coded to - NOT NULL',
hivelastupdatetimestamp TIMESTAMP COMMENT 'No Mapping Hive Updated time NOT NULL',
hashcode STRING COMMENT 'No Mapping Hash Code of all valid columns NOT NULL'
)
CLUSTERED BY (NPN, ElectronicAddressTypeCode, ElectronicAddressCategoryTypeCode) INTO 128 BUCKETS
STORED AS ORC;
