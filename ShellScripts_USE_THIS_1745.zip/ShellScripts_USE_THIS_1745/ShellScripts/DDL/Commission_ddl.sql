CREATE TABLE ${WORK_DATABASE}.Commission
(
  --CommissionID INTEGER NOT NULL,
  NPN VARCHAR(20) COMMENT 'Mapping found coming from source, NOT NULL',
  DepositNumber VARCHAR(20) COMMENT 'Mapping found coming from source, NOT NULL',
  StatementDate DATE COMMENT 'Mapping found coming from source, NOT NULL',
  StatementStartDate DATE COMMENT 'Mapping found coming from source, NOT NULL',
  StatementEndDate DATE COMMENT 'Mapping found coming from source, NOT NULL',
  InternalCompanyCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to PMC NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (NPN,DepositNumber,StatementDate) INTO 128 BUCKETS
STORED AS ORC;