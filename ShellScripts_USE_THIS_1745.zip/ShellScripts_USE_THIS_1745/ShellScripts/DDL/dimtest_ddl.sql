CREATE TABLE ${DATABASE}.dimtest
(
Driver_Id INT
,Policy_Id INT
)
CLUSTERED BY(Driver_Id) INTO 16 BUCKETS;