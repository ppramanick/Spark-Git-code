--AgentLicenceMan
CREATE EXTERNAL TABLE ${DATABASE}.${TABLE}
(
  AGENTCODE string,   -- pk (VUE Unique identifier NPN of the agent. Either AgentCode or WritingNumber is mandatory)
  LICENSENUMBER string,   --  pk  License Number
  LICENSETYPE string,     --License Type is to determine whether the appointment is an Individual appointment or Agency appointment
  ISSUEDATE string,     --Issue Date
  EXPIRATIONDATE string,      --Expiration Date
  STATE string,     --State in which the Licence is issued
  ISRESIDENT string,      --'Y’ – Yes, 'N’ – No
  LICENSESTATUS string,     --Active, Terminated, ‘ Pending,
  LICENSESTATUSDATE string, --License Status Date
  LICENSESTATUSREASON string, --Active, Terminated, ‘ Pending,
  LICENSESTATUSREASONDATE string,     --License Status Reason Date
  ISPERPERTUALLICENSE string,     --'Y’ – Yes, ‘N’ – No
  LICENSECLASS string,      --License Class
  LINEOFAUTHORITY string,     --Health Life and Health Life LineOfAuthority
  LOASTATUS string,     --Active or Inactive
  LOASTATUSDATE string,     --LOAStatusDate
  APPLIEDFORDATE string,
  ORIGINALISSUEDATE string,
  RECEIVEDDATE string,
  COMMENTS string,
  EXCLUDEFROMPDB int      --0-No, 1-Yes
) 
CLUSTERED BY (AGENTCODE,LICENSENUMBER) INTO 16 BUCKETS
STORED AS ORC;
