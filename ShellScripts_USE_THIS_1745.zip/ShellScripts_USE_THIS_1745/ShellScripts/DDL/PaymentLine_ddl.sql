CREATE TABLE ${WORK_DATABASE}.PaymentLine
(
  --AccountLineID BIGINT COMMENT 'No mapping, sequence to be generated in BDM NOT NULL',
  --PaymentID BIGINT COMMENT 'No mapping, sequence to be generated in BDM NOT NULL',
  AccountLineNumber VARCHAR(100) COMMENT 'Mapping coming from source Natural Key, NOT NULL', --Natural Key, Used to Populate PK AccountLineID in BDM
  PaymentNumber VARCHAR(20) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, Used to Populate PK PaymentID in BDM, it it correct ?
  AccountLineType VARCHAR(20) COMMENT 'No Mapping, Hardcoded to Payment NOT NULL', -- why do we need these columns ? Pooja to confirm if we can remove
  AccountLineAmount DECIMAL(11,2) COMMENT 'Mapping found coming from source, NOT NULL', -- why do we need these columns ? Pooja to confirm if we can remove
  LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp NOT NULL',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to GNL NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (AccountLineNumber) INTO 128 BUCKETS
STORED AS ORC;