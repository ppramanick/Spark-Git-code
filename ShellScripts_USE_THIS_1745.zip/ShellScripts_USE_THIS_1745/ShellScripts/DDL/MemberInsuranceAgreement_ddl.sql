CREATE TABLE ${WORK_DATABASE}.MemberInsuranceAgreement
(
--MemberInsuranceAgreementID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
--GroupInsuranceAgreementID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
--AccountID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
--MemberPartyID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
InsuranceAgreementNumber VARCHAR(100) COMMENT 'Mapping found Coming from source NOT NULL',
InternalCompanyCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
InsuranceAgreementTypeCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to Individual Certificate NOT NULL',
GroupInsuranceAgreementNumber VARCHAR(100) COMMENT 'Mapping found Coming from source NOT NULL',
AccountNumber VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
SourceGNLParticipantID VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
SourceGNLAccountNumber DECIMAL(5,0) COMMENT 'Mapping from source Not null',
MemberInsuranceAgreementTerminationReasonCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
MemberInsuranceAgreementModificationReasonCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
MemberClassificationName VARCHAR(100) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
SourceSystemCode VARCHAR(20) COMMENT 'Not coming from source, Hardcoded to GNL NOT NULL',
LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (InsuranceAgreementNumber,InternalCompanyCode) INTO 128 BUCKETS
STORED AS ORC;


