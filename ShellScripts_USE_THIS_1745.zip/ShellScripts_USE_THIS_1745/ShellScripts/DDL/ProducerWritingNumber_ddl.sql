CREATE TABLE ${WORK_DATABASE}.ProducerWritingNumber(
  --ProducerPartyID BIGINT COMMENT 'Mapping found coming from source, NOT NULL',
  ProducerWritingNumber VARCHAR(10) COMMENT 'Mapping found coming from source, NOT NULL',
  InternalCompanyCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  NPN VARCHAR(20) COMMENT 'Mapping found coming from source, NOT NULL',
  ProducerWritingNumberEffectiveDate TIMESTAMP COMMENT 'Mapping found coming from source, NOT NULL',
  EndDate TIMESTAMP COMMENT 'Mapping found coming from source, NOT NULL',
  AssociateStatusCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  LastProductionDate TIMESTAMP COMMENT 'Not coming from source, Hardcoded to 9999-12-31 23:59:59 NOT NULL',
  BrokerExceptionFlag CHAR(1) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  ProducerMaximumLevelNumber INT COMMENT 'Not coming from source, Hardcoded to 0 NOT NULL',
  VestedFlag CHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  PartnerIndicator CHAR(1) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  ProducerTenureCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to PMC NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (ProducerWritingNumber,InternalCompanyCode) INTO 128 BUCKETS
STORED AS ORC;

