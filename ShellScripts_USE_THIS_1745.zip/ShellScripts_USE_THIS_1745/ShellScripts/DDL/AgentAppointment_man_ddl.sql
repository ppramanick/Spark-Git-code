--AgentAppointmentman
CREATE EXTERNAL TABLE ${DATABASE}.${TABLE}
(
  AGENTCODE STRING COMMENT 'PK (VUE Unique identifier NPN of the agent. Either AgentCode or WritingNumber is mandatory)',
  APPOINTMENTTYPE STRING, --Appointment Type is to determine whether the appointment is an Individual appointment or Agency appointment
  CARRIERSHORTNAME  STRING,
  RECEIVEDDATE  STRING, --The date on which the appointment request was received
  EFFECTIVEDATE STRING, --The effective date of the appointment from when the individual/agency is eligible to sell respective products in the market for the Carrier & State.
  STATE STRING, --State in which the appointment is made-
  APPOINTMENTSTATUS STRING, --Status of the appointment-
  APPOINTMENTSTATUSDATE STRING, --Date on which the appointment status is set/modified
  APPOINTMENTSTATUSREASON STRING, --Status reason of the appointment based on the respective status
  APPOINTMENTSTATUSREASONDATE STRING,
  RENEWALDATE STRING, --Renewal Date
  EXCLUDEFROMRENEWALPROCESS int,  --0-No 1-Yes
  LINEOFAUTHORITY STRING, --LOA based on applicable State, License Class 
  LOASTATUS STRING, --Status of the Appointment Line of Authority
  LOASTATUSDATE STRING, --Date on which the appointment status is set/modified
  APPOINTMENTTERMINATIONDUEDATE STRING, --Date on which the appointment is set for termination. Appointment Term Due Date will be populated when appointment is set for future termination.
  ISEXCLUDEFROMPDB  int,  --0-No  1-Yes
  LICENSETYPE STRING,   --License Type is to determine whether the appointment is for individual license or corporate (agency) license
  SUBMITTEDDATE STRING,   --Date when an appointment request or termination is submitted to NIPR. This is not required to be filled by Aflac
  ORIGINALEFFECTIVEDATE STRING    --Effective date of appointment when it is issued initially. This date will be fixed and not varied for appointment renewal. The effective date and original effective date of the appointment will be same initially and the effective date will change during appointment renewal
)
STORED AS ORC;