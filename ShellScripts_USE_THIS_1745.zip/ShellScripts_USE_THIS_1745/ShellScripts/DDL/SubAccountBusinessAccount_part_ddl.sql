SET hive.exec.dynamic.partition.mode = nonstrict;
CREATE TABLE ${WORK_DATABASE}.SubAccountBusinessAccount(
--BusinessAccountID BIGINT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
--GroupInsuranceAgreementID BIGINT 'No mapping, Not coming from Source / RDM Process required NOT NULL'
GroupInsuranceAgreementNumber VARCHAR(100) COMMENT 'Mapping found Coming from source NOT NULL', --Natural Key
BussinessAccountNumber VARCHAR(100) COMMENT 'Mapping found Coming from source NOT NULL', --Natural Key, Used to Populate PK/FK BusinessAccountID in BDM
SubAccountNumber VARCHAR(100) COMMENT 'Mapping found Coming from source NOT NULL', --Used to Populate PK/FK GroupInsuranceAgreementID in BDM
InternalCompanyCode VARCHAR(100) COMMENT 'Mapping found Coming from source NOT NULL', --Natural Key, Used to Populate PK/FK BusinessAccountID in BDM
BusinessAccountType VARCHAR(100) COMMENT 'No Mapping, Hardcoded to Invoice Account NOT NULL',
LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
SourceSystemCode VARCHAR(20) COMMENT 'Not coming from source, Hardcoded to GNL NOT NULL',
LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
hivelastupdatetimestamp TIMESTAMP COMMENT 'No Mapping Hive Updated time Not null',
hashcode STRING COMMENT 'No Mapping Hash Code of all valid columns NOT NULL'
)
PARTITIONED BY (scd_flag boolean)
STORED AS ORC;
