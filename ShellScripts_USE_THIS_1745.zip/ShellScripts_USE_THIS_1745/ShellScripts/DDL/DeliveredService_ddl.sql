CREATE TABLE ${WORK_DATABASE}.DeliveredService(
--DeliveredServiceID BIGINT COMMENT 'No mapping, Not coming from Source / sequence to be generated in BDM',
--LossID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL'
--CoveredPartyID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL'
--MemberInsuranceAgreementID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL'
BeneficiaryPartyID BIGINT COMMENT 'Not coming from source, Hardcoded to -1 NOT NULL',
ProductCoverageID INT COMMENT 'Not coming from source, Hardcoded to -1 NOT NULL',
DeliveredServiceName VARCHAR(150) COMMENT 'Mapping found coming from source, NOT NULL',
ClaimNumber VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
LossName VARCHAR(250) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
SourceGNLGroupNumber VARCHAR(20) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
SourceGNLParticipantID VARCHAR(20) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
SourceGNLDependentSequenceNumber INT COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
Internalcompanycode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
InsuranceAgreementTypeCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to Individual Certificate NOT NULL', --Natural Key, BDM lookup required
InsuranceAgreementNumber VARCHAR(40) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
LossProcedureCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
DeliveredServiceCanceledFlag CHAR(1) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
DeliveredServiceReasonCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
DeliveredServiceTypeCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
MemberInsuranceAgreementCoverageEffectiveDate DATE COMMENT 'Not coming from source, Hardcoded to 1900-01-01 NOT NULL',
DeliveredServiceDate DATE COMMENT 'Not coming from source, Hardcoded to 1900-01-01 NOT NULL',
DeliveredServiceDecisionReasonCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to Genelco NOT NULL',
LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (DeliveredServiceName,ClaimNumber,LossName) INTO 128 BUCKETS
STORED AS ORC;