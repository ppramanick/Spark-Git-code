CREATE TABLE ${WORK_DATABASE}.MemberInsuranceAgreementCoverage
(
--MemberInsuranceAgreementID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
--ProductCoverageID INTEGER COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
--GroupInsuranceAgreementID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
MemberInsuranceAgreementNumber VARCHAR(100) COMMENT 'Mapping found coming from source Natural Key, NOT NULL', --Natural Key, Used to Populate PK MemberInsuranceAgreementID in BDM
InternalCompanyCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, Used to Populate PK MemberInsuranceAgreementID/GroupInsuranceAgreementID in BDM
InsuranceAgreementTypeCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to Individual Certificate NOT NULL', --Natural Key, Used to Populate PK MemberInsuranceAgreementID in BDM
ProductCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, Used to Populate PK ProductCoverageID in BDM
GroupInsuranceAgreementNumber VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, Used to Populate PK GroupInsuranceAgreementID in BDM
GroupInsuranceAgreementTypeCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to Group Certificate NOT NULL', --Natural Key, Used to Populate PK GroupInsuranceAgreementID in BDM
MemberInsuranceAgreementCoverageEffectiveDate TIMESTAMP COMMENT 'Mapping found coming from source, NOT NULL',
MemberInsuranceAgreementCoverageEndDate TIMESTAMP COMMENT 'Mapping found coming from source, NOT NULL',
AnnualPremiumAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
MemberInsuranceAgreementCoverageStatusCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
RequestedCoverageBenefitAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
CoverageTypeCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
MemberInsuranceAgreementCoverageTerminationReasonCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
BillFrequencyPremiumAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
AnnualizedPremiumAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
PremiumPaidToDate DATE COMMENT 'Mapping found coming from source, NOT NULL',
TaxStatusCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
SubAccountNumber VARCHAR(100) COMMENT 'Mapping found coming from source, NOT NULL',
MemberCoveragePortedIndicator CHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
PremiumPaidInAdvanceMonthCount SMALLINT COMMENT 'No Mapping, Hardcoded to 0 NOT NULL',
WaiverOfPremiumCoverageIndicator CHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
PayrollDeductionAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
PremiumPaidToDateAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
MemberInsuranceAgreementCoverageStatusChangeDateTime TIMESTAMP COMMENT 'No Mapping, Hardcoded to 1900-01-01 NOT NULL',
OutOfForceIndicator CHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
InitialAnnualPremiumAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
ApprovedCoverageBenefitAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
SourceSystemCode VARCHAR(20) COMMENT 'Not coming from source, Hardcoded to GNL NOT NULL',
LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (MemberInsuranceAgreementNumber,InternalCompanyCode,InsuranceAgreementTypeCode,ProductCode,MemberInsuranceAgreementCoverageEffectiveDate) INTO 128 BUCKETS
STORED AS ORC;