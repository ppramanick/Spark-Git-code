CREATE TABLE ${WORK_DATABASE}.PMCPartyBankAccount
(
  NPN STRING COMMENT 'Natural Key, Mapping Found not coming from source, NOT NULL',
  BankRoutingNumber INT COMMENT 'Natural Key, Mapping Found coming from source, NOT NULL',
  BankAccountNumber INT COMMENT 'Natural Key, Mapping Found coming from source, NOT NULL',
  BankName VARCHAR(100) COMMENT 'Mapping Found coming from source, NOT NULL',
  BankAccountType VARCHAR(50) COMMENT 'Mapping Found not coming from source, NOT NULL',
  BankAccountSequenceNumber SMALLINT COMMENT 'Mapping Found coming from source, NOT NULL',
  CurrentRecordIndicator CHAR(1) COMMENT 'Mapping Found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(20) COMMENT 'Mapping Found coming from source, NOT NULL',
  LogicalDeleteIndicator CHAR(1) COMMENT 'Mapping Found coming from source, NOT NULL',
  EFTFromDate DATE COMMENT 'Mapping Found not coming from source,HardCoded to 1900-01-01, NOT NULL',
  EFTToDate DATE COMMENT 'Mapping Found not coming from source,HardCoded to 1900-01-01, NOT NULL',
  AddressLine1 VARCHAR(250) COMMENT 'Mapping Found not coming from source, NOT NULL',
  AddressLine2 VARCHAR(250) COMMENT 'Mapping Found not coming from source, NOT NULL',
  AddressLine3 VARCHAR(250) COMMENT 'Mapping Found coming from source, NOT NULL',
  AddressCityName VARCHAR(250) COMMENT 'Mapping Found not coming from source, NOT NULL',
  AddressPostalCode VARCHAR(20) COMMENT 'Mapping Found not coming from source, NOT NULL',
  StateCode VARCHAR(50) COMMENT 'Mapping Found not coming from source, NOT NULL',
  CountryCode VARCHAR(50) COMMENT 'Mapping Found not coming from source, NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Mapping Found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping Found coming from source, NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No Mapping Hive Updated time Not null',
  hashcode STRING COMMENT 'No Mapping Hash Code of all valid columns NOT NULL'
)
CLUSTERED BY (BankRoutingNumber, BankAccountNumber) INTO 16 BUCKETS
STORED AS ORC;

