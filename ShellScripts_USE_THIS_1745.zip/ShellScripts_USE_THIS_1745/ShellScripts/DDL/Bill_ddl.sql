CREATE TABLE ${WORK_DATABASE}.Bill
(
  --BillID BIGINT NOT NULL,
  BillNumber VARCHAR(50) COMMENT 'Natural Key, Mapping Coming from source NOT NULL',
  InvoiceNumber VARCHAR(10) COMMENT 'Natural Key, Mapping Coming from source NOT NULL',
  BillDueDate TIMESTAMP COMMENT 'Mapping Coming from source NOT NULL',
  BillDueAmount DECIMAL(18,2) COMMENT 'Mapping Coming from source NOT NULL',
  BillCreationDate TIMESTAMP COMMENT 'Mapping Coming from source NOT NULL',
  BillScheduleDate TIMESTAMP COMMENT 'Default to 1900-01-01 NOT NULL',
  BillEffectiveFromDate TIMESTAMP COMMENT 'Default to 1900-01-01 NOT NULL',
  BillEffectiveToDate TIMESTAMP COMMENT 'Default to 9999-12-31 NOT NULL',
  BillCancelledFlag VARCHAR(1) COMMENT 'Default to - NOT NULL',
  BillCancellationDate TIMESTAMP COMMENT 'Default to 1900-01-01 NOT NULL',
  BillIsRebillFlag CHAR(1) COMMENT 'Default to - NOT NULL',
  BillIsFinalFlag CHAR(1) COMMENT 'Default to - NOT NULL',
  BillAmount DECIMAL(15,2) COMMENT 'Mapping Coming from source NOT NULL',
  BillPaidAmount DECIMAL(15,2) COMMENT 'Default to 0 NOT NULL',
  BillCreditAppliedFlag CHAR(1) COMMENT 'Default to 0 NOT NULL',
  BillWriteoffFlag CHAR(1) COMMENT 'Default to - NOT NULL',
  BillStatusCode VARCHAR(50) COMMENT 'Default to - NOT NULL',
  SubAccountNumber VARCHAR(100) COMMENT 'Mapping Coming from source NOT NULL',
  GroupInsuranceAgreementNumber VARCHAR(40) COMMENT 'Mapping Coming from source NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'System Generated NOT NULL',
  CurrentRecordIndicator CHAR(1) COMMENT 'Mapping Coming from source NOT NULL',
  SourceSystemCode VARCHAR(20) COMMENT 'Default to Genelco for RDM NOT NULL',
  LogicalDeleteIndicator CHAR(1) COMMENT 'Mapping from source NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'System Generated NOT NULL',
  --LastUpdateProcessID VARCHAR(50) COMMENT 'Default to - for RDM NOT NULL',
  ContributionBillingTypeCode VARCHAR(50) COMMENT 'Default to - for RDM NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'Hive Update time Not Null',
  hashcode STRING COMMENT 'Full Row hash for CDC'
)
CLUSTERED BY(BillNumber) INTO 128 BUCKETS
STORED AS ORC;

