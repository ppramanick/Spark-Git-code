CREATE TABLE ${WORK_DATABASE}.AccountTransaction(
  --AccountTransactionID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
  InternalCompanyCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  TransactionNumber VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  AccountTransactionTypeCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  TransactionPostingTimestamp TIMESTAMP COMMENT 'Mapping found coming from source, NOT NULL',
  TransactionAmount DECIMAL(11,2) COMMENT 'Mapping found coming from source, NOT NULL',
  AccountTransactionCreationUserID VARCHAR(20) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to Genelco NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (SourceSystemCode,InternalCompanyCode,TransactionNumber,AccountTransactionTypeCode) INTO 128 BUCKETS
STORED AS ORC;