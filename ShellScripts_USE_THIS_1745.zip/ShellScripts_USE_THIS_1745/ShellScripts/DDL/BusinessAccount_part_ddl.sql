SET hive.exec.dynamic.partition.mode = nonstrict;
CREATE TABLE ${WORK_DATABASE}.BusinessAccount
(
  --BusinessAccountID BIGINT NOT NULL,
  BusinessAccountOwningPartyIDGrp VARCHAR(10) COMMENT 'Natural Key', ---OWNING PARTY
  BusinessAccountOwningPartyIDAcct DECIMAL(5,0) COMMENT 'Natural Key',---OWNING PARTY
  BusinessAccountOwningPartyIDSSN VARCHAR(10) COMMENT 'Natural Key',---OWNING PARTY
  InternalCompanyCode VARCHAR(50),
  BusinessAccountNumber VARCHAR(50) COMMENT 'Natural Key Not Null',
  BusinessAccountCreateDate TIMESTAMP,
  BusinessAccountTypeCode VARCHAR(50),
  BusinessAccountBalanceAmount DECIMAL(11,2),
  BusinessAccountSuspendedBalanceAmount DECIMAL(11,2),
  CurrentRecordIndicator VARCHAR(1),
  SourceSystemCode VARCHAR(20),
  LogicalDeleteIndicator VARCHAR(1),
  LastUpdateUserID VARCHAR(20),
  LastUpdateDateTime TIMESTAMP,
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No Mapping Hive Updated time Not null',
  hashcode STRING COMMENT 'No Mapping Hash Code of all valid columns NOT NULL'
)
PARTITIONED BY (scd_flag boolean)

STORED AS ORC;
