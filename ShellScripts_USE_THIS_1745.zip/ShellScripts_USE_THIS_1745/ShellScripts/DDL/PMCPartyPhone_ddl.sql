CREATE TABLE ${WORK_DATABASE}.PMCPartyPhone
(
  --PartyID BIGINT NOT NULL,
  NPN STRING COMMENT 'Natural Key, NOT NULL',
  PhoneTypeCode VARCHAR(50) COMMENT 'Natural Key, Mapping Found not coming from source, NOT NULL',
  PreferredPhoneTypeFlag CHAR(1) COMMENT 'Mapping Found not coming from source, NOT NULL',
  PhoneNumber VARCHAR(50) COMMENT 'Mapping Found not coming from source, NOT NULL',
  PhoneExtension VARCHAR(10) COMMENT 'Mapping Found coming from source, NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Mapping Found not coming from source, NOT NULL',
  CurrentRecordIndicator CHAR(1) COMMENT 'Mapping Found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(20) COMMENT 'Mapping Found coming from source, NOT NULL',
  LogicalDeleteIndicator CHAR(1) COMMENT 'Mapping Found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping Found coming from source, NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, Time stamp NOT NULL',
  hashcode STRING COMMENT 'No mapping, Time stamp NOT NULL'
)
CLUSTERED BY (NPN,PhoneTypeCode) INTO 16 BUCKETS
STORED AS ORC;