-- Meta
DROP TABLE IF EXISTS dev_meta.auditTarget;
CREATE EXTERNAL TABLE dev_meta.auditTarget(
  key String
  ,CoreToPublishStartDateTime Timestamp COMMENT 'Date and Time that the Process that copies the Core Zone Data to the Publish Zone Started'
  ,CoreToPublishEndDateTime Timestamp COMMENT 'Date and Time that the Process that copies the Core Zone Data to the Publish Zone Ended'
  ,CoreProcessName Varchar(256) COMMENT 'Name of the Process that copies the Source Data into the Core Zone'
  ,PublishTotalNumberOfRows BigInt COMMENT 'Total Number of Rows Copied into the Publish Zone Table, Could be used to compare to CoreTotalNumberOfRows'
  ,CoreTotalNumberOfRows BigInt COMMENT 'Total Number of Rows Copied into the Core Zone Table, Could be used to compare to PublishTotalNumberOfRows'
  ,CoreFailureRows BigInt COMMENT 'Total Number of Rows that Failed in the Core Zone Process'
  ,WorkTotalNumberOfRows BigInt COMMENT 'Total Number of Rows Copied into the Work Zone Publish Formatted Table'
  ,WorkProcessStartDateTime Timestamp COMMENT 'Date and Time that the Work Process Started'
  ,WorkProcessEndDateTime Timestamp COMMENT 'Date and Time that the Work Process Ended'
  ,WorkProcessRunTimeMs BigInt COMMENT 'Total Work runtime in ms'
  ,WorkValidationStartDateTime Timestamp COMMENT 'Date and Time that the Work Zone Validation Process Started'
  ,WorkValidationEndDateTime Timestamp COMMENT 'Date and Time that the Work Zone Validation Process Ended'
  ,WorkMappingStartDateTime Timestamp COMMENT 'Date and Time that the Work Zone Mapping Process Started'
  ,WorkMappingEndDateTime Timestamp COMMENT 'Date and Time that the Work Zone Mapping Process Ended'
  ,WorkMappingRunTimeMs Bigint COMMENT 'Total Work Mapping / Transformation runtime in ms'
  ,WorkCDCStartDateTime Timestamp COMMENT 'Date and Time that the Work Zone Change Data Capture (CDC) Process Started'
  ,WorkCDCStartEndDateTime Timestamp COMMENT 'Date and Time that the Work Zone Change Data Capture (CDC) Process Ended'
  ,WorkCDCRunTimeMs Bigint COMMENT 'Total CDC Work to Core runtime in ms'
  ,PublishDatabaseName String COMMENT 'Database Name in the Publish Zone where Work Zone Data is copied to'
  ,PublishTableName Varchar(256) COMMENT 'Table Name in the Publish Zone where Work Zone Data is copied to'
  ,CoreDatabaseName String COMMENT 'Database Name in the Core Zone where Core Zone Data is copied to'
  ,CoreTableName Varchar(256) COMMENT 'Table Name in the Core Zone where Core Zone Data is copied to'
  ,WorkDatabaseName String COMMENT 'Database Name in the Work Zone where Staging Data and Landing Zone Data is copied to'
  ,WorkTableName Varchar(256) COMMENT 'Table Name in the Work Zone where Staging Data and Landing Zone Data is copied to'
  ,WorkValidationProcessName Varchar(256) COMMENT 'Name of the Process that Validates the Work Zone Source System Formatted Table Data'
  ,WorkMappingProcessName Varchar(256) COMMENT 'Name of the Process that Maps the Source Formatted Data in the Work Zone Table into the Corresponding Publish Table Format in the Work Zone'
  ,WorkCDCProcessName Varchar(256) COMMENT 'Name of the Process that performs the Change Data Capture (CDC) processing on the Publish Table Formatted Data in the Work Zone by Reading the History Data in the Core Zone'
  ,WorkToCoreProcessName Varchar(256) COMMENT 'Name of the Process that copies the Work Data into the Core Zone'
  ,CoreToPublishProcessName Varchar(256) COMMENT 'Name of the Process that copies the Core Data into the Publish Zone'
  ,WorkProcessUserId String COMMENT 'UserId of the user running the Work Transform process'
  ,PublishProcessUserId String COMMENT 'New'
  ,CoreToPublishRunTimeInMs BigInt COMMENT 'New'
  ,WorkToPubValidationRunTimeInMs Bigint COMMENT 'Total time for verification in ms'
)
STORED BY 'org.apache.hadoop.hive.hbase.HBaseStorageHandler'
WITH SERDEPROPERTIES ("hbase.columns.mapping" = "
  :key
,cf:corePubSDt
,cf:corePubEDt
,cf:coreProc
,cf:pubTot
,cf:coreTot
,cf:coreFailTot
,cf:wrkTot
,cf:wrkSDt
,cf:wrkEDt
,cf:wrkRt
,cf:wrkValSDt
,cf:wrkValEDt
,cf:wrkTranSDt
,cf:wrkTranEDt
,cf:wrkTranRt
,cf:wrkCdcSDt
,cf:wrkCdcEDt
,cf:wrkCdcRt
,cf:pubDb
,cf:pubTbl
,cf:coreDb
,cf:coreTbl
,cf:wrkDb
,cf:wrkTbl
,cf:wrkValProcss
,cf:wrkTranProc
,cf:wrkCdcProc
,cf:wrkCorePrc
,cf:corePubProc
,cf:wrkCoreId
,cf:corePubId
,cf:corePubRt
,cf:wrkPubValRt
")
TBLPROPERTIES ('hbase.table.name' = 'audit');
