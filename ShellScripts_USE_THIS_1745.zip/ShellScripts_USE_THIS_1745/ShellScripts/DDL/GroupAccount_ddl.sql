CREATE TABLE ${WORK_DATABASE}.groupaccount
(
  --AccountID BIGINT NOT NULL,
  SourceGNLGroupAccountNumber VARCHAR(20)  COMMENT 'Mapping found Coming from source, NOT NULL',
  InternalCompanyCode VARCHAR(50) COMMENT 'Mapping Coming from Source',
  AccountStatusCode VARCHAR(50) COMMENT 'Mapping Not Coming from source Default to -, NOT NULL',
  AccountEstablishedDate DATE COMMENT 'No mapping, FORMAT yyyy/mm/dd Default to 9999-12-31, NOT NULL',
  AccountTerminationReasonCode VARCHAR(50) COMMENT 'No Mapping Default to -, NOT NULL',
  AccountTypeCode VARCHAR(50) COMMENT 'No mapping Default to -, NOT NULL',
  AccountTerminationDate DATE  COMMENT 'No mapping Default to 9999-12-31, FORMAT yyyy/mm/dd NOT NULL',
  SourceGNLAccountNumber INT COMMENT 'Mapping Coming from source, Natural key NOT NULL',
  OperatesinAllStatesIndicator VARCHAR(1) COMMENT 'No Mapping Default to Y, NOT NULL',
  CurrentRecordIndicator CHAR(1) COMMENT 'Mapping Coming from source NOT NULL',
  SourceSystemCode VARCHAR(20) COMMENT 'Mapping Not Coming from source, Default to GNL NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping Coming from source NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping Not Coming from source, Default Hadoop user VID NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'No mapping NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No Mapping Hive Updated time Not null',
  hashcode STRING COMMENT 'No Mapping Hash Code of all valid columns NOT NULL'
)
CLUSTERED BY (SourceGNLAccountNumber, SourceGNLGroupAccountNumber) INTO 128 BUCKETS
STORED AS ORC;