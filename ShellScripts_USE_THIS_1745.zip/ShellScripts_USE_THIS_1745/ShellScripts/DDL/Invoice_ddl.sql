CREATE TABLE ${WORK_DATABASE}.Invoice(
--InvoiceID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
InvoiceNumber VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
InvoiceEffectiveDate TIMESTAMP COMMENT 'Not coming from source, Hardcoded to 1900-01-01 NOT NULL',
InvoiceDueDate TIMESTAMP COMMENT 'Mapping found coming from source, NOT NULL',
InvoiceDueAmount DECIMAL(18,2) COMMENT 'Mapping found coming from source, NOT NULL',
InvoiceCreationDate TIMESTAMP COMMENT 'Mapping found coming from source, NOT NULL',
InvoiceScheduleDate TIMESTAMP COMMENT 'Not coming from source, Hardcoded to 1900-01-01 NOT NULL',
InvoiceCancelledFlag CHAR(1) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
InvoiceCancellationDate TIMESTAMP COMMENT 'Not coming from source, Hardcoded to 1900-01-01 NOT NULL',
InvoiceCurrencyCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
InvoiceAmount DECIMAL(15,2) COMMENT 'Mapping found coming from source, NOT NULL',
InvoiceCreditAppliedFlag CHAR(1) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
InvoiceStatusCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to Genelco NOT NULL',
LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (InvoiceNumber,SourceSystemCode) INTO 128 BUCKETS
STORED AS ORC;