CREATE TABLE ${WORK_DATABASE}.Claim(
--ClaimID BIGINT COMMENT 'No mapping, sequence to be generated in BDM NOT NULL',
--MemberInsuranceAgreementID BIGINT COMMENT 'No Mapping, needs lookup in BDM, NOT NULL'
--CoveredPartyID BIGINT COMMENT 'No Mapping, needs lookup in BDM, NOT NULL'
ClaimNumber VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, Used to Populate PK ClaimID in BDM
SourceGNLGroupNumber VARCHAR(20) COMMENT 'Mapping found coming from source, NOT NULL',
SourceGNLParticipantID VARCHAR(20) COMMENT 'Mapping found coming from source, NOT NULL',
SourceGNLDependentSequenceNumber INT COMMENT 'Mapping found coming from source, NOT NULL',
MemberInsuranceAgreementNumber VARCHAR(40) COMMENT 'Mapping found coming from source, NOT NULL',
ClaimCreationDateTime TIMESTAMP COMMENT 'No Mapping, Hardcoded to 1900-01-01 NOT NULL',
ClaimIncurredDate TIMESTAMP COMMENT 'No Mapping, Hardcoded to 1900-01-01 NOT NULL',
ClaimTotalBenefitAmount DECIMAL(18,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
ClaimCloseDate TIMESTAMP COMMENT 'Mapping found coming from source, NOT NULL',
ClaimExaminerEmployeeNumber VARCHAR(10) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
ClaimApproverEmployeeNumber VARCHAR(10) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
ClaimNoteText VARCHAR(500) COMMENT 'Mapping found coming from source, NOT NULL',
ClaimReceivedDate DATE COMMENT 'Mapping found coming from source, NOT NULL',
ClaimDecisionCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
ClaimStatusReasonCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
ClaimStatusTypeCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
ClaimStatusDate DATE COMMENT 'No Mapping, Hardcoded to 1900-01-01 NOT NULL',
BenefitChargedNotCoveredAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
ClaimTreatmentDecisionReasonCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
ClaimOverPaymentAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL',
ClaimFeeAmount DECIMAL(11,2) COMMENT 'No Mapping, Hardcoded to 0.00 NOT NULL', -- column is not present in the STTM, but got confirmation from DA(Pooja)
ClaimFeeBudgetCenter VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL', -- column is not present in the STTM, but got confirmation from DA(Pooja)
LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to GNL NOT NULL',
LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (ClaimNumber) INTO 128 BUCKETS
STORED AS ORC;