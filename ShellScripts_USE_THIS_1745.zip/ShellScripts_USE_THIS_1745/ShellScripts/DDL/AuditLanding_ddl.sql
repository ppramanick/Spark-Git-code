-- Meta
DROP TABLE IF EXISTS dev_meta.auditLanding;
CREATE EXTERNAL TABLE dev_meta.auditLanding(
  key String
  ,SourceFileSize BigInt COMMENT 'File Size of the Source File (obtained from the Source System)'
  ,LandingFileSize BigInt COMMENT 'File Size of the Landing File after being copied to the Landing Zone'
  ,LandingFileHashTotal String COMMENT 'File Hash Total of the Landing File after being copied to the Landing Zone'
  ,LandingProcessUserId String COMMENT 'Executing userid for landing process'
  ,LandingProcessRunTimeMs BigInt COMMENT 'Total landing runtime in ms'
  ,WorkTotalNumberOfRows BigInt COMMENT 'Total Number of Rows Copied into the Work Zone Publish Formatted Table'
  ,SourceFileDateTime Timestamp COMMENT 'Date and Time of the Source File (obtained from the Source System)'
  ,LandingProcessStartDateTime Timestamp COMMENT 'Date and Time that the Landing Process Started'
  ,LandingProcessEndDateTime Timestamp COMMENT 'Date and Time that the Landing Process Ended'
  ,LandingToArchiveStartDateTime Timestamp COMMENT 'Date and Time that the Process that copies the Source File to the Archive Zone Started'
  ,LandingToArchiveEndDateTime Timestamp COMMENT 'Date and Time that the Process that copies the Source File to the Archive Zone Ended'
  ,LandingToWorkStartDateTime Timestamp COMMENT 'Date and Time that the Process that copies the Source File to the Work Zone Started'
  ,LandingToWorkEndDateTime Timestamp COMMENT 'Date and Time that the Process that copies the Source File to the Work Zone Ended'
  ,LandingToWorkRunTimeMs BigInt COMMENT 'Total landing runtime in ms'
  ,WorkDatabaseName String COMMENT 'Database Name in the Work Zone where Staging Data and Landing Zone Data is copied to'
  ,WorkTableName Varchar(256) COMMENT 'Table Name in the Work Zone where Staging Data and Landing Zone Data is copied to'
  ,LandingFileName Varchar(256) COMMENT 'File Name of the Landing File after being copied to the Landing Zone'
  ,LandingFileLocation Varchar(256) COMMENT 'File Directory Name of the Landing File after being copied to the Landing Zone'
  ,LandingProcessName Varchar(256) COMMENT 'Name of the Process that copies the Source File to the Landing Zone'
  ,LandingToArchiveProcessName Varchar(256) COMMENT 'Name of the Process that copies the Source File to the Archive Zone'
  ,LandingToWorkProcessName Varchar(256) COMMENT 'Name of the Process that copies the Source File to the Work Zone'
  ,LandingToWorkValidationRunTimeInMs Bigint COMMENT 'Total time for verification in ms'
  ,LandingMismatchRatio DOUBLE
)
STORED BY 'org.apache.hadoop.hive.hbase.HBaseStorageHandler'
WITH SERDEPROPERTIES ("hbase.columns.mapping" = "
  :key
  ,cf:srcSize
  ,cf:lanSize
  ,cf:lanHash
  ,cf:lanId
  ,cf:lanRt
  ,cf:wrkTot
  ,cf:srcFDt
  ,cf:lanSDt
  ,cf:lanEDt
  ,cf:lanArcSDt
  ,cf:lanArcSEt
  ,cf:lanWrkSDt
  ,cf:lanWrkEDt
  ,cf:lanWrkRt
  ,cf:wrkDb
  ,cf:wrkTbl
  ,cf:lanFile
  ,cf:lanFLoc
  ,cf:lanProc
  ,cf:lanArcProc
  ,cf:lanWrkProc
  ,cf:lanWrkValRt
  ,cf:lanMmRat
")
TBLPROPERTIES ('hbase.table.name' = 'audit');
