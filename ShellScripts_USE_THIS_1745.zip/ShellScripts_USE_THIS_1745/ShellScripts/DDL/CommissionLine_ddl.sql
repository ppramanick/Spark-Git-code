CREATE TABLE ${WORK_DATABASE}.CommissionLine
(
  NPN VARCHAR(20) COMMENT 'Mapping found coming from source, NOT NULL',
  DepositNumber VARCHAR(20) COMMENT 'Mapping found coming from source, NOT NULL',
  StatementDate DATE COMMENT 'Mapping found coming from source, NOT NULL',
  ProducerWritingNumber VARCHAR(10) COMMENT 'Mapping found coming from source, NOT NULL',
  InternalCompanyCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  InsuranceAgreementNumber VARCHAR(40) COMMENT 'Mapping found coming from source, NOT NULL',
  MemberInsuranceAgreementCoverageEffectiveDate DATE COMMENT 'Mapping found coming from source, NOT NULL',
  ProducerRoleTypeCode VARCHAR(100) COMMENT 'Mapping found coming from source, NOT NULL',
  CommissionLinesAdjustmentFlag CHAR(1) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  CommissionLineReversalDate TIMESTAMP COMMENT 'Not coming from source, Hardcoded to 1900-01-01 00:00:00 NOT NULL',
  CommissionBaseRate DECIMAL(8,5) COMMENT 'Mapping found coming from source, NOT NULL',
  CommissionPaidAmount DECIMAL(18,2) COMMENT 'Mapping found coming from source, NOT NULL',
  CommissionPaymentReasonTypeCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  CommissionPaymentDistributionTypeCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  CommissionablePremiumAmount DECIMAL(11,2) COMMENT 'Mapping found coming from source, NOT NULL',
  EarnedCommissionAmount DECIMAL(11,2) COMMENT 'Mapping found coming from source, NOT NULL',
  AdvanceCommissionPaidAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0 NOT NULL',
  FederalTaxWithheldAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0 NOT NULL',
  StateTaxWithheldAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0 NOT NULL',
  CommissionPaidInAdvanceMonthCount INT COMMENT 'Mapping found coming from source, NOT NULL',
  CommissionType VARCHAR(100) COMMENT 'Mapping found coming from source, NOT NULL',
  FirstYearCommissionIndicator CHAR(1) COMMENT 'Not coming from source, Hardcoded to Y NOT NULL',
  CommissionPaidFromPremiumDate TIMESTAMP COMMENT 'Not coming from source, Hardcoded to 1900-01-01 00:00:00 NOT NULL',
  CommissionPaidToPremiumDate TIMESTAMP COMMENT 'Not coming from source, Hardcoded to 9999-12-31 23:59:59 NOT NULL', --check with DAs
  CommissionTransactionTypeCode VARCHAR(50) COMMENT 'Not coming from source, Hardcoded to - NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to PMC NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (ProducerWritingNumber,InternalCompanyCode,MemberInsuranceAgreementCoverageEffectiveDate,ProducerRoleTypeCode,InsuranceAgreementNumber) INTO 128 BUCKETS
STORED AS ORC;
