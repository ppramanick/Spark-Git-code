-- Create core table 
CREATE TABLE IF NOT EXISTS ${CORE_DATABASE}.${TABLE} LIKE ${WORK_DATABASE}.${TABLE};
-- Add missing columns
ALTER TABLE ${CORE_DATABASE}.${TABLE} ADD COLUMNS (start_date timestamp, end_date timestamp, scd_flag boolean);



-- Mitigates Beeline Bug
SELECT * FROM ${CORE_DATABASE}.${TABLE} WHERE 1=0 LIMIT 1;

