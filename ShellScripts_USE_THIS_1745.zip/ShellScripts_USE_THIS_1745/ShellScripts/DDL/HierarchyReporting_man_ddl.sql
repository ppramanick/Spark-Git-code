CREATE TABLE ${DATABASE}.${TABLE}
(
  ArrangementCode STRING,
  AgentCode STRING,
  StartDate String COMMENT 'Parse to Date',
  EndDate String COMMENT 'Parse to Date',
  IsPrimary INT,
  ContractName STRING,
  ContractStartDate String COMMENT 'Parse to Date',
  ContractEndDate String COMMENT 'Parse to Date',
  CarrierShortName STRING,
  Channel STRING,
  Role STRING,
  ApplyAdvance INT,
  RAAgentCode STRING,
  RAArrangementCode STRING,
  FieldOfficeName STRING,
  WritingNumbers STRING
)
CLUSTERED BY (ArrangementCode,AgentCode) INTO 16 BUCKETS
STORED AS ORC;