CREATE EXTERNAL TABLE ${DATABASE}.${TABLE}
(
  DisbursementNumber BIGINT -- PK
  ,FullName STRING
  ,Address1Text STRING
  ,Address2Text STRING
  ,CityName STRING
  ,StateCode STRING
  ,ZipCode STRING
  ,PaymentDateText STRING
  ,CheckTypeCode STRING
  ,IssueTypeCode STRING
  ,CommentsText STRING
  ,RefundDetailCode STRING
  ,CompanyCode STRING
  ,PaymentTypeCode STRING
  ,CheckNumber BIGINT
  ,ZCD_TRANS_ID BIGINT
  ,AmountText STRING
  ,DisbursementPaymentMethodCode STRING
  ,CurrencyCode STRING
  ,DisbursementAmount DOUBLE
  ,DisbursementRequestSourceSystemCode STRING
)
CLUSTERED BY (DisbursementNumber) INTO 16 BUCKETS
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION ${TBLPATH};