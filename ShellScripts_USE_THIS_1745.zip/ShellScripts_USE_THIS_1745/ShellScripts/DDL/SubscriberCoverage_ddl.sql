-- SubscriberCoverage
CREATE EXTERNAL TABLE ${DATABASE}.${TABLE}
(
  Title STRING     --Title such as Mr, Mrs, Miss of the subscriber (insured)
  ,FirstName STRING    --First name of the subscriber
  ,LastName STRING   --Last name of the subscriber
  ,Suffix STRING      --Suffix such as Jr, Sr
  ,EmployeeNumber STRING -- PK    --Unique code to identify the subscriber
  ,CustomerNumber STRING -- PK    --This is the Customer Number
  ,CustomerName STRING        --Customer/Account number
  ,CustomerBillGroup STRING     --Customer's Location where employee works
  ,Gender STRING            --Gender of the subscriber (F-Female,M-Male)
  ,SubscriberStatus STRING     --Status of the subscriber(Active/Inactive/Terminated/Pending)
  ,SubscriberStatusDate STRING    --Date from when the status is in effect
  ,CarrierCode STRING         --2500 for CAIC, 2200 for AFNY
  ,GroupPolicyNumber STRING     --Policy Number for the Group
  ,ProductCode STRING         --Product Code (VUE Product)
  ,ProductItemCode STRING       --Aflac Plan Code (VUE Product Item, dynamically created and stored in VUE)
  ,CertNumber STRING        -- PK--Cert Number
  ,EffectiveDate STRING       --Effective Date
  ,OriginalEffectiveDate STRING   --Original Effective Date
  ,CertStatus STRING         --Status of the Coverage(Active/Terminated/Pending)
  ,CertStatusDate STRING      --Date from when the status is in effect
  ,AppDate STRING           --Application Signed Date of the Cert
  ,IssuedDate STRING          --Date when the App/Cert is issued
  ,State STRING           --Situs State of the Subscriber
  ,CertificateSolicitationState STRING    --Certificate Solicitation State
  ,LocationofEnrollment STRING    --Location of enrollment
  ,SourceofApplication STRING   --Source of new business (Paper, eFile)
  ,EnrollmentMethod STRING     --Type of enrollment used for the given certificate (Producer Assisted, HR Enrolled)(Producer Assisted,HR Enrolled,Call Center,Internet or Self-Service)
  ,ArrangmentCode STRING       --Arrangement code tied to the cert. All the levels of Hierarchy can be obtained from the Arrangement feed listed above.
  ,CommissionType STRING       --Commission Type is to determine whether the agent/agency arrangement is applicable for commissions or for reporting hierarchy.
  ,AgentStartDate STRING      --Agent Start Date
  ,AgentEndDate STRING        --Agent End Date
  ,SplitPercentage DOUBLE      --
  ,AgentType STRING          --(Broker/Spit Agent/Variable Agent/Writing Agent )
  ,SigningAgentCode STRING      --(Signing Agent Writing Number)
  ,AnnualPremium DOUBLE
)
CLUSTERED BY (EmployeeNumber,CustomerNumber,CertNumber) INTO 16 BUCKETS
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY ','
--STORED AS TEXTFILE
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES (
   "separatorChar" = ",",
   "quoteChar"     = "\""
  )
STORED AS TEXTFILE
LOCATION ${TBLPATH};