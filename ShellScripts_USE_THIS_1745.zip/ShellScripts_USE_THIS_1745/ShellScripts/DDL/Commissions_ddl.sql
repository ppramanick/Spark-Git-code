-- Commissions
CREATE EXTERNAL TABLE ${DATABASE}.${TABLE}
(
  StatementDate STRING        --The date on which the statement is generated for the calculated commission in the carrier system 
  ,FromDate STRING          --The date from which the premiums are considered for commission calculation
  ,ToDate STRING            --The date to which the premiums are considered for commission calculation
  ,CarrierGroupCode INT       --Carrier Group Code is the code defined for the group of carriers. This is not required for Aflac and used only for MGA implementations
  ,CarrierCode STRING         --Carriers for which the commission is calculated. 2400 (Aflac)/2500 (CAIC)/2200 (AFNY)
  ,GroupProductNumber STRING      --Policy Number - this is the Group Product Number
  ,PolicyNumber STRING        --Cert Number
  ,GroupAccountNumber STRING      --GroupAccountNumber
  ,EffectiveDate STRING       --Effective date of the policy
  ,DepositNumber STRING   --(Previously it was BIGINT)--This is for MGA implementations and not required for Aflac
  ,DepositDate STRING         --This is for MGA implementations and not required for Aflac
  ,TransactionDate STRING       --Date on when the customer pays the premium
  ,PaidToDate STRING          --Date till the premium is paid.
  ,DueDate STRING           --Premium due date.
  ,Premium DOUBLE           --Premium Amount
  ,PremiumType STRING         --Types of premium such as "Excess Premium", "Target Premium". Not required for Aflac
  ,PaymentFrequency STRING      --Codes for Payment Frequency : A-Anually,Q-Quarterly,SA-Semi Annually,M-Monthly
  ,Months INT             --Premium amount months
  ,AdvanceMonths INT          --Advance months paid
  ,CommissionablePremium DOUBLE --(Previously it was String)    --Premium amount on which the commission need to be calculated after deduction of fee amounts
  ,CommissionRate DOUBLE --(Previously it was String)       --Rate on which the commission is paid
  ,Revenue DOUBLE           --Commission Amount
  ,EarnedCommission DOUBLE      --Earnoff commission amount if paid advance
  ,ProductItemCode STRING       --Product item code to identify the product item for the product
  ,CommissionType STRING        --To determine the commission type such as BASE or OVER
  ,TransactionCode STRING       --Transaction codes to determine the transaction such as AD','ADC','AM','BASE','BONUS','CB','CBR','CBT','FEE','FY','OVER'
  ,TransactionDesc STRING       --Description of the transaction
  ,PolicyYear INT           --which year policy
  ,State STRING           --Policy state
  ,ProductCode STRING         --Product code configured while defining the product
  ,ProductName STRING         --Name of the product
  ,AgentCode STRING         --Agent Code to uniquely identify the agent in the system
  ,AgentRole STRING         --Agent Role
  ,RAAgentCode STRING         --RA Agent Code
  ,SubscriberCount INT        --Count of subscribers under a group/account
  ,MemberCount INT          --Count of memebrs for all the subscribers of the account 
  ,InsuredFirstName STRING      --First Name of the subscriber
  ,InsuredLastName STRING     --Last Name of the subscriber
  ,InsuredMiddleName STRING     --Middle Name of the subscriber
  ,InsuredName STRING        --Full Name of the subscriber
  ,InsuredNumber STRING        --Subscriber number used to uniquely identify the record
  ,InsuredType STRING        --Individual/Group
  ,IsIndividual INT          --If the insured is individual or Group
  ,DOB STRING             --Date of birth of the subscriber
  ,InsuredStatus STRING        --status of the insured
  ,InsuredStatusDate STRING     --Date on when the insured status is set/modified
  ,WritingNumber STRING       --Agent writing number or cross reference # used to identify the agent record in other systems
  ,PolicyStatus STRING       --Status of the policy
  ,PolicyStatusDate STRING      --Date on when the policy status is set/modified
  ,PolicyStatusReason STRING    --Status reason of the policy
  ,PolicyStatusReasonDate STRING --Date on when the policy status reason is set/modified
  ,PolicyAppDate STRING       --The date on which the policy is applied for
  ,PolicyPaidToDate STRING     --Till when the premium is paid on the policy
  ,PolicyIssueAge INT       --Insured Age
  ,TrasactionSource STRING
)
CLUSTERED BY (StatementDate,AgentCode,InsuredNumber) INTO 16 BUCKETS
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY ','
--STORED AS TEXTFILE
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES (
   "separatorChar" = ",",
   "quoteChar"     = "\""
  )
STORED AS TEXTFILE
LOCATION ${TBLPATH};


