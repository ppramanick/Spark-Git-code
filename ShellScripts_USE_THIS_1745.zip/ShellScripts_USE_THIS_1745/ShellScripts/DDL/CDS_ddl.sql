CREATE EXTERNAL TABLE ${DATABASE}.${TABLE}
(
  DisbursementNumber STRING, 
  FullName STRING,
  Address1Text STRING,
  Address2Text STRING,
  CityName STRING,
  StateCode STRING,
  ZipCode STRING,
  PaymentDateText STRING,
  DisbursementCreationTime STRING COMMENT 'Added 2017-10-21',
  DisbursementCancelDate STRING COMMENT 'Added 2017-10-21',
  DisbursementCancelReason STRING COMMENT 'Added 2017-10-21',
  CheckTypeCode STRING,
  IssueTypeCode STRING,
  CommentsText STRING,
  RefundDetailCode STRING,
  CompanyCode STRING,
  PaymentTypeCode STRING,
  CheckNumber STRING,
  CheckStatus STRING,
  ZCD_TRANS_ID STRING,
  AmountText STRING,
  DisbursementPaymentMethodCode STRING,
  CurrencyCode STRING,
  DisbursementAmount STRING,
  DisbursementCashedDate STRING,
  ACHReturnCode STRING,
  DISBURSEDStatusCode STRING,
  DisbursementRequestSourceSystemCode STRING
)
CLUSTERED BY (DisbursementNumber,DisbursementRequestSourceSystemCode) INTO 16 BUCKETS
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION ${TBLPATH};