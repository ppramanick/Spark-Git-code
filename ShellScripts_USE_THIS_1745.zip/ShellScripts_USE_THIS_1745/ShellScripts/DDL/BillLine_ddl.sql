CREATE TABLE ${WORK_DATABASE}.BillLine
(
  AccountLineNumber STRING COMMENT 'Natural Key Not NUll',
  BillNumber STRING COMMENT 'Natural Key Not NUll',
  BillLineEffectiveDate TIMESTAMP COMMENT 'Not Null',
  BillLineEndDate TIMESTAMP COMMENT 'Not Null',
  BillLineIsAdjustmentIndicator VARCHAR(1) COMMENT 'Not Null',
  BillLineAmountWIthoutTax DECIMAL(11,2) COMMENT 'Not Null',
  BillLinePaidAmount DECIMAL(11,2) COMMENT 'Not Null',
  BillLineTransactionMonthStartDate TIMESTAMP COMMENT 'Not Null',
  BillLineReversalMonthStartDate TIMESTAMP COMMENT 'Not Null',
  BillLineUnAllocatedAmount DECIMAL(11,2) COMMENT 'Not Null',
  BillLineDayPriceAmount DECIMAL(11,2) COMMENT 'Not Null',
  BillLineGroupContributionAmount DECIMAL(11,2) COMMENT 'Not Null',
  BillLineDayPriceWithoutTaxAmount DECIMAL(11,2) COMMENT 'Not Null',
  BillLineGroupContributionWithoutTaxAmount DECIMAL(11,2) COMMENT 'Not Null',
  BillLineMemberContributionAmount DECIMAL(11,2) COMMENT 'Not Null',
  BIllLineMemberContributionWithoutTaxAmount DECIMAL(11,2) COMMENT 'Not Null',
  BillLineStatusCode VARCHAR(50) COMMENT 'Not Null',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Not Null',
  SourceSystemCode VARCHAR(20) COMMENT 'Not Null',
  LogicalDeleteIndicator CHAR(1) COMMENT 'Not Null',
  ProductCoverageID INT COMMENT 'Not Null',
  MemberInsuranceAgreementID BIGINT COMMENT 'Not Null',
  BillLineAmount DECIMAL(11,2) COMMENT 'Not Null',
  GroupInsuranceAgreementID BIGINT COMMENT 'Not Null',
  LastUpdateUserID VARCHAR(20) COMMENT 'Not Null',
  LastUpdateDateTime TIMESTAMP COMMENT 'Not Null',
  --LastUpdateProcessID VARCHAR(50) COMMENT 'Not Null',
  --RowInsertDateTime TIMESTAMP COMMENT 'Not Null',
  --RowUpdateDateTime TIMESTAMP COMMENT 'Not Null',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'Hive Update time Not Null',
  hashcode STRING COMMENT 'Full Row hash for CDC'
)
CLUSTERED BY (AccountLineNumber, BillNumber) INTO 128 BUCKETS
STORED AS ORC;

