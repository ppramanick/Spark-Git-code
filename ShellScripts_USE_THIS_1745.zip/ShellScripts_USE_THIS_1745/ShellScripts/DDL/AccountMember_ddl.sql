CREATE TABLE ${WORK_DATABASE}.AccountMember
(
  InternalCompanyCode VARCHAR(10) COMMENT 'Natural Key Not Null',
  MemberNumber VARCHAR(20) COMMENT 'Natural Key Not Null',
  EmployeeTotalWorkHoursPerWeek INT COMMENT 'Not Null',
  EmployeeJobTitle VARCHAR(100) COMMENT 'Not Null',
  EmployeeSalaryAmount DECIMAL(12,2) COMMENT 'Not Null',
  GroupNumber VARCHAR(10) COMMENT 'Natural Key Not Null',
  EmployeeTotalWorkDaysPerWeek INT COMMENT 'Not Null',
  EmployeeStatusCode VARCHAR(50) COMMENT 'Not Null',
  MemberWorkTypeCode VARCHAR(50) COMMENT 'Not Null',
  MemberEstablishedDate DATE COMMENT 'Not Null',
  MemberTerminationDate DATE COMMENT 'Not Null',
  MemberTerminationReasonCode VARCHAR(50) COMMENT 'Not Null',
  EmployeeDepartmentNumber VARCHAR(10) COMMENT 'Not Null',
  SmokerIndicator VARCHAR(1) COMMENT 'Not Null',
  HireDate DATE COMMENT 'Not Nul l',
  EmployeeDepartmentName VARCHAR(30)COMMENT 'Not Null',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Not Null',
  SourceSystemCode VARCHAR(20) COMMENT 'Not Null',
  LogicalDeleteIndicator CHAR(1) COMMENT 'Not Null',
  LastUpdateUserID VARCHAR(20) COMMENT 'Not Null',
  LastUpdateDateTime TIMESTAMP COMMENT 'Not Null',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (InternalCompanyCode, MemberNumber, GroupNumber) INTO 128 BUCKETS
STORED AS ORC;

