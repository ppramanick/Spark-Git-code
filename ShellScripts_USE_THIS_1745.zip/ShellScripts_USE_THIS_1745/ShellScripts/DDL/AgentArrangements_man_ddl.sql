-- AgentArrangements
CREATE TABLE ${DATABASE}.${TABLE}
(
  ArrangementCode STRING -- PK    --Arrangement Code which uniquely identifies the arrangement of the agent/agency. 
  ,AgentCode STRING -- PK     --Code which uniquely identifies the agent/agency. This will be the Agent NPN.  
  ,ARStartDate STRING COMMENT 'To be converted to DATE in Work'   --The date from when the agent arrangement is active
  ,AREndDate STRING COMMENT 'To be converted to DATE in Work'   --The date by when the agent arrangement is ended
  ,IsPrimary INT          --To determine whether the arrangement is primary or not(1-Yes,0-No)
  ,ContractName STRING      --Name of the contract to which the agent is associated
  ,ContractStartDate STRING   --The date from when the agent is associated with the contract
  ,ContractEndDate STRING   --Contract End Date
  ,CarrierShortName STRING    --Carriers for which the commission is calculated.2400 (Aflac)/2500 (CAIC)/2200 (AFNY)
  ,Channel STRING
  ,Role STRING        --Role name which is applicable for the agent contract and available under the agent contract channel
  ,ApplyAdvance INT     --To determine If the agent arrangement is applicable for advance or not(1-Yes,0-No)
  ,RAAgentCode STRING   --Reporting Authority Agent Code. This will be the Agent NPN.  
  ,RAArrangementCode STRING   --Reporting Authority Arrangement Code for the agent arranagement
  ,FieldOfficeName STRING   --This field will have the Market Field office name associated with the arrangement. Will be displayed as comma(,) Separated
  ,WritingNumbers STRING      --Wrting number associated with the Arrangement. If there are multiple writing numbers associated with the Arrangement, one Arrangement record for each writing number should be included in the extract. For example if there are 3 writing numbers associated to an Arrangement, this file should have 3 records for the same Arrangement.
)
CLUSTERED BY (ArrangementCode,AgentCode) INTO 16 BUCKETS
STORED AS ORC;

