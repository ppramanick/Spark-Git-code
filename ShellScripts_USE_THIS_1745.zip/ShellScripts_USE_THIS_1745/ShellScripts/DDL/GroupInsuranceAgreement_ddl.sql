CREATE TABLE ${WORK_DATABASE}.GroupInsuranceAgreement(
--GroupInsuranceAgreementID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
AccountNumber VARCHAR(10) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, Used to Populate PK GroupInsuranceAgreementID in BDM 
InsuranceAgreementNumber VARCHAR(10) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, Used to Populate PK GroupInsuranceAgreementID in BDM
InternalCompanyCode VARCHAR(10) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, Used to Populate PK GroupInsuranceAgreementID in BDM
InsuranceAgreementTypeCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to Group Certificate NOT NULL', --Natural Key, Used to Populate PK GroupInsuranceAgreementID in BDM
EligibleEmployeeCount INT COMMENT 'No Mapping, Hardcoded to 0 NOT NULL',
TotalEmployeeCount INT COMMENT 'No Mapping, Hardcoded to 0 NOT NULL',
IssuedParticipantCount INT COMMENT 'No Mapping, Hardcoded to 0 NOT NULL',
RequiredEmployeeParticipationPercentage DECIMAL(5,2) COMMENT 'No Mapping, Hardcoded to 0 NOT NULL',
GroupInsuranceAgreementTerminationReasonCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
GroupInsuranceAgreementModificationReasonCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
MaximumMonthsInvestigateandDenyClaimCount INT COMMENT 'No Mapping, Hardcoded to 0 NOT NULL',
LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to Genelco NOT NULL',
LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record' 
)
CLUSTERED BY (AccountNumber, InternalCompanyCode, InsuranceAgreementNumber) INTO 128 BUCKETS
STORED AS ORC;





