CREATE TABLE ${WORK_DATABASE}.ProductCoverage(
  --ProductCoverageID INT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
  EmployerPaidIndicator VARCHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  LineofBusinessCode VARCHAR(50) COMMENT 'Mapping found Coming from source, but needs RDM lookup NOT NULL',
  ProductSeriesCode VARCHAR(20) COMMENT 'Natural Key No Mapping, Hardcoded to - NOT NULL',
  ProductCoverageCode VARCHAR(30) COMMENT 'Natural Key Mapping found coming from source, NOT NULL',
  ProductCoverageDescription VARCHAR(100) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  CreationTimestamp TIMESTAMP COMMENT 'No Mapping, Hardcoded to 9999-12-31 NOT NULL',
  EffectiveDate TIMESTAMP COMMENT 'No Mapping, Hardcoded to 9999-12-31 NOT NULL',
  EndDate TIMESTAMP COMMENT 'No Mapping, Hardcoded to 9999-12-31 NOT NULL',
  DraftIndicator VARCHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  AuthorizedforAllStatesIndicator VARCHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  InternalCompanyCode VARCHAR(50) COMMENT 'Natural Key Mapping found coming from source, NOT NULL',
  CoverageTypeCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
  ProductSeriesVersionNumber SMALLINT COMMENT 'No Mapping, Hardcoded to 0 NOT NULL',
  ProductSeriesID INT COMMENT 'No Mapping, Hardcoded to 0 NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to GNL NOT NULL',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (ProductCoverageCode) INTO 128 BUCKETS
STORED AS ORC;