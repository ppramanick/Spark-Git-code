CREATE TABLE ${WORK_DATABASE}.MemberInsuranceAgreementCoverageProducer 
(
  FieldOfficeName VARCHAR(50) COMMENT 'Newly mapped column, NOT NULL',
  MemberInsuranceAgreementCoverageEffectiveDate TIMESTAMP COMMENT 'Mapping found coming from source, NOT NULL',
  ProducerRoleTypeCode VARCHAR(50) COMMENT 'Mapping found coming from source,NOT NULL',
  ProducerWritingNumber VARCHAR(10) COMMENT 'Mapping found coming from source, NOT NULL',
  InternalCompanyCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  CommissionSplitPercentage DECIMAL(6,3) COMMENT 'Mapping found coming from source, NOT NULL',
  CertNumber VARCHAR(50) COMMENT 'Mapping from source, NOT NULL',
  ProducerHierarchyTypeCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  SalesChannelCode VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL',
  CurrentRecordIndicator CHAR(1) COMMENT 'Mapping found not coming from source, NOT NULL',
  SourceSystemCode VARCHAR(20) COMMENT 'Mapping found not coming from source, NOT NULL',
  LogicalDeleteIndicator CHAR(1) COMMENT 'Mapping found not coming from source, NOT NULL',
  LastUpdateDateTime TIMESTAMP COMMENT 'Mapping found not coming from source,NOT NULL',
  LastUpdateUserID VARCHAR(20) COMMENT 'Mapping found not coming from source, NOT NULL',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'System Generated NOT NULL',
  hashcode STRING COMMENT 'System Generated NOT NULL for CDC'
)
CLUSTERED BY (MemberInsuranceAgreementCoverageEffectiveDate, InternalCompanyCode, ProducerRoleTypeCode, ProducerWritingNumber) INTO 32 BUCKETS
STORED AS ORC;