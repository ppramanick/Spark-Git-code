CREATE TABLE ${WORK_DATABASE}.Payment(
--PaymentID BIGINT COMMENT 'No mapping, sequence to be generated in BDM NOT NULL',
PaymentMethodTypeCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
BankReceivedDate DATE COMMENT 'No Mapping, Hardcoded to 1900-01-01 NOT NULL',
PaymentReceivedDate DATE COMMENT 'Mapping found coming from source, NOT NULL',
PaymentCanceledIndicator CHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
PaymentCancelDate DATE COMMENT 'No Mapping, Hardcoded to 1900-01-01 NOT NULL',
PaymentCancelReasonCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
PaymentAmount DECIMAL(11,2) COMMENT 'Mapping found coming from source, NOT NULL',
PaymentMethodNumber VARCHAR(20) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
PaymentCleanIndicator CHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
PaymentNumber VARCHAR(20) COMMENT 'Mapping coming from source NATURAL KEY, NOT NULL',
PaymentReceiptNumber VARCHAR(20) COMMENT 'No Mapping, Hardcoded to - NOT NULL',
InitialPaymentIndicator CHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL', --Column missing in STTM, but got confirmation from DA(Pooja)
AccountOwnerPartyID BIGINT COMMENT 'No Mapping, Hardcoded to 0 NOT NULL', --Column missing in STTM, but got confirmation from DA(Pooja)
PaymentBatchID VARCHAR(100) COMMENT 'No Mapping, Hardcoded to - NOT NULL', --Column missing in STTM, but got confirmation from DA(Pooja)
PaymentBatchGroupingID VARCHAR(255) COMMENT 'No Mapping, Hardcoded to - NOT NULL', --Column missing in STTM, but got confirmation from DA(Pooja)
PaymentChannelCode VARCHAR(50) COMMENT 'No Mapping, Hardcoded to - NOT NULL', --Column missing in STTM, but got confirmation from DA(Pooja)
ProcessedAsPaidandBilledIndicator CHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL', --Column missing in STTM, but got confirmation from DA(Pooja)
SubmittedAsPaidandBilledIndicator CHAR(1) COMMENT 'No Mapping, Hardcoded to - NOT NULL', --Column missing in STTM, but got confirmation from DA(Pooja)
LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp NOT NULL',
CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to GNL NOT NULL',
LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (PaymentNumber) INTO 128 BUCKETS
STORED AS ORC;