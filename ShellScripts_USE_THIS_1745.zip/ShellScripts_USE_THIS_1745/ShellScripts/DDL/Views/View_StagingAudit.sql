DROP VIEW dev_meta.StagingErrorAudit;
CREATE VIEW IF NOT EXISTS dev_meta.StagingErrorAudit AS
SELECT
a.key
,a.stagingtotalnumberofrows
,a.stagingvalidatedrows
,a.stagingfailurerows
,a.worktotalnumberofrows
,a.workvalidatedrows
,a.workfailurerows
,a.stagingprocessuserid
,a.stagingprocessstartdatetime
,a.stagingprocessenddatetime
,a.stagingprocessruntimems
,a.stagingvalidationstartdatetime
,a.stagingvalidationenddatetime
,a.stagingtoworkvalidationruntimeinms
,a.stagingtoarchivestartdatetime
,a.stagingtoarchiveenddatetime
,a.stagingtoarchiveruntimems
,a.stagingtoworkstartdatetime
,a.stagingtoworkenddatetime
,a.stagingtoworkruntimems
,a.workdatabasename
,a.worktablename
,a.stagingdatabasename
,a.stagingtablename
,a.sourcedatabasename
,a.sourcetablename
,a.sourcesystemname
,a.sourcelocationname
,a.sourcefilename
,a.stagingprocessname
,a.stagingvalidationprocessname
,a.stagingtoarchiveprocessname
,a.stagingtoworkprocessname
,a.workprocessname
,a.stagingtoworklastimport
,(a.stagingtoworkvalidationruntimeinms / a.stagingprocessruntimems) AS percentageRuntimeValidation
,(a.stagingtoworkruntimems / a.stagingprocessruntimems) AS percentageRuntimeCDC
,(a.stagingtoarchiveruntimems / a.stagingprocessruntimems) AS percentageRuntimeArchive
,((a.stagingprocessruntimems-a.stagingtoworkruntimems-a.stagingtoarchiveruntimems-a.stagingtoworkvalidationruntimeinms) / a.stagingprocessruntimems) AS percentageRuntimeMain
,e.key as errorkey
,e.datalakeingestionstartdatetime
,e.datalakeingestionfailuredatetime
,e.failurecode
,e.failuredescription
,e.failureprocessname
,e.failurezone
,e.yarnapplicationid
,e.failuresqlscript
,e.failuredatabase
,e.failuretable
,e.rowsaffected
,e.errorlevel
,e.failurelogfile
,e.failurelogmessage
,e.failuretimestampsaffectedtimestamp
FROM dev_meta.auditStaging a
LEFT OUTER JOIN dev_meta.errorLog e
ON (a.key = e.FailureAuditLinkKey)
WHERE a.stagingprocessuserid IS NOT NULL;
