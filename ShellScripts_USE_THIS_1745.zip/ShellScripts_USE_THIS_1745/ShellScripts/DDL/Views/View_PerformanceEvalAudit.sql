-- transform.sh
WITH avgs AS(
  SELECT 
  -- Total runtime
  avg(a.workprocessruntimems) as averageRuntime
  --,a.coretopublishruntimeinms
  --,a.totalRuntimeInMs
  --,a.workmappingruntimems
  --,a.workcdcruntimems
  --,a.worktopubvalidationruntimeinms
  -- Percentages
  ,avg(a.percentageruntimevalidation) as averageValidationPercentage
  ,avg(a.percentageruntimecdc) as averageCDCPercentage
  ,avg(a.percentageruntimemapping) as averageMappingPercentage
  ,avg(a.percentageruntimemain) as averageMainRuntime
  ,avg(a.coretotalnumberofrows) as avegerageRows
  ,COUNT(*) as sampleSize
  FROM dev_meta.targeterroraudit a
  WHERE coretopublishstartdatetime IS NOT NULL
)
SELECT av.*, (av.averageRuntime/av.avegerageRows) as RowsPerMs
FROM avgs av;

-- importCsvData.sh
WITH avgs AS(
  SELECT 
  -- Total runtime
  avg(a.landingprocessruntimems) as averageRuntime
  -- Percentages
  ,avg(a.percentageRuntimeValidation) as averageValidationPercentage
  ,avg(a.percentageRuntimeCDC) as averageCDCPercentage
  ,avg(a.percentageRuntimeMain) as averageMainRuntime
  ,avg(a.worktotalnumberofrows) as avegerageRows
  ,COUNT(*) as sampleSize
  FROM dev_meta.landingerroraudit a
  WHERE landingtoworkenddatetime IS NOT NULL
)
SELECT av.*, (av.averageRuntime/av.avegerageRows) as RowsPerMs
FROM avgs av;
