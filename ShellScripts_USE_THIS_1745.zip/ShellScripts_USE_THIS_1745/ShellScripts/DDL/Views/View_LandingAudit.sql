DROP VIEW dev_meta.LandingErrorAudit;
CREATE VIEW IF NOT EXISTS dev_meta.LandingErrorAudit AS
SELECT
a.key
,a.landingfilesize
,a.landingfilehashtotal
,a.landingprocessuserid
,a.landingprocessruntimems
,a.worktotalnumberofrows
,a.landingprocessstartdatetime
,a.landingprocessenddatetime
,a.landingtoworkstartdatetime
,a.landingtoworkenddatetime
,a.landingtoworkruntimems
,a.workdatabasename
,a.worktablename
,a.landingfilename
,a.landingfilelocation
,a.landingprocessname
,a.landingtoarchiveprocessname
,a.landingtoworkprocessname
,a.landingtoworkvalidationruntimeinms
,(a.landingtoworkvalidationruntimeinms / a.landingprocessruntimems) AS percentageRuntimeValidation
,(a.LandingToWorkRunTimeMs / a.landingprocessruntimems) AS percentageRuntimeCDC
,((a.landingprocessruntimems-a.LandingToWorkRunTimeMs-a.landingtoworkvalidationruntimeinms) / a.landingprocessruntimems) AS percentageRuntimeMain
,a.LandingMismatchRatio
,e.key as errorkey
,e.datalakeingestionstartdatetime
,e.datalakeingestionfailuredatetime
,e.failurecode
,e.failuredescription
,e.failureprocessname
,e.failurezone
,e.yarnapplicationid
,e.failuresqlscript
,e.failuredatabase
,e.failuretable
,e.rowsaffected
,e.errorlevel
,e.failurelogfile
,e.failurelogmessage
,e.failuretimestampsaffectedtimestamp
FROM dev_meta.auditLanding a
LEFT OUTER JOIN dev_meta.errorLog e
ON (a.key = e.FailureAuditLinkKey)
WHERE a.landingprocessname IS NOT NULL;
