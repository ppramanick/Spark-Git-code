DROP VIEW dev_meta.TargetErrorAudit;
CREATE VIEW IF NOT EXISTS dev_meta.TargetErrorAudit AS
SELECT
a.key
,a.coretopublishstartdatetime
,a.coretopublishenddatetime
,a.coreprocessname
,a.publishtotalnumberofrows
,a.coretotalnumberofrows
,a.corefailurerows
,a.worktotalnumberofrows
,a.workprocessstartdatetime
,a.workprocessenddatetime
,a.workmappingstartdatetime
,a.workmappingenddatetime
,a.workcdcstartdatetime
,a.workcdcstartenddatetime
,a.publishdatabasename
,a.publishtablename
,a.coredatabasename
,a.coretablename
,a.workdatabasename
,a.worktablename
,a.workvalidationprocessname
,a.workmappingprocessname
,a.workcdcprocessname
,a.worktocoreprocessname
,a.coretopublishprocessname
,a.workprocessuserid
,a.publishprocessuserid
,a.workprocessruntimems
,a.workmappingruntimems
,a.workcdcruntimems
,a.coretopublishruntimeinms
,a.worktopubvalidationruntimeinms
,(a.workprocessruntimems + a.coretopublishruntimeinms) as totalRuntimeInMs
,(a.worktopubvalidationruntimeinms / (a.workprocessruntimems + a.coretopublishruntimeinms)) AS percentageRuntimeValidation
,(a.workcdcruntimems / (a.workprocessruntimems + a.coretopublishruntimeinms)) AS percentageRuntimeCDC
,(a.workmappingruntimems / (a.workprocessruntimems + a.coretopublishruntimeinms)) AS percentageRuntimeMapping
,((a.workprocessruntimems-a.worktopubvalidationruntimeinms-a.workcdcruntimems) / (a.workprocessruntimems + a.coretopublishruntimeinms + a.workmappingruntimems)) AS percentageRuntimeMain
,e.key as errorkey
,e.datalakeingestionstartdatetime
,e.datalakeingestionfailuredatetime
,e.failurecode
,e.failuredescription
,e.failureprocessname
,e.failurezone
,e.yarnapplicationid
,e.failuresqlscript
,e.failuredatabase
,e.failuretable
,e.rowsaffected
,e.errorlevel
,e.failurelogfile
,e.failurelogmessage
,e.failuretimestampsaffectedtimestamp
FROM dev_meta.auditTarget a
LEFT OUTER JOIN dev_meta.errorLog e
ON (a.key = e.FailureAuditLinkKey)
WHERE a.WorkToCoreProcessName IS NOT NULL;
