CREATE TABLE ${WORK_DATABASE}.InsuranceAgreement
(
  AccountNumber VARCHAR(20) COMMENT 'Natural Key, GroupAccount.AccountNumber NOT NULL',
  InternalCompanyCode VARCHAR(50) COMMENT 'Natural Key NOT NULL',
  InsuranceAgreementNumber VARCHAR(40) COMMENT 'Natural Key NOT NULL',
  InsuranceAgreementTypeCode VARCHAR(50) COMMENT 'Natural Key NOT NULL',
  InsuranceAgreementEffectiveDate TIMESTAMP COMMENT 'Not Null',
  InsuranceAgreementEndDate TIMESTAMP COMMENT 'Not Null',
  SignatureDate DATE COMMENT 'Default to 1900-01-01 Not Null',
  TerminationDate DATE COMMENT 'Default to 9999-12-31 Not Null',
  RenewalDate DATE COMMENT 'Default to 9999-12-31 Not Null',
  BillingActivatedIndicator VARCHAR(1) COMMENT 'Default to - Not Null',
  InsuranceAgreementStatusCode VARCHAR(50) COMMENT 'Not Null',
  IssueStateCode VARCHAR(50) COMMENT 'Not Null',
  OriginalIssueDate DATE COMMENT 'Not Null',
  IssueDate DATE COMMENT 'Not Null',
  InsuranceAgreementModificationApprovalUserID VARCHAR(10) COMMENT 'Not Null',
  CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping from source Not Null',
  SourceSystemCode VARCHAR(20) COMMENT 'Default to Genelco Not Null',
  LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping from source on CurrentRecordIndicator Not Null',
  InsuranceAgreementStatusDate DATE COMMENT 'Default to 1900-01-01 Not Null',
  LastUpdateUserID VARCHAR(20) COMMENT 'No Mapping, Not Null',
  LastUpdateDateTime TIMESTAMP COMMENT 'No Mapping, Not Null',
  hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
  hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (AccountNumber, InternalCompanyCode, InsuranceAgreementNumber) INTO 128 BUCKETS
STORED AS ORC;



