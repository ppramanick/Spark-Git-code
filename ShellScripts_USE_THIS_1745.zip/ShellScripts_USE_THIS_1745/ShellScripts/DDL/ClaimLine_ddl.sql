CREATE TABLE ${WORK_DATABASE}.ClaimLine(
--AccountLineID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
--DeliveredServiceID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
--ClaimID BIGINT COMMENT 'No mapping, Not coming from Source / RDM Process required NOT NULL',
AccountLineNumber VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
ClaimNumber VARCHAR(50) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
DeliveredServiceName VARCHAR(150) COMMENT 'Mapping found coming from source, NOT NULL', --Natural Key, BDM lookup required
FederalTaxWithheldonLateClaimInterestAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
StateTaxWithheldonLateClaimInterestAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
FederalTaxWithheldonEmployerPaidBenefitsAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
StateTaxWithheldonEmployerPaidBenefitsAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
FederalTaxWithheldonSection125PaidBenefitsAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
StateTaxWithheldonSection125PaidBenefitsAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
FederalTaxWithheldonBenefitsPaidtoProviderAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
StateTaxWithheldonBenefitsPaidtoProviderAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
LateClaimInterestPaymentAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
LateClaimPenaltyPaymentAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
StateTaxWithheldAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
FederalTaxWithheldAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
ChildSupportLienDisbursementAmount DECIMAL(11,2) COMMENT 'Not coming from source, Hardcoded to 0.00 NOT NULL',
LastUpdateDateTime TIMESTAMP COMMENT 'Not coming from source, current timestamp LastUpdateDateTime NOT NULL',
CurrentRecordIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
SourceSystemCode VARCHAR(10) COMMENT 'Not coming from source, Hardcoded to Genelco NOT NULL',
LogicalDeleteIndicator VARCHAR(1) COMMENT 'Mapping found coming from source, NOT NULL',
LastUpdateUserID VARCHAR(20) COMMENT 'Mapping not found, Datalake NOT NULL',
hivelastupdatetimestamp TIMESTAMP COMMENT 'No mapping, current_timestamp',
hashcode STRING COMMENT 'No Mapping, it will store the hashcode for the record'
)
CLUSTERED BY (AccountLineNumber) INTO 128 BUCKETS
STORED AS ORC;