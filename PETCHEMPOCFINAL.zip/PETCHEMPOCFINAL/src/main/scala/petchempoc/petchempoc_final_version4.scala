package petchempoc
import kafka.serializer.StringDecoder
import java.util.Properties
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming._
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.kafka.{KafkaUtils, HasOffsetRanges, OffsetRange}
import io.confluent.kafka.serializers.KafkaAvroDecoder
import org.apache.spark.sql.SQLContext
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.kafka.clients.producer.RecordMetadata
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, lit, when}
object PetChemOrderStatus_version4 extends Serializable {
	def main(args: Array[String]) {
		val conf = new SparkConf().setAppName("PetChemPOC").setMaster("local[*]")
		val ssc = new StreamingContext(conf, Seconds(10))
		val sparkSession = SparkSession.builder().config(conf).getOrCreate()

		val kafkaParams = Map(
			"bootstrap.servers" -> "localhost:9092",
			"schema.registry.url" -> "http://localhost:8081",
			"group.id" -> "order",
			"auto.offset.reset" -> "smallest"
			)

/***************************Producer Properties*************************************/
                        val properties = new Properties()
                        properties.put("bootstrap.servers", "localhost:9092")
                        properties.put("key.serializer","org.apache.kafka.common.serialization.StringSerializer")
                        //properties.put("value.serializer", "io.confluent.kafka.serializers.KafkaAvroSerializer")
                        properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
                        properties.put("schema.registry.url", "http://localhost:8081")
                        
                        //val producer: KafkaProducer[String, String] = new KafkaProducer[String, String](properties)

/***************************Producer Properties ends here ***********************/


		val ordertopic="PETCHEM-POC-ORDERS"
		val billtopic="PETCHEM-POC-BILLING"
		val outputTopic="PETCHEM-CONSUMER-ORD-BILL"

		val orderStream: DStream[(String, Object)] =
			KafkaUtils.createDirectStream[String, Object, StringDecoder, KafkaAvroDecoder](ssc, kafkaParams, Set(ordertopic))
		val billingStream: DStream[(String, Object)] =
			KafkaUtils.createDirectStream[String, Object, StringDecoder, KafkaAvroDecoder](ssc, kafkaParams, Set(billtopic))



		orderStream.foreachRDD( rdd =>{
			val offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
			//println(offsetRanges)
			val topicName = offsetRanges.map(or => or.topic)
			topicName.foreach(println)
			val sqlContext = SQLContext.getOrCreate(rdd.sparkContext)
			import sqlContext.implicits._

			val orderRDD = rdd.map(_._2.toString)
			val orderDF = sqlContext.read.json(orderRDD)
			val jsonDF = orderDF.toJSON.rdd
			orderDF.printSchema()
			orderDF.cache
			orderDF.persist
			orderDF.write.mode("overwrite").format("json").save("/opt/petchempoc/orderDF/")
    		})

		billingStream.foreachRDD( rdd =>{
			val sqlContext = SQLContext.getOrCreate(rdd.sparkContext)
                	import sqlContext.implicits._

                	val billingRDD = rdd.map(_._2.toString)
                	val billingDF = sqlContext.read.json(billingRDD)
                	//val jsonDF = billingDF.toJSON.rdd
                	billingDF.printSchema()
                	billingDF.show(false)
                	billingDF.cache
                	println("OrderDF ----********************")
                	val orderDF = sqlContext.read.json("/opt/petchempoc/orderDF/*")
                	orderDF.show()
			if(!billingDF.rdd.isEmpty() && !orderDF.rdd.isEmpty()){
                		//val billstat = billingDF.filter($"billing_status" === "initiated").select($"order_id" , $"cust_id", $"ship_to_location", $"billing_status" )
				val billstat = billingDF.filter($"billing_status" === "Complete").select($"order_id" , $"cust_id", $"ship_to_location", $"billing_status" )
                		val updf1 = billstat.join(orderDF, "order_id" )
                		val finalOrderStatus = updf1.withColumn("order_status", when($"billing_status"isNull, $"order_status").otherwise(lit("ready_to_ship"))).select($"order_id", $"cust_id", $"ship_to_location", $"order_no", $"order_qty", $"order_status", $"order_date", $"Create_date", $"Modify_date")
                		finalOrderStatus.show()
		
				val finalOrderStatusProducer = finalOrderStatus.toJSON.rdd
         			val metadata = finalOrderStatusProducer.map(data => {
                                        println(data + "***********************")
                                        val producer: KafkaProducer[String, String] = new KafkaProducer[String, String](properties)
                                        val msg =  new ProducerRecord[String, String](outputTopic, data)
                                        producer.send(msg)

				})
                                metadata.foreach { metadata => metadata.get() }
		}
    })
    ssc.start()
    ssc.awaitTermination()
  }

}

