package petchempoc
import kafka.serializer.StringDecoder
import java.util.Properties
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming._
import org.apache.spark.sql.kafka010.KafkaSourceProvider
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.kafka.{KafkaUtils, HasOffsetRanges, OffsetRange}
import io.confluent.kafka.serializers.KafkaAvroDecoder
import org.apache.spark.sql.SQLContext
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.kafka.clients.producer.RecordMetadata
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.{col, lit, when}
object PetChemOrderStatus_version3 extends Serializable {
	def main(args: Array[String]) {
		val conf = new SparkConf().setAppName("PetChemPOC").setMaster("local[*]")
		val ssc = new StreamingContext(conf, Seconds(10))
		val sparkSession = SparkSession.builder().config(conf).getOrCreate()
		import sparkSession.implicits._

		val kafkaParams = Map(
			"bootstrap.servers" -> "ec2slave.hdp.com:6667",
			"schema.registry.url" -> "http://localhost:8081",
			"group.id" -> "order",
			"auto.offset.reset" -> "smallest"
			)

/***************************Producer Properties*************************************/
                        val properties = new Properties()
                        properties.put("bootstrap.servers", "ec2slave.hdp.com:6667")
                        properties.put("key.serializer","org.apache.kafka.common.serialization.StringSerializer")
                        //properties.put("value.serializer", "io.confluent.kafka.serializers.KafkaAvroSerializer")
                        properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
                        properties.put("schema.registry.url", "http://localhost:8081")
                        
                        //val producer: KafkaProducer[String, String] = new KafkaProducer[String, String](properties)

/***************************Producer Properties ends here ***********************/


		val ordertopic="PETCHEM-POC-ORDERS"
		val billtopic="PETCHEM-POC-BILLING"
		val outputTopic="PETCHEM-CONSUMER-ORD-BILL"
		val dashboardTopic = "ORDER-DASHBOARD"
		
		val streamingDF = sparkSession.read.format("org.apache.spark.sql.kafka010.KafkaSourceProvider").option("kafka.bootstrap.servers", "ec2slave.hdp.com:6667").option("subscribe", "ORDER-DASHBOARD").load()
		streamingDF.printSchema()
		//val streamingSelectDF = streamingDF.selectExpr(get_json_object(($"value").cast("string"), "$.order_status").alias("ORDER_STATUS"))
		//val streamingSelectDF = streamingDF.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")
		//println(streamingSelectDF)

    ssc.start()
    ssc.awaitTermination()
  }

}

