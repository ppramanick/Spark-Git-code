package petchempoc
import kafka.common.TopicAndPartition
import kafka.message.MessageAndMetadata
import kafka.serializer.{DefaultDecoder, StringDecoder}
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.streaming.dstream.DStream
import io.confluent.kafka.serializers.KafkaAvroDecoder
import org.apache.spark.streaming.kafka.{HasOffsetRanges, KafkaUtils}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkConf


/**
  * contains spark/kafka utility methods common to processing
  */
object SparkUtilsScala {
	def createCustomDirectKafkaStreamAvro(ssc: StreamingContext, kafkaParams: Map[String, String], topic: Set[String]): DStream[(String, Object)] = {
		//val kafkaStream = KafkaUtils.createDirectStream(ssc, PreferConsistent, Subscribe[String, String](topics, kafkaParams))
		val message: DStream[(String, Object)] =  KafkaUtils.createDirectStream[String, Object, StringDecoder, KafkaAvroDecoder](ssc, kafkaParams, topic)
		//val kafkaStream = message.map(row => row._2.toString)
		message

	}
	
        def setupSsc(topicSet1: Set[String],topicSet2: Set[String], kafkaParams: Map[String, String], conf: String)(): StreamingContext = {
        	//create spark and memsql context
        	val ssc = new StreamingContext(conf)
        	//processAvroRequestData(ssc, kafkaParams, topicSet1, topicSet2)
        	ssc
        }

	
}


